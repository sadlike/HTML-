//
//  IDCardCameraVC.h
//  IDCardDemo
//
//  Created by mac on 13-4-1.
//  Copyright (c) 2013年 mac. All rights reserved.
//


typedef enum
{
	IDC_NON,                  //non
    IDC_NAME,              //姓名
    IDC_NAME_CH,           //姓名（中文）
    IDC_CARDNO,            //证号
    IDC_SEX,               //性别
    IDC_BIRTHDAY,          //出生日期
    IDC_ADDRESS,           //地址
    IDC_ISSUE_AUTHORITY,   //签发机构
    IDC_ISSUE_DATE,        //签发日期
    IDC_VALID_PERIOD,      //有效期限
    IDC_COUNTRY,           //国籍
    
    IDC_FOLK,              //民族
    
    IDC_MEMO
} IDCard;


#define IDC_HEADIMAGE      -10

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
@class CameraDrawView;
@protocol IDCardCameraVCDelegate;

//为使在ios5系统下能够自动对焦，确保IDCardCameraVC实例只初始化一次

@interface IDCardCameraVC : UIViewController
{
    
}

-(void)dismissSelf:(id)sender;

@property (strong, nonatomic) UIImage *idCardImage;
@property (strong, nonatomic) UIButton *cancelButton;
@property (assign, nonatomic) id<IDCardCameraVCDelegate> delegate;

@end


@protocol IDCardCameraVCDelegate <NSObject>
//返回识别结果：resultDict
//resultDict 详细数据结构project内搜：getIDCardDataInfo
-(void)idCardCamerVC:(IDCardCameraVC*)idCardCameraVC  cardRecResult:(NSDictionary*)resultDict;
//识别进度：process (0~100)
-(void)idCardCamerVC:(IDCardCameraVC*)idCardCameraVC  cardRecProcess:(NSNumber*)process;

@end
