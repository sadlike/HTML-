//
//  OCREngine.h
//  IDCardScanDemo
//
//  Created by  on 14-04-16.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Common.h"

#define OCR_TEXT_MAX_LEN    1024

#define SYSTEM_HEIGHT [UIScreen mainScreen].bounds.size.height
#define SYSTEM_WIDTH  [UIScreen mainScreen].bounds.size.width

// 客户授权渠道号字符串
#define CHANNELNUM_BK  @"njzjbkios"
#define CHANNELNUM_ID  @"njzjidios"
#define CHANNELNUM_JZ  @"CPSTR"
#define CHANNELNUM_XS  @"IDSTR"
#define CHANNELNUM_CP  @"njzjcpios"
#define CHANNELNUM_VIN @"CPSTR"
#define CHANNELNUM_GCFP @"GCFPSTR"
#define CHANNELNUM_HZ  @"IDSTR"


#define RES_XSSTR  @"XSSTR"
#define RES_JZSTR  @"JZSTR"
#define RES_CPSTR  @"CPSTR"
#define RES_IDSTR  @"IDSTR"
#define RES_VINSTR @"VINSTR"
#define RES_GCFPSTR @"GCFPSTR"
#define RES_HZSTR  @"HZSTR"

//version=1：2.2.8（不切边），version=2：2.4.9（强制找边切边） 默认为强制找边版本
#define VERSION 2

//银行卡
//#define RESBANK_NUM            @"BANK_NUM"            //银行卡号
//#define RESBANK_BANKNAME       @"BANK_BANKNAME"       //银行名称
//#define RESBANK_CARDNAME       @"BANK_CARDNAME"       //卡名称
//#define RESBANK_CARDTYPE       @"BANK_CARDTYPE"       //卡类型
//#define RESBANK_IDIMAGE        @"BANK_IDIMAGE"        //证件图片
//#define RESBANK_RET            @"BANK_RET"            //返回值

#define RESBANK_NUM            @"bank_card_no"            //银行卡号
#define RESBANK_BANKNAME       @"bank_name"       //银行名称
#define RESBANK_CARDNAME       @"card_name"       //卡名称
#define RESBANK_CARDTYPE       @"card_type"       //卡类型
#define RESBANK_IDIMAGE        @"bank_card_image"        //证件图片
#define RESBANK_RET            @"BANK_RET"            //返回值

//身份证
#define RESID_NAME          @"ID_NAME"          //姓名
#define RESID_SEX           @"ID_SEX"           //性别
#define RESID_FOLK          @"ID_FOLK"          //民族
#define RESID_BIRT          @"ID_BIRT"          //出生日期
#define RESID_ADDRESS       @"ID_ADDRESS"       //住址
#define RESID_NUM           @"ID_NUM"           //公民身份号码
#define RESID_ISSUE         @"ID_ISSUE"         //签发机关
#define RESID_VALID         @"ID_VALID"         //有效期限
#define RESID_IMAGE         @"ID_IMAGE"         //证件图片
#define RESID_HEADIMAGE     @"ID_HEADIMAGE"     //证件头像图片
#define RESID_RESULT        @"ID_RESULT"        //识别结果


//#define RESID_NAME          @"name"          //姓名
//#define RESID_SEX           @"sex"           //性别
//#define RESID_FOLK          @"nation"          //民族
//#define RESID_BIRT          @"birthday"          //出生日期
//#define RESID_ADDRESS       @"address"       //住址
//#define RESID_NUM           @"id_card_no"           //公民身份号码
//#define RESID_ISSUE         @"issuer"         //签发机关
//#define RESID_VALID         @"expiration_date"         //有效期限
//#define RESID_IMAGE         @"ID_IMAGE"         //证件图片
//#define RESID_HEADIMAGE     @"ID_HEADIMAGE"     //证件头像图片
//#define RESID_RESULT        @"ID_RESULT"        //识别结果


//行驶证
#define RESXS_NAME          @"XS_NAME"          //所有人
#define RESXS_CARDNO        @"XS_CARDNO"        //号牌号码
#define RESXS_ADDRESS       @"XS_ADDRESS"       //住址
#define RESXS_VEHICLETYPE   @"XS_VEHICLETYPE"   //车辆类型
#define RESXS_USECHARACTE   @"XS_USECHARACTE"   //使用性质
#define RESXS_MODEL         @"XS_MODEL"         //品牌型号
#define RESXS_VIN           @"XS_VIN"           //车辆识别代号
#define RESXS_ENGINEPN      @"XS_ENGINEPN"      //发动机号码
#define RESXS_REGISTERDATE  @"XS_REGISTERDATE"  //注册日期
#define RESXS_ISSUEDATE     @"XS_ISSUEDATE"     //发证日期
#define RESXS_FILENO        @"XS_FILENO"        //档案编号
#define RESXS_RECORD        @"XS_RECORD"        //检验记录
#define RESXS_APPROVEDNO    @"XS_APPROVEDNO"    //核定载人数
#define RESXS_TOTALQUALITY  @"XS_TOTALQUALITY"  //总质量
#define RESXS_CURBWEIGHT    @"XS_CURBWEIGHT"    //整备质量
#define RESXS_APPROVEDQUALITY   @"XS_APPROVEDQUALITY"   //核定载质量
#define RESXS_SIZE          @"XS_SIZE"          //外廓尺寸
#define RESXS_TRACTQUALITY  @"XS_TRACTQUALITY"  //准牵引总质量
#define RESXS_NOTE          @"XS_NOTE"          //备注
#define RESXS_IDIMAGE       @"XS_IDIMAGE"       //证件图片

//驾照
#define RESJZ_NAME          @"JZ_NAME"          //姓名
#define RESJZ_CARDNO        @"JZ_CARDNO"        //证号
#define RESJZ_SEX           @"JZ_SEX"           //性别
#define RESJZ_BIRTHDAY      @"JZ_BIRTHDAY"      //出生日期
#define RESJZ_ADDRESS       @"JZ_ADDRESS"       //住址
#define RESJZ_ISSUE_DATE    @"JZ_ISSUE_DATE"    //初次领证日期
#define RESJZ_VALID_PERIOD  @"JZ_VALID_PERIOD"  //有效期限
#define RESJZ_COUNTRY       @"JZ_COUNTRY"       //国籍
#define RESJZ_DRIVING_TYPE  @"JZ_DRIVING_TYPE"  //准驾车型
#define RESJZ_REGISTER_DATE @"JZ_REGISTER_DATE" //有效起始日期
#define RESJZ_FILENO        @"JZ_FILENO"        //档案编号
#define RESJZ_RECORD        @"JZ_RECORD"        //检验记录
#define RESJZ_IDIMAGE       @"JZ_IDIMAGE"       //证件图片

//车牌
#define RESCP_NUM           @"Num"
#define RESCP_LAYER         @"Layer"
#define RESCP_COLOR         @"Color"
#define RESCP_IDIMAGE       @"CP_IDIMAGE"       //证件图片

//vin码
#define RESVIN_RESULT       @"VIN_RESULT"    //识别结果
#define RESVIN_IDIMAGE      @"VIN_IDIMAGE"   //整张图片
#define RESVIN_HEADIMAGE    @"VIN_HEADIMAGE" //VIN图片

//购车发票
#define RESGCFP_RESULT       @"GCFP_RESULT"    //识别结果
#define RESGCFP_BlockNum     @"GCFP_BlockNum"
#define RESGCFP_Text         @"GCFP_Text"
#define RESGCFP_TextTable    @"GCFP_TextTable"
#define RESGCFP_Lx           @"GCFP_Lx"
#define RESGCFP_Ly           @"GCFP_Ly"
#define RESGCFP_Rx           @"GCFP_Rx"
#define RESGCFP_Ry           @"GCFP_Ry"
#define RESGCFP_IDIMAGE      @"GCFP_IDIMAGE"  //购车发票图片

//护照
#define RESHZ_NAME            @"HZ_NAME"          //英文姓名
#define RESHZ_NAMECH          @"HZ_NAMECH"        //中文姓名
#define RESHZ_CARDNO          @"HZ_CARDNO"        //护照号
#define RESHZ_SEX             @"HZ_SEX"           //英文性别
#define RESHZ_SEXCH           @"HZ_SEXCH"         //中文性别
#define RESHZ_BIRTHDAY        @"HZ_BIRTHDAY"      //出生日期
#define RESHZ_ADDRESS         @"HZ_ADDRESS"       //英文地点
#define RESHZ_ADDRESSCH       @"HZ_ADDRESSCH"     //中文地点
#define RESHZ_ISSUEDATE       @"HZ_ISSUEDATE"     //签发日期
#define RESHZ_VALIDPERIOD     @"HZ_VALIDPERIOD"   //有效期限
#define RESHZ_NATION          @"HZ_NATION"        //国 家
#define RESHZ_ISSUEADDRESS    @"HZ_ISSUEADDRESS"    //英文签发地点
#define RESHZ_ISSUEADDRESSCH  @"HZ_ISSUEADDRESSCH"  //中文签发地点
#define RESHZ_PERSONALNO      @"HZ_PERSONALNO"      //个人号码
#define RESHZ_ENFIR           @"HZ_ENFIR"           //中文姓拼音
#define RESHZ_ENSEN           @"HZ_ENSEN"           //中文名拼音
#define RESHZ_NAMEFIR         @"HZ_NAMEFIR"         //中文姓
#define RESHZ_NAMESEN         @"HZ_NAMESEN"         //中文名
#define RESHZ_MRZ             @"HZ_MRZ"           //MRZ
#define RESHZ_BIDC_MRZ1       @"HZ_BIDC_MRZ1"     //BIDC_MRZ1
#define RESHZ_BIDC_MRZ2       @"HZ_BIDC_MRZ2"     //BIDC_MRZ2
#define RESHZ_IDIMAGE         @"HZ_IDIMAGE"       //证件图片

@protocol BCRProgressCallBackDelegate;

@protocol BcrResultCallbackDelegate <NSObject>
@required -(void)bcrResultCallbackWithValue:(NSInteger)value;
@end

@protocol BcrFreeCallbackDelegate <NSObject>
@required -(void)bcrFreeCallbackWithFreeValue:(NSInteger)freeValue;
@end

@interface YMIDCardEngine : NSObject
{
    BEngine         *_bcrEngine;
    BImage          *_bImage;
    CGRect          textRect;
    NSInteger       progress;
    UIImage         *idCardImage;
    BImage          *_headBImage;
    BImage          *_picImage;
    UIImage         *headImage;
}

typedef enum
{
    Bank_NON,                  //non
    Bank_cardNo,              //银行卡卡号
    Bank_bankName,            //银行名称
    Bank_cardName,            //银行卡名称
    Bank_cardType,            //银行卡类型
    Bank_MEMO
} BankCard;

typedef enum
{
    engInitSuccess,            //初始化成功
    engInitFailed,             //初始化失败   0
    engInitLocTimeExpired,     //本地时间过期 100
    engInitRecTimeExpired,     //识别时间过期 101
    engInitAuthoriFailed,        //授权失败  200
    engInitTimesExceed,        //识别次数超过 300
    engInitEncryptionFailed,   //软件加密失败 600
    engInitTimesPermissionsFailed,   //识别次数创建权限失败  900
    engInitTimePermissionsFailed,     //识别时间创建权限失败 901
    
}EngInitRet;

typedef enum
{
    ID_NON,                  //non
    ID_cardNo,              //
} IDCard;

typedef enum
{
    cardType_Bank,            //银行卡
    cardType_ID,              //身份证
    cardType_JZ,              //驾照
    cardType_XS,              //行驶证
    cardType_CP,              //车牌
    cardType_VIN,             //VIN
    cardType_GCFP,            //购车发票
    cardType_HZ,              //护照
} CardType;

@property (nonatomic, assign) NSInteger ocrLanguage;

@property (nonatomic, assign) NSInteger version;

@property(nonatomic) EngInitRet engInitRet;

@property(nonatomic,assign)NSInteger cardIndex;

/**
 初始化引擎
 @param   language：识别语言   默认传2
 @param   index：证件索引
 @return
 */
- (id)initWithLanguage:(NSInteger)language andIndex:(NSInteger)index;

/**
 拍照或者导入申请图片
 @param   image：图片
 @return  0：失败
 1：成功
 */
- (BOOL)allocBImage:(UIImage *)image;

/**
 身份证拍照或者导入识别
 @param   picIndex: 单张导入识别传0；批量导入识别图片索引
 @return  NSDictionary：身份证拍照或者导入识别结果
          JSON格式
 */
- (NSDictionary *)doBCR_IDwithPicIndex:(NSInteger)picIndex;

/**
 行驶证拍照或者导入识别
 @param   picIndex: 单张导入识别传0；批量导入识别图片索引
 @return  NSDictionary：行驶证拍照或者导入识别结果
 */
- (NSDictionary *)doBCR_XSwithPicIndex:(NSInteger)picIndex;

/**
 驾照拍照或者导入识别
 @param   picIndex: 单张导入识别传0；批量导入识别图片索引
 @return  NSDictionary：驾照拍照或者导入识别结果
 */
- (NSDictionary *)doBCR_JZwithPicIndex:(NSInteger)picIndex;

/**
 车牌拍照或者导入识别
 @param   picIndex: 单张导入识别传0；批量导入识别图片索引
 @return  NSDictionary：车牌拍照或者导入识别结果
 */
- (NSDictionary *)doOCR_CPwithPicIndex:(NSInteger)picIndex;

/**
 VIN拍照或者导入识别
 @param   picIndex: 单张导入识别传0；批量导入识别图片索引
 @return  NSDictionary：VIN拍照或者导入识别结果
 */
- (NSDictionary *)doOCR_VINwithPicIndex:(NSInteger)picIndex;

/**
 购车发票拍照或者导入识别
 @param   picIndex: 单张导入识别传0；批量导入识别图片索引
 @return  NSDictionary：购车发票拍照或者导入识别结果
 */
- (NSDictionary *)doOCR_GCFPwithPicIndex:(NSInteger)picIndex;

/**
 护照拍照或者导入识别

 @return  NSDictionary：护照拍照或者导入识别结果
 */
- (NSDictionary *)doBCRJSON_HZ;

/**
 银行卡视频识别
 @param width    图像宽度
 @param height   图像高度
 @param pRect    视频图像四个点的位置信息
 
 @return  100：试用期已过
 200：未授权
 0：表示处理事变， 1~16：表示是否存在四条边框信息
 */
-(int)doBcrRecognizeVedioWithBuffer_BK:(UInt8 *)buffer andWidth:(int)width andHeight:(int)height andRect:(BRect)pRect andChannelNumberStr:(NSString *)channelNumberStr;

-(NSDictionary*)doBCR_BankWithImagePath:(NSString*)imagePath andChannelNumberStr:(NSString *)channelNumberStr withPicIndex:(NSInteger)picIndex;

/**
 行驶证视频识别找边
 @param width    图像宽度
 @param height   图像高度
 @param pRect    视频图像四个点的位置信息
 
 @return  100：试用期已过
          200：未授权
            0：表示处理事变， 1~16：表示是否存在四条边框信息
 */
-(int)doBcrRecognizeVedioWith_XS:(UInt8 *)buffer andWidth:(int)width andHeight:(int)height andRect:(BRect)pRect andChannelNumberStr:(NSString *)channelNumberStr;

/**
 身份证视频识别找边
 @param width    图像宽度
 @param height   图像高度
 @param pRect    视频图像四个点的位置信息
 
 @return  100：试用期已过
 200：未授权
 0：表示处理事变， 1~16：表示是否存在四条边框信息
 */
-(int)doBcrRecognizeVedioWith_ID:(UInt8 *)buffer andWidth:(int)width andHeight:(int)height andRect:(BRect)pRect andChannelNumberStr:(NSString *)channelNumberStr;

/**
 驾照视频识别找边
 @param width    图像宽度
 @param height   图像高度
 @param pRect    视频图像四个点的位置信息
 
 @return  100：试用期已过
 200：未授权
 0：表示处理事变， 1~16：表示是否存在四条边框信息
 */
-(int)doBcrRecognizeVedioWith_JZ:(UInt8 *)buffer andWidth:(int)width andHeight:(int)height andRect:(BRect)pRect andChannelNumberStr:(NSString *)channelNumberStr;

/**
 车牌视频识别找边
 @param width    图像宽度
 @param height   图像高度
 @param pRect    视频图像四个点的位置信息
 
 @return  100：试用期已过
 200：未授权
 0：表示处理事变， 1~16：表示是否存在四条边框信息
 */
-(int)doBcrRecognizeVedioWith_CP:(UInt8 *)buffer andWidth:(int)width andHeight:(int)height andRect:(BRect)pRect andChannelNumberStr:(NSString *)channelNumberStr;

/**
 VIN视频识别找边
 @param width    图像宽度
 @param height   图像高度
 @param pRect    视频图像四个点的位置信息
 
 @return  100：试用期已过
 200：未授权
 0：表示处理事变， 1~16：表示是否存在四条边框信息
 */
-(int)doBcrRecognizeVedioWith_VIN:(UInt8 *)buffer andWidth:(int)width andHeight:(int)height andRect:(BRect)pRect andChannelNumberStr:(NSString *)channelNumberStr;

/**
 身份证视频识别结果
 @param   rect：预留参数
 @return  NSDictionary：识别结果为字典格式

 */
- (NSDictionary *)doBCRWithRect_ID:(CGRect)rect;

/**
 行驶证视频识别结果
 @param   rect：预留参数
 @return  NSDictionary：识别结果为字典格式

 */
- (NSDictionary *)doBCRWithRect_XS:(CGRect)rect;

/**
 驾照视频识别结果
 @param   rect：预留参数
 @return  NSDictionary：识别结果为字典格式

 */
- (NSDictionary *)doBCRWithRect_JZ:(CGRect)rect;

/**
 车牌视频识别结果
 @param   rect：预留参数
 @return  NSDictionary：识别结果为字典格式

 */
- (NSDictionary *)doBCRWithRect_CP:(CGRect)rect;

/**
 银行卡视频识别结果
 @param   rect：预留参数
 @return  NSDictionary：识别结果为字典格式
 
 */

- (NSDictionary *)doBCRWithRect_BK:(CGRect)rect;

/**
 VIN视频识别结果
 @param   rect：预留参数
 @return  NSDictionary：识别结果为字典格式
 
 */
- (NSDictionary *)doBCRWithRect_VIN:(CGRect)rect;

/**
 视频识别结果回调
 @param   delegate：代理
 @return
 
 */
-(void)setBcrResultCallbackDelegate:(id)delegate;

/**
 VIN视频识别取消释放 
 @param
 @return
 
 */
- (void)ymClearAll_ID;

/**
 驾照视频识别取消释放
 @param
 @return
 
 */
- (void)ymClearAll_JZ;

/**
 行驶证视频识别取消释放
 @param
 @return
 
 */
- (void)ymClearAll_XS;

/**
 车牌视频识别取消释放
 @param
 @return
 
 */
- (void)ymClearAll_Plate;

/**
 整合身份证银行卡等
 */
/**
 初始化引擎
 @param   language：识别语言   默认传2
 @param   channelNumberStr：客户授权渠道号
 @return
 */
- (id)initWithLanguage:(NSInteger)language andIndex:(NSInteger)index andChannelNumber:(NSString*)channelNumberStr;

/**
 拍照或者导入申请图片
 @param   image：图片
 @return  0：失败
 1：成功
 */
- (BOOL)allocBImage_ID:(UIImage *)image;

/**
 视频识别申请图片
 @param   image：图片
 @return  0：失败
 1：成功
 */
- (BOOL)allocBImageVideo_ID:(UIImage*)image;



- (NSDictionary *)doBCRJSON_IDwithPicIndex:(NSInteger)picIndex;


-(void)clearYMAllVideo;

@end


