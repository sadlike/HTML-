#ifndef _LOAD_BMP_H_
#define _LOAD_BMP_H_

#include "imgdef.h"

#ifdef __cplusplus
extern "C" {
#endif

char * LoadImageBMP(const char *filename, int *pWidth, int *pHeight);
int get_property_from_bmp(const char *filename, 
						  int *pWidth, int *pHeight, int *pComponents);

#ifdef __cplusplus
}
#endif

#endif // _LOAD_BMP_H_