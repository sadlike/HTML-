#include "savebmp.h"
#include "loadbmp.h"

#include <memory.h>

puint_8 getYData(puint_16 pRgb565, int width, int height)
{
	int i = 0, j = 0;
	int offset = 0;
	int byteWidth = width * sizeof(uint_8);
	uint_16 red = 0, green = 0, blue = 0;
	puint_8 pYData = (puint_8)malloc(byteWidth);
	puint_8 pData = NULL;
	uint_8 ydata = 0;
	
	if (!pRgb565 || !pYData) goto GET_EXIT;

	pData = (puint_8)pRgb565;
	for (i = 0; i < height; i++) {
		//memset(pYData, 0, byteWidth);
		for (j = 0; j < width; j++) {
			red = (pRgb565[offset + j] & RGB565_MASK_RED) >> 8;
			green = (pRgb565[offset + j] & RGB565_MASK_GREEN) >> 3;
			blue = (pRgb565[offset + j] & RGB565_MASK_BLUE) << 3;
			ydata = (uint_8)((red * 30 + green * 59 + blue * 11) / 100);
			//printf("rgb = 0x%x, r = %d, g = %d, b = %d, y = %d\n", pRgb565[offset + j], red, green, blue, ydata);
			pYData[j] = ydata;
		}
		memcpy(pData + offset, pYData, byteWidth);
		offset += width;
	}

GET_EXIT:
	// release the resource
	if (pYData) {
		free(pYData);
		pYData = NULL;
	}
		
	return pData;
}

// this function only support the 8bits Y data
//int SaveImageBMP(char *filename, char *pYDataBuf, int width, int height)
int SaveImageBMP(const char *filename, char *pYDataBuf, int width, int height)
{
	COMBITMAPFILEHEADER	ph;
	COMBITMAPINFOHEADER	pi;
	FILE *file = NULL;
	unsigned int dwCOMBITMAPINFOSize = 0, dwFileHeaderSize = 0;
	int image_size = 0, writeBytes = 0, i = 0;
	unsigned char colorPalette[1024] = { 0 }, diffBuf[5] = { 0 }, hbuf[100] = { 0 };
	unsigned char *pColorPalette = NULL, *p = NULL;
	int scanWidth = (width + 3) >> 2 << 2; // bytes per line
	int diff = scanWidth - width; // should be in the range [0, 4]
	int offset = 0;

	if (!pYDataBuf) return 0;

	//tjh add
	//width = scanWidth;
	//diff = 0;

	file = fopen(filename, "wb");
	if (!file) 
	{
//		printf("fail to open the file: %s\n", filename);
		return 0;
	}

	dwCOMBITMAPINFOSize = SIZE_BMPINFOHEADER + 256 * sizeof(COMRGBQUAD);
	image_size = scanWidth * height;
	dwFileHeaderSize = SIZE_BMPFILEHEADER + dwCOMBITMAPINFOSize;
	
	//
	// Fill in the fields of the file header & write to file
	//
	pi.biBitCount   = 8; // this is a 8bits bmp image
	ph.bfType       = 0x4d42;
	ph.bfSize       = dwFileHeaderSize + image_size;
	ph.bfReserved1  = 0;
	ph.bfReserved2  = 0;
	ph.bfOffBits    = dwFileHeaderSize;

	p = (unsigned char *)hbuf;
	memcpy(p, &(ph.bfType), 2); p += 2;
	memcpy(p, &(ph.bfSize), 4); p += 4;
	p += 4;
	memcpy(p, &(ph.bfOffBits), 4); p += 4;

	writeBytes = fwrite((void *)hbuf, 1, SIZE_BMPFILEHEADER, file);
	if (writeBytes != SIZE_BMPFILEHEADER)
	{
//		printf("fail to write the file header\n");
		fclose(file);
		return 0;
	}


	//
	// fill in the fields of the info header & write to file
	//
	pi.biSize = SIZE_BMPINFOHEADER;
	pi.biWidth = width;
	pi.biHeight = height;
	pi.biPlanes = 1;
	pi.biCompression = 0;
	pi.biClrImportant = 0;
	pi.biSizeImage = 0;
	pi.biXPelsPerMeter = 0;
	pi.biYPelsPerMeter = 0;
	pi.biClrUsed = 0;

	p = (unsigned char *)hbuf;
	memcpy(p, &(pi.biSize), 4);          p += 4;
	memcpy(p, &(pi.biWidth), 4);         p += 4;
	memcpy(p, &(pi.biHeight), 4);        p += 4;
	memcpy(p, &(pi.biPlanes), 2);        p += 2;
	memcpy(p, &(pi.biBitCount), 2);      p += 2;
	memcpy(p, &(pi.biCompression), 4);   p += 4;
	memcpy(p, &(pi.biSizeImage), 4);     p += 4;
	memcpy(p, &(pi.biXPelsPerMeter), 4); p += 4;
	memcpy(p, &(pi.biYPelsPerMeter), 4); p += 4;
	memcpy(p, &(pi.biClrUsed), 4);       p += 4;
	memcpy(p, &(pi.biClrImportant), 4);  p += 4;

	writeBytes = fwrite((void *)hbuf, 1, SIZE_BMPINFOHEADER, file);
	if (writeBytes != SIZE_BMPINFOHEADER)
	{
//		printf("fail to write info header\n");
		fclose(file);
		return 0;
	}

	
	//
	// creat the color palette & write it to the file
	//
	pColorPalette = colorPalette;
	for (i = 0; i < 256; i++)
	{
		*pColorPalette++ = (unsigned char)i;
		*pColorPalette++ = (unsigned char)i;
		*pColorPalette++ = (unsigned char)i;
		*pColorPalette++ = (unsigned char)0;
	}
	writeBytes = fwrite(colorPalette, 1, 1024, file);
	if (writeBytes != 1024)
	{
//		printf("fail to write the color palette\n");
		fclose(file);
		return 0;
	}


	//
	// write the Y data to the file
	//
	offset = width * (height - 1); // copy Y data from the bottom cause the format of bmp image data storage  
	for (i = 0; i < height; i++)
	{
		writeBytes = fwrite(pYDataBuf + offset, 1, width, file);
		if (writeBytes != width)
		{
//			printf("fail to write the Y Data to the file\n");
			fclose(file);
			return 0;
		}
		if (diff)
		{
			writeBytes = fwrite(diffBuf, 1, diff, file);
			if (writeBytes != diff)
			{
//				printf("fail to write the diff bytes to the file\n");
				fclose(file);
				return 0;
			}
		}
		offset -= width; // NOTE, this maybe diff from other image format
	}
	
//	printf("successfully\n");
	fclose(file);
	return 1;
}
