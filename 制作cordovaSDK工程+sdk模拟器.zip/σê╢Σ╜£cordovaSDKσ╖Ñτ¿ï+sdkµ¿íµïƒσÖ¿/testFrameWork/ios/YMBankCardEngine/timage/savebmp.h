#ifndef _SAVE_BMP_H_
#define _SAVE_BMP_H_

#include "imgdef.h"

#ifdef __cplusplus
extern "C" {
#endif

int SaveImageBMP(const char *filename, char *pYDataBuf, int width, int height);

puint_8 getYData(puint_16 pRgb565, int width, int height);

#ifdef __cplusplus
}
#endif

#endif // _SAVE_BMP_H_