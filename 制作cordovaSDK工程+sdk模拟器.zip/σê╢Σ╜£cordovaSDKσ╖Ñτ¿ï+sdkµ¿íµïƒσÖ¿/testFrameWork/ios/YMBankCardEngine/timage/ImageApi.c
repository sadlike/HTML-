#include "ImageApi.h"
#include "imgdef.h"
#include "adapter.h"

typedef struct _IMAGE_FORMAT 
{
	char *name;
	int format;
} ImageFormat;

uint_8 *IM_LoadImageMemJpg(char *pImgMem, int memSize, short *pWidth, short *pHeight, int *pComponents);
uint_8 *IM_LoadImageMemBmp(char *pImgMem, int memSize, short *pWidth, short *pHeight, int *pComponents);
uint_8 *IM_LoadImageFileJpg(char *pFilePath, short *pWidth, short *pHeight, int *pComponents);
int _get_format_from_file(const char *filename);
int _get_format_from_mem(const void *pImgMem, int memSize);


Image *IM_LoadImageMem(char *pImgMem, int memSize)
{
	Image	 *pImage = NULL;
	uint_8   *pData = NULL;
	int		 width = 0;
	int		 height = 0;
	int		 components = 0;
	int		 nFormat = 0;

	if (NULL == pImgMem)
	{
		return NULL;
	}

	pImage = (Image *)malloc(sizeof(Image));
	if (NULL == pImage)
	{
		return NULL;
	}
	memset(pImage, 0, sizeof(Image));


	//judge image file format
	nFormat = _get_format_from_mem(pImgMem, memSize);

	switch (nFormat)
	{
	case IMG_FMT_BMP:
		{	
			pData = LoadImageMemBmp(pImgMem, memSize,&width, &height, &components);
		}
		break;
		
	case IMG_FMT_JPG:
		{
			pData = LoadImageMemJpg(pImgMem, memSize,&width, &height, &components);
		}
		break;
	case IMG_FMT_PNG:
		{	
		}
		break;
	case IMG_FMT_TIF:
		{	
		}
		break;	
	case IMG_FMT_GIF:
		{	
		}
		break;	
	default:
		break;
	}

	if (NULL == pData)
	{
		free(pImage);
		return NULL;
	}

	//get image data info
	pImage->components = components;
	pImage->pData = pData;
	pImage->width = width;
	pImage->height = height;

	return pImage;
}

Image *IM_LoadImageFile(char *pFilePath)
{
	Image	 *pImage = NULL;
	uint_8   *pData = NULL;
	int		 width = 0;
	int		 height = 0;
	int		 components = 0;
	int		 nFormat = 0;
	
	if (NULL == pFilePath)
	{
		return NULL;
	}
	
	pImage = (Image *)malloc(sizeof(Image));
	if (NULL == pImage)
	{
		return NULL;
	}
	memset(pImage, 0, sizeof(Image));
	
	
	//judge image file format
	nFormat = _get_format_from_file(pFilePath);

	switch (nFormat)
	{
	case IMG_FMT_BMP:
		{	
		}
		break;
		
	case IMG_FMT_JPG:
		{
			pData = LoadImageFileJpeg(pFilePath,&width, &height, &components);
		}
		break;
	case IMG_FMT_PNG:
		{	
			//pData = LoadImageFilePng(pFilePath,&width, &height, &components);
		}
		break;
	case IMG_FMT_TIF:
		{	
		}
		break;	
	case IMG_FMT_GIF:
		{	
		}
		break;
	default:
		break;
	}
	
	if (NULL == pData)
	{
		free(pImage);
		return NULL;
	}

	//get image data info
	pImage->components = components;
	pImage->pData = pData;
	pImage->width = width;
	pImage->height = height;
	
	return pImage;
}


// uint_8 *IM_LoadImageMemJpg(char *pImgMem, int memSize, short *pWidth, short *pHeight, int *pComponents)
// {
// 
// 	if (NULL == pImgMem || NULL == pWidth || NULL == pHeight || NULL == pComponents)
// 	{
// 		return NULL;
// 	}
// 	
// 	return LoadImageMemJpg(pImgMem, memSize, pWidth, pHeight, pComponents);
// 
// }
// uint_8 *IM_LoadImageMemBmp(char *pImgMem, int memSize, short *pWidth, short *pHeight, int *pComponents)
// {
// 	
// 	if (NULL == pImgMem || NULL == pWidth || NULL == pHeight || NULL == pComponents)
// 	{
// 		return NULL;
// 	}
// 	
// 	return LoadImageMemBmp(pImgMem, memSize, pWidth, pHeight, pComponents);
// 	
// }
// uint_8 *IM_LoadImageFileJpg(char *pFilePath, short *pWidth, short *pHeight, int *pComponents)
// {
// 	
// 	if (NULL == pFilePath || NULL == pWidth || NULL == pHeight || NULL == pComponents)
// 	{
// 		return NULL;
// 	}
// 	
// 	return  LoadImageJpeg(pFilePath, pWidth, pHeight, pComponents);
// 
// }

int _get_format_from_file(const char *filename)
{
	int fmt = IMG_FMT_UNK;
	
	if (filename)
	{
		ImageFormat fmt[] = { 
			{ "jpg", IMG_FMT_JPG }, 
			{ "bmp", IMG_FMT_BMP }, 
			{ "jpeg" , IMG_FMT_JPG } 
		};
		int fmt_cnt = ARRAY_SIZE(fmt);
		char filepath[256] = { 0 };
		char *p0, *p1, *p;
		int len = strlen(filename);
		
		strcpy(filepath, filename);
		p0 = (char *)filepath;
		p1 = p0 + len - 1;
		p = p1;
		
		for (; p != p0; p--) {
			if (*p == '.') {
				int ext_len = p1 - p;
				if (ext_len < 5) {
					int i;
					char ext[8] = { 0 };
					
					memcpy(ext, p+1, ext_len);
					//ext = strlwr(ext);
					for (i = 0; i < fmt_cnt; i++) {
						if (!strcmp(ext, fmt[i].name))
							return fmt[i].format;
					}
				}
				break;
			} else if (*p >= 'A' && *p <= 'Z') {
				*p = *p - 'A' + 'a';
			}
		}
	}
	
	return fmt;
}


int _get_format_from_mem(const void *pImgMem, int memSize)
{
	char *pData = (char *)pImgMem;
	
	if (NULL == pData || memSize < 10)
	{
		return 0;
	}

	if (strncmp("BM", pData, strlen("BM")) == 0)
    {
        printf("BMP\n");
		return IMG_FMT_BMP;
    }	
	//if (strncmp("JFIF", pData + 6, strlen("JFIF")) == 0)
	if ((UChar)pData[0] == 0xFF && (UChar)pData[1] == 0xD8)
    {
        printf("JPEG\n");
		return IMG_FMT_JPG;
    }
    else if (strncmp("GIF89a", pData, strlen("GIF89a")) == 0 || strncmp("GIF87a", pData, strlen("GIF87a")) == 0)
    {
        printf("GIF\n");
		return IMG_FMT_GIF;
    }
    else if (strncmp("PNG", pData + 1, strlen("PNG")) == 0)
    {
        printf("PNG\n");
		return IMG_FMT_PNG;
    }
    else if (strncmp("II", pData, strlen("II")) == 0 || strncmp("MM", pData, strlen("MM")) == 0)
    {
        printf("TIF\n");
		return IMG_FMT_TIF;
    }
    else
    {
        printf("UNKNOW\n");
		return IMG_FMT_UNK;
    }

}

int IM_SaveImage(Image *pImage, char *pFileName)
{
	int quality = 90;
	int ret = 0, errCode = 0, format = 0;
	
	if (!pFileName || !pImage)
		return 0;
	
	format = _get_format_from_file(pFileName);
	
	switch (format)
	{
	case IMG_FMT_BMP:
		{
			switch (pImage->components)
			{
			case IMG_COMPONENT_GRAY:
				errCode = SaveImageBitmapGray((const char *)pFileName,pImage->pData, pImage->width, pImage->height);
				break;
			case IMG_COMPONENT_RGB:
				errCode = SaveImageBitmap((const char *)pFileName, pImage->pData, pImage->width, pImage->height,pImage->components);
				break;
			default:
				ret = -1;
				break;
			}		
		}
		break;
		
	case IMG_FMT_JPG:
		{
			switch (pImage->components)
			{
			case IMG_COMPONENT_GRAY:
				errCode = SaveImageJpeg((const char *)pFileName, pImage->pData, pImage->width, pImage->height,90, 1);
				//				errCode = SaveImageJpegGray((const char *)filename,
				//					pIEngine->pImage, pIEngine->width, pIEngine->height,
				//					pIEngine->quality);
				break;
			case IMG_COMPONENT_RGB:
				errCode = SaveImageJpeg((const char *)pFileName,pImage->pData, pImage->width, pImage->height, 90, pImage->components);
				break;
			default:
				ret = -1;
				break;
			}
		}
		break;
		
	default:
		ret = -1;
		break;
	}
	
	
	if (errCode == 1)
		ret = 1;
	
	return ret;
}

Int YM_SaveImage(BImage *pImage, Char *pFileName)
{
	Image img = {0};

	if (NULL == pImage || NULL == pFileName)
	{
		return 0;
	}

	img.pData = *(pImage->pixels);
    if(pImage->type ==8)
    {
        img.components = 3;
    }
    else if(pImage->type ==4)
    {
        img.components = 1;
    }
    else
    {
        return 0;
    }
	//img.components = (pImage->type == IMG_RGB) ? IMG_COMPONENT_RGB : IMG_COMPONENT_GRAY;
	img.width = pImage->width;
	img.height = pImage->height;

	return IM_SaveImage(&img, pFileName);

}

