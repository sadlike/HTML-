/*
 * write by ocean yu 2011.1
 */
#ifndef		__YUV420_CONVERT_H__
#define		__YUV420_CONVERT_H__

#ifdef		__cplusplus
extern "C" {
#endif

// This function convert RGB24 to YUV420
void Rgb24ToYuv420(unsigned char *pSrcRGB, unsigned char *pDesYUV, 
				   unsigned int nWidth, unsigned int nHeight);

// This function convert YUV422 planer to YUV420
void Yuv422Planer2Yuv420(unsigned char *pSrcYUV422, unsigned char *pDesYUV420,
						 unsigned int nWidth, unsigned int nHeight);

#ifdef		__cplusplus
}
#endif

#endif
