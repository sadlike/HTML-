#ifndef _IMAGE_API_H_
#define _IMAGE_API_H_

#include "imgdef.h"

// format
#define IMG_FMT_UNK			0
#define IMG_FMT_BMP			1
#define IMG_FMT_JPG			2
#define IMG_FMT_PNG			3
#define IMG_FMT_TIF			4
#define IMG_FMT_GIF			5

// component
#define IMG_COMPONENT_GRAY	1
#define IMG_COMPONENT_RGB	3

#ifndef _HC_COMMON_DATA_H
#define _HC_COMMON_DATA_H
#if defined D_API_EXPORTS
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif
typedef char	Char;
typedef unsigned char	UChar;

typedef short	Short;
typedef unsigned short	UShort;
#ifndef U_SHORT
#define U_SHORT
typedef unsigned short	Ushort;
#endif
typedef int	Int;
typedef unsigned int	UInt;

typedef long	Long;
typedef unsigned long	ULong;

typedef short	Sint;
typedef unsigned short	Suit;

typedef UChar	uch;
typedef UShort	ush;

typedef float   Float;
typedef UChar	SByte;


typedef struct T_Rect
{
    Short	lx;
    Short	ly;
    Short	rx;
    Short	ry;
}
TRect;

typedef struct B_Image {
    
    Short	width;
    Short	height;
    Short	xres;
    Short	yres;
    SByte	**pixels;
    
    UShort	type;
    UChar	status;
    UChar	key;
    
    Short x1, x2;	//
    Short y1, y2;	//
    TRect CropRect;//added by CZ for getting exact position in the end.20090205
    void  *ptr;		// can be used to pass user defined struct
    
    struct B_Image	*secImage;
    
    SByte	msk[24];
}BImage;
#endif
typedef struct _image
{
	uint_8  *pData;
	short   width;
	short   height;
	int     components;
}Image;

#ifdef __cplusplus
extern "C"
{
#endif

	Image *IM_LoadImageFile(char *pFilePath);
	Image *IM_LoadImageMem(char *pImgMem, int memSize);
	int IM_SaveImage(Image *pImage, char *pFileName);
    EXPORT Int YM_SaveImage(BImage *pImage, Char *pFileName);

#ifdef __cplusplus
};
#endif

#endif //_IMAGE_API_H_
