#include "HFX_imageIO.h"

void sc_error_exit (j_common_ptr cinfo)
{
	// cinfo->err really points to a my_error_mgr struct, so coerce pointer 
	sc_error_ptr scerr = (sc_error_ptr) cinfo->err;
	
	// Always display the message. 
	(*cinfo->err->output_message) (cinfo);
	
	// Return control to the setjmp point 
	longjmp(scerr->setjmp_buffer, 1);
}



puint_8 Hfx_LoadJPGFile(const char* filename, int *pWidth, int *pHeight)
{
	struct jpeg_decompress_struct cinfo;
	sc_error_mgr jerr;
	FILE * infile = NULL;		
	int row_stride,i,j;
	JSAMPLE **buffer = NULL;
	JSAMPLE *p = NULL; 
	int width, height, BytesPerLine;
	puint_8 pImg = NULL;
	int offset = 0;
	int index = 0;
	
	if ((infile = fopen(filename, "rb")) == NULL) 
	{
		printf("can't open %s\n");	
		return NULL;
	}
	
	// allocate and initialize JPEG decompression object 
	cinfo.err = jpeg_std_error(&jerr.pub);
	jerr.pub.error_exit = sc_error_exit;
	
	// Establish the setjmp return context for sc_error_exit to use. 
	if (setjmp(jerr.setjmp_buffer)) 
	{
		jpeg_destroy_decompress(&cinfo);
		fclose(infile);
		return NULL;
	}
	
	//initialize the JPEG decompression object. 
	jpeg_create_decompress(&cinfo);
	
	// specify data source (eg, a file) 
	jpeg_stdio_src(&cinfo, infile);
	
	//read file parameters with jpeg_read_header()
	(void) jpeg_read_header(&cinfo, TRUE);
	
	// set parameters for decompression 
	
	// To change any of the defaultsset by jpeg_read_header()
	// so so we here.
	
	
	//Start decompressor 
	(void) jpeg_start_decompress(&cinfo);
	
	height = cinfo.output_height;
	width = cinfo.output_width;
	BytesPerLine = cinfo.output_width;
	
	pImg = (puint_8)malloc(height * width * sizeof(uint_8));
	if (!pImg)
	{
		jpeg_destroy_decompress(&cinfo);
		fclose(infile);
		return NULL;
	}
	
	
	//JSAMPLEs per row in output buffer 
	//row_stride = cinfo.output_width * cinfo.output_components;
	row_stride = cinfo.output_width;
	buffer = (JSAMPLE **)calloc(1, sizeof(JSAMPLE*));
	if (!buffer)
	{
		jpeg_destroy_decompress(&cinfo);
		goto error_exit;	
	}
	
	buffer[0] = (JSAMPLE *)calloc(cinfo.output_width * cinfo.output_components, sizeof(JSAMPLE));
	if (!buffer[0])
	{
		jpeg_destroy_decompress(&cinfo);
		goto error_exit;	
	}
	
	// read data
	i = 0;
	while (cinfo.output_scanline < cinfo.output_height && i < height) 
	{
		(void) jpeg_read_scanlines(&cinfo, buffer, 1);
		if (cinfo.output_components == 3)
		{
			for (j = 0; j < width; j++)
			{
				index = 3 * j;
				pImg[offset + j] = (11 * buffer[0][index] + 59 * buffer[0][index + 1] + 30 * buffer[0][index + 2]) / 100;
			}
		}
		else
		{
			for(j = 0; j < width; j++)
			{
				pImg[offset + j] = buffer[0][j];
			}
		}
		offset += BytesPerLine;
		i++;
	}
	
	
//	(void) jpeg_finish_decompress(&cinfo);
	
	jpeg_destroy_decompress(&cinfo);

	if (buffer[0])
	{
		free(buffer[0]);
		buffer[0] = NULL;
	}

	if (buffer)
	{
		free(buffer);
		buffer = NULL;
	}
	
	
	if (infile)
	{
		fclose(infile);
		infile = NULL;
	}
	
	// At this point you may want to check to see whether any corrupt-data
	// warnings occurred (test whether jerr.pub.num_warnings is nonzero).
	
	if (pWidth)
		*pWidth = width;

	if (pHeight)
		*pHeight = height;
	
	return pImg;
	
error_exit:

	if (buffer[0])
	{
		free(buffer[0]);
		buffer[0] = NULL;
	}

	if (buffer)
	{
		free(buffer);
		buffer = NULL;
	}
	
   	if (infile)
	{
		fclose(infile);
		infile = NULL;
	}
	
	if (pImg)
	{
		free(pImg);
		pImg = NULL;
	}
	
	return NULL;
}


int get_property_from_jpg(const char *filename, int *pWidth, int *pHeight, int *pComponents)
{
	struct jpeg_decompress_struct cinfo;
	sc_error_mgr jerr;
	FILE * infile = NULL;
	int width, height, components;

	
	if ((infile = fopen(filename, "rb")) == NULL) 
	{
		printf("can't open %s\n");	
		return 0;
	}
	
	// allocate and initialize JPEG decompression object 
	cinfo.err = jpeg_std_error(&jerr.pub);
	jerr.pub.error_exit = sc_error_exit;
	
	// Establish the setjmp return context for sc_error_exit to use. 
	if (setjmp(jerr.setjmp_buffer)) 
	{
		jpeg_destroy_decompress(&cinfo);
		fclose(infile);
		return 0;
	}
	
	//initialize the JPEG decompression object. 
	jpeg_create_decompress(&cinfo);
	
	// specify data source (eg, a file) 
	jpeg_stdio_src(&cinfo, infile);
	
	//read file parameters with jpeg_read_header()
	(void) jpeg_read_header(&cinfo, TRUE);
	
	// set parameters for decompression 
	
	// To change any of the defaultsset by jpeg_read_header()
	// so so we here.
	
	
	//Start decompressor 
	(void) jpeg_start_decompress(&cinfo);
	

	width = cinfo.output_width;
	height = cinfo.output_height;
	components = cinfo.output_components;

	jpeg_destroy_decompress(&cinfo);
	if (infile)
	{
		fclose(infile);
		infile = NULL;
	}

	if (pWidth) *pWidth = width;
	if (pHeight) *pHeight = height;
	if (pComponents) *pComponents = components;

	return 1;
}


#ifdef Hfx_includeBMP
SCAN_IMAGE *Hfx_LoadBMPFile(char *filename)
{
	SCAN_IMAGE *BmpImage=NULL;
	FILE *fp;
	BITMAPFILEHEADER_H fileHeader;
	
	BITMAPINFOHEADER_H m_pBitmapInfo;
	BITMAPCOREHEADER_H *m_coreheader;
    unsigned char* m_pBits,pixel;
	unsigned long  dwBitsoff;
	
	int i,j,k,m,l;
	long bytepreline,imgbpreline;
	int num_colors;
	
	//	unsigned int  Offset;
	
    if((fp=fopen(filename,"rb")) == NULL)	
	{	
		return NULL;
	}
	
	/*
	m_pBitmapInfo = (BITMAPINFOHEADER_H *)HRW_malloc(sizeof(BITMAPINFOHEADER_H));
	
	  if(m_pBitmapInfo==NULL)
	  {
	  //	HRW_free(BmpImage);
	  //	BmpImage = NULL;
	  return(NULL);
	  }
	*/	
	i=sizeof(unsigned short);	
	
    j=sizeof(BITMAPFILEHEADER_H);
	fseek(fp,0,SEEK_SET);
	if(j>14)
	{
		//	if((fread(&fileHeader, 14,1,fp))!=1)
		//		return NULL;
		fread((void *)&fileHeader.bfType ,sizeof(unsigned short),1,fp);  
		
		//	fseek(fp,2,SEEK_SET);
		fread((void *)&fileHeader.bfSize ,sizeof(unsigned long),1,fp);  
		//	fseek(fp,6,SEEK_SET);
		fread((void *)&fileHeader.bfReserved1 ,sizeof(unsigned short),1,fp);  
		//	fseek(fp,8,SEEK_SET);
		fread((void *)&fileHeader.bfReserved2 ,sizeof(unsigned short),1,fp);  
		//	fseek(fp,10,SEEK_SET);
		fread((void *)&fileHeader.bfOffBits ,sizeof(unsigned long),1,fp);  
		
		
	}
	else
    {
		if((fread(&fileHeader, sizeof(BITMAPFILEHEADER_H),1,fp))!=1)
			return NULL;
    }
	
	if(fileHeader.bfType != 0x4d42)    // invalid bmp image
	{	
		return(NULL);
	}
	BmpImage = (SCAN_IMAGE *)HRW_malloc(sizeof(SCAN_IMAGE));
	if(BmpImage==NULL)
	{	
		return(NULL);
	}
	BmpImage->pixels=NULL;
	//read information header
    //  fseek(fp,sizeof(BITMAPFILEHEADER),SEEK_SET);
	if((fread(&m_pBitmapInfo, sizeof(BITMAPINFOHEADER_H),1,fp))!=1)
		//	  return NULL;
		goto error_exit;
	
	if(m_pBitmapInfo.biSize!=sizeof(BITMAPINFOHEADER_H))
	{
		//	HRW_free(m_pBitmapInfo);
		//    m_pBitmapInfo=NULL;
		m_coreheader=(BITMAPCOREHEADER_H*)&m_pBitmapInfo;
		//	return(NULL);		
		BmpImage->width=m_coreheader->bcWidth;
		BmpImage->height=m_coreheader->bcHeight;
		if(m_coreheader->bcBitCount>0)
		{
			num_colors = 2 << (m_coreheader->bcBitCount -1);
			dwBitsoff=sizeof(RGBTRIPLE_H)*num_colors;
			dwBitsoff+=m_coreheader->bcSize;
		}
		else
		{
			num_colors=0;
			dwBitsoff=m_coreheader->bcSize;
		}
		
	}
	else
	{
		if(m_pBitmapInfo.biCompression)
			goto error_exit;
		BmpImage->width=m_pBitmapInfo.biWidth;
		BmpImage->height=m_pBitmapInfo.biHeight;
		if(m_pBitmapInfo.biClrUsed == 0)
		{
			if(m_pBitmapInfo.biBitCount<24)
			{
				num_colors = 2 << (m_pBitmapInfo.biBitCount-1);
				dwBitsoff=sizeof(RGBQUAD_H)*num_colors;
				dwBitsoff+=m_pBitmapInfo.biSize;
			}
			else
			{
				num_colors=0;
				dwBitsoff=m_pBitmapInfo.biSize;
			}
		}
		else
		{
			num_colors = (unsigned short)m_pBitmapInfo.biClrUsed;
			dwBitsoff=sizeof(RGBQUAD_H)*num_colors;
			dwBitsoff+=m_pBitmapInfo.biSize;
		}
		
		
	}
	BmpImage->xres=300;
	BmpImage->yres=300;
	if(num_colors==2)
        BmpImage->ImageColor=2;
	else
		BmpImage->ImageColor=256;
	
	BmpImage->pixels=NULL;
	
	
	//	width = m_pBitmapInfo.biWidth;
	switch(num_colors)
	{
	case 2:
		bytepreline = ((BmpImage->width + 7 ) / 8 + 3) /4 * 4;		
		//	bytepreline = (((BmpImage->width) + 31) / 32 * 4);
		break;
	case 16:
		bytepreline= ((BmpImage->width + 1) / 2  + 3) /4 * 4;
		break;
	case 256:
		bytepreline = (BmpImage->width + 3) /4 * 4;
		break;
	case 0:
		bytepreline = (BmpImage->width * 3 + 3) /4 * 4;
		break;
	default:
		bytepreline=0;
		break;
	}
	if(bytepreline==0) goto error_exit;
	
	if(num_colors==2)
	{
		imgbpreline = ((BmpImage->width + 7 ) / 8 + 3) /4 * 4;
		
	}
	else
		imgbpreline=(BmpImage->width + 3) /4 * 4;
	
		  BmpImage->BytesPerLine=imgbpreline;
		  //		width = BmpImage->width;
		  
		  
		  if((BmpImage->pixels=(unsigned char **)HRW_malloc(sizeof(unsigned char *)*BmpImage->height))==NULL)
			  goto error_exit;
		  
		  for(i=0;i<BmpImage->height;i++)
		  {
			  
			  if((BmpImage->pixels[i]=(unsigned char *)HRW_malloc(sizeof(unsigned char )*imgbpreline))==NULL)
				  goto error_exit;
			  
			  
		  }
		  
		  if((m_pBits=(unsigned char *)HRW_malloc(sizeof(unsigned char)*bytepreline))==NULL)
			  goto error_exit;
		  //	dwBitsoff=fileHeader.bfOffBits+i*bytepreline;
		  //	fseek(fp,dwBitsoff,SEEK_SET);
		  //   	fseek(fp,fileHeader.bfOffBits,SEEK_SET);
		  fseek(fp,dwBitsoff+6,SEEK_SET);
		  fread(m_pBits, sizeof(unsigned char ),bytepreline,fp);
		  
		  dwBitsoff+=14;
		  fseek(fp,dwBitsoff,SEEK_SET);
		  for(i=0;i<BmpImage->height;i++)
		  {	
			  //		fseek(fp,dwBitsoff+i*bytepreline,SEEK_SET);
			  fread(m_pBits, sizeof(unsigned char ),bytepreline,fp);
			  if(num_colors==0)
			  {
				  m=BmpImage->height-1-i;
				  for(j=0,k=0;j<bytepreline ;j+=3,k++)
				  {
					  if(k>=imgbpreline)
						  break;
					  BmpImage->pixels[m][k]=(11*m_pBits[j]+59*m_pBits[j+1]+30*m_pBits[j+2])/100;
				  }
				  while(k<imgbpreline)
				  {
					  BmpImage->pixels[m][k]=255;
					  k++;
				  }
			  }
			  else if(num_colors==256)
			  {
				  m=BmpImage->height-1-i;
				  for(j=0,k=0;j<bytepreline ;j++,k++)
				  {
					  if(k>=imgbpreline)
						  break;
					  BmpImage->pixels[m][k]=m_pBits[j];
				  }
				  while(k<imgbpreline)
				  {
					  BmpImage->pixels[m][k]=255;
					  k++;
				  }
			  }
			  else if(num_colors==16)
			  {
				  m=BmpImage->height-1-i;
				  for(j=0,k=0;j<bytepreline ;j++,k++)
				  {
					  if(k>=imgbpreline-1)
						  break;
					  BmpImage->pixels[m][k]=m_pBits[j] & 0x0f;
					  BmpImage->pixels[m][k+1]=(m_pBits[j] & 0xf0)>>4;
				  }
				  while(k<imgbpreline)
				  {
					  BmpImage->pixels[m][k]=255;
					  k++;
				  }
			  }
			  else if(num_colors==2)
			  {
				  m=BmpImage->height-1-i;
				  for(j=0,k=0;j<bytepreline ;j++,k++)
				  {
					  if(k>=imgbpreline)
						  break;
					  BmpImage->pixels[m][k]=~m_pBits[j];
				  }
				  while(k<imgbpreline)
				  {
					  BmpImage->pixels[m][k]=255;
					  k++;
				  }
				  /*	l=BmpImage->height-1-i;		
				  k=0;
				  for(j=0;j<bytepreline ;j++)
				  {			
				  pixel = m_pBits[j];
		                for(m=0;m<8;m++,k++)
						{
						if(k>=BmpImage->width)
						break;
						if(((pixel>>m)&1))
						BmpImage->pixels[l][k] =255;
						else
						BmpImage->pixels[l][k] =0;
						}
						if(k>=BmpImage->width)
						break;
						}
						while(k<imgbpreline)
						{
						BmpImage->pixels[l][k]=255;
						k++;
						}
				  */
			  }
		  }
		  
		  fclose(fp);
		  
		  return(BmpImage);
		  
		  
error_exit:
		  if(BmpImage->pixels)
		  {
			  for(i=0;i<BmpImage->height;i++)
			  {
				  HRW_free(BmpImage->pixels[i]);
				  BmpImage->pixels[i]=NULL;
			  }
			  HRW_free(BmpImage->pixels);
			  BmpImage->pixels=NULL;
		  }
		  
		  HRW_free(BmpImage);
		  BmpImage=NULL;
		  
		  return NULL;
}
#endif
