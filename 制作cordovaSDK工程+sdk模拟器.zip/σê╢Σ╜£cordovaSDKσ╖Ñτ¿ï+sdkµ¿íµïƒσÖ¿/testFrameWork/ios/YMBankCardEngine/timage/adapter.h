#ifndef __ADAPTER_H__
#define __ADAPTER_H__

#include "imgdef.h"


#ifdef __cplusplus
extern "C" {
#endif


puint_8 LoadImageJpegGray(const char *filename, int *pWidth, int *pHeight);
puint_8 LoadImageFileJpeg(const char *filename, int *pWidth, int *pHeight, int *pComponents);
//puint_8 LoadImageFilePng(const char *filename, int *pWidth, int *pHeight, int *pComponents);
puint_8 LoadImageMemJpg(char *pImgMem, int imgSize, int *pWidth, int *pHeight, int *pComponents);
puint_8 LoadImageMemBmp(const char *pImgMem, int memSize, short *pWidth, short *pHeight, int *pComponents);
puint_8 LoadImageBitmapGray(const char *filename, int *pWidth, int *pHeight);
puint_8 LoadImageBitmap(const char *filename, int *pWidth, int *pHeight, int *pComponents);




int SaveImageBitmapGray(const char *filename, puint_8 pYDataBuf, int width, int height);
int SaveImageBitmap(const char *filename, puint_8 pDataBuf, 
					int width, int height, int components);

int SaveImageJpegGray(const char *filename, puint_8 pYDataBuf, int width, int height, int quality);
int SaveImageJpeg(const char *filename, puint_8 pDataBuf, int width, int height, int quality, int components);

#ifdef __cplusplus
}
#endif


#endif // __ADAPTER_H__