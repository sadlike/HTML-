//
//  WWPCacheManager.h
//  testPlugin
//
//  Created by wwp on 2018/11/9.
//

#import <Foundation/Foundation.h>
//#define BUNDLE_PATH [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:BundleName]
//
//#define ImageNamed(imageName)  ([UIImage imageNamed:[NSString stringWithFormat:@"%@/%@","WWPScanCardResourceBundle",imageName]])


@class YMIDCardEngine;
@interface WWPCacheManager : NSObject
@property(strong,nonatomic) YMIDCardEngine *ymIDCardEngine;
//识别证件类型
@property (assign, nonatomic) NSInteger idType;

- (NSString *)replaceUnicode:(NSString *)unicodeStr;
@end
extern  WWPCacheManager *hwSaveCache;

