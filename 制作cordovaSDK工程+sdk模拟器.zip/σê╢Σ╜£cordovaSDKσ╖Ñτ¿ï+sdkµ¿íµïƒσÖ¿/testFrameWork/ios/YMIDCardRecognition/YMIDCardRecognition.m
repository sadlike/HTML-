//
//  YMIDCardRecognition.m
//  IDCardScanDemo
//
//  Created by lincan on 14-04-01.
//
//

#import "YMIDCardRecognition.h"

@implementation YMIDCardRecognition

-(id)initWithImagePath:(NSString*)imagePath andChannelNumber:(NSString*)chNumberStr delegate:(id<YMIDCardRecognitionDelegate>)dge
{
    if (self=[super init])
    {
        _BCREngine = [[YMIDCardEngine alloc] init];
        _delegate = dge;
        _chRecNumberStr = chNumberStr;
        _recImagePath = imagePath;
        [NSThread detachNewThreadSelector:@selector(BCRThread) toTarget:self withObject:nil];
        
    }
    return self;
}

+(id)recongnitionWithImagePath:(NSString*)imagePath andChannelNumber:(NSString*)chNumberStr delegate:(id<YMIDCardRecognitionDelegate>)delegate
{
    return [[self alloc] initWithImagePath:(NSString*)imagePath andChannelNumber:chNumberStr delegate:delegate];
}


- (void)BCRThread
{
    
    //    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
//        [self.delegate setCancelProcess: NO];

    self.recogResultDic = [_BCREngine doBCRJSON_IDwithPicIndex:0];
    if (TRUE)
    {
        if (!self.recogResultDic)
        {
            if (self.delegate&&[self.delegate respondsToSelector:@selector(recongnition:didFailWithError:)])
            {
                NSString *msg = NSLocalizedString(@"没有识别结果，请确认这是身份证", nil);
                NSError *error = [NSError errorWithDomain:msg code:11 userInfo:nil];
                [self.delegate performSelector:@selector(recongnition:didFailWithError:) withObject:self withObject:error];
            }
        }else
        {
            if (self.delegate&&[self.delegate respondsToSelector:@selector(recongnition:didRecognitionResult:)])
            {
                [self.delegate performSelector:@selector(recongnition:didRecognitionResult:) withObject:self withObject:self.recogResultDic];
            }
        }
    }
    
    //    [pool release];
    
}


#pragma mark - callBack delegate
//- (void)progressCallbackWithValue:(NSInteger)value
//{
//    if (self.delegate&&[self.delegate respondsToSelector:@selector(progressCallbackWithValue:)])
//    {
//        [self.delegate progressCallbackWithValue:value];
//    }
//}
- (void)progressStop
{
    
}

@end

