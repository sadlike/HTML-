//
//  HarpyConstants.h
//  
//  Created by lincf on 15-05-17.
//  Copyright (c) 2014年 Mr.赵. All rights reserved.
//
//

/*
 Option 1 (DEFAULT): NO gives user option to update during next session launch
 Option 2: YES forces user to update app on launch
 */
static BOOL harpyForceUpdate = NO;

// 2. Your AppID (found in iTunes Connect)
#define kHarpyAppID                 @"972007482"

