/**
 * Created by wwp on 2018/9/11.
 */
var exec = require("cordova/exec");

function ScanCard() {};

ScanCard.prototype.scanCard = function (success,fail,option) {
    exec(success, fail, 'ScanCard', 'scanCardWithTypeCommand', option);
};

var wwpScanCard = new ScanCard();
module.exports = wwpScanCard;
