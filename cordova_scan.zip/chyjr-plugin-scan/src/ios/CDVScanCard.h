//
//  CDVScanCard.h
//  HelloWord
//
//  Created by wwp on 2018/9/11.
//

#import <Cordova/CDVPlugin.h>

@interface CDVScanCard : CDVPlugin

-(void)scanCard:(CDVInvokedUrlCommand *)command;

-(void)scanCardWithTypeCommand:(CDVInvokedUrlCommand *)command;
@end
