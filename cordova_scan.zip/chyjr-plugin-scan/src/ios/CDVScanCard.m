//
//  CDVScanCard.m
//  HelloWord
//
//  Created by wwp on 2018/9/11.
//

#import "CDVScanCard.h"
#import "YMIDCardEngine.h"
#import "CameraViewController.h"
#import "WWPCacheManager.h"
@implementation CDVScanCard
-(void)scanCard:(CDVInvokedUrlCommand *)command{
}
-(void)scanCardWithTypeCommand:(CDVInvokedUrlCommand *)command
{
    if (hwSaveCache==nil) {
        hwSaveCache = [[WWPCacheManager alloc]init];
        hwSaveCache.ymIDCardEngine =[[YMIDCardEngine alloc] init];
    }
    NSString *callBackID = command.callbackId;
    if(command.arguments.count>0){
        NSString *valueStr= [NSString stringWithFormat:@"%@",[command.arguments firstObject]];
        CameraViewController *cameraVC = [[CameraViewController alloc] init];
        switch ([valueStr integerValue]) {
            case 0: {
                hwSaveCache.idType = cardType_Bank;
                cameraVC.exIdCardIndex = cardType_Bank;
            }break;
            case 1:{
                hwSaveCache.idType = cardType_ID;
                cameraVC.exIdCardIndex = hwSaveCache.idType;
                hwSaveCache.ymIDCardEngine = [[YMIDCardEngine alloc] initWithLanguage:2 andIndex:hwSaveCache.idType andChannelNumber:@"yunmaiTY"];
                hwSaveCache.ymIDCardEngine.version = 2;
                if (hwSaveCache.ymIDCardEngine.engInitRet == engInitSuccess)  {
                    cameraVC.exIdCardIndex = cardType_ID;
                }
            }break;
            
            default:
            break;
        }
        __weak CDVScanCard *weakSelf = self;
        cameraVC.block = ^(NSDictionary *cameraDic) {
            NSString *str = [NSString stringWithFormat:@"%@",cameraDic];
            NSString *replaceStr = [hwSaveCache replaceUnicode:str];
            CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsString:replaceStr];
            [weakSelf.commandDelegate sendPluginResult:pluginResult callbackId:callBackID];
        };
        [self.viewController presentViewController:cameraVC animated:YES completion:^(void){}];
    }else{
        CDVPluginResult* pluginResult = [CDVPluginResult resultWithStatus:CDVCommandStatus_ERROR messageAsString:@"没有参数"];
        [self.commandDelegate sendPluginResult:pluginResult callbackId:callBackID];
    }
}

@end


