#include "adapter.h"
#include "HFX_imageIO.h"
#include "loadbmp.h"
#include "savebmp.h"
//#include "png.h"


puint_8 LoadImageJpegGray(const char *filename, int *pWidth, int *pHeight)
{
	return Hfx_LoadJPGFile(filename, pWidth, pHeight);
}

#if 0
puint_8 LoadImageFilePng(const char *filename, int *pWidth, int *pHeight, int *pComponents)
{
	png_struct *png_ptr=NULL;
	png_info *info_ptr=NULL;
	
	FILE *infile=NULL;
	
	//��PNG�ļ��Ľ���
	if ((infile = fopen(filename, "rb")) == NULL) 
	{
		fprintf(stderr, "can't open %s\n", filename);
		return NULL;
	}
	// create read struct
	png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, 0, 0, 0);
	// check pointer
	if (png_ptr == 0)
	{
		fclose(infile);
		return NULL;
	}
	// create info struct
	info_ptr = png_create_info_struct(png_ptr);
	// check pointer
	if (info_ptr == 0)
	{
		png_destroy_read_struct(&png_ptr, 0, 0);
		fclose(infile);
		return NULL;
	}
	// set error handling
	if (setjmp(png_jmpbuf(png_ptr)))
	{
		png_destroy_read_struct(&png_ptr, &info_ptr, 0);
		fclose(infile);
		return NULL;
	}
	// I/O initialization using standard C streams
	png_init_io(png_ptr, infile);
	
	// read entire image , ignore alpha channel�������Ҫʹ��alphaͨ�������PNG_TRANSFORM_STRIP_ALPHAȥ��
	png_read_png(png_ptr, info_ptr, PNG_TRANSFORM_EXPAND | PNG_TRANSFORM_STRIP_ALPHA, 0);
	
	*pWidth = info_ptr->width;
	*pHeight = info_ptr->height;
	
	if (info_ptr->color_type)
	{
		*pComponents = info_ptr->color_type;
	}
	//close file
	fclose(infile);

	return png_get_rows(png_ptr,info_ptr);
}
#endif

puint_8 LoadImageFileJpeg(const char *filename, int *pWidth, int *pHeight, int *pComponents)
{
	struct jpeg_decompress_struct cinfo;
	sc_error_mgr jerr;
	FILE * infile = NULL;		
	int row_stride, i;
	JSAMPLE **buffer = NULL;
	int width, height, BytesPerLine, scanW;
	puint_8 pImg = NULL;
	int offset = 0;
	int index = 0;
	
	if ((infile = fopen(filename, "rb")) == NULL) 
	{
		printf("can't open %s\n", filename);	
		return NULL;
	}
	
	// allocate and initialize JPEG decompression object 
	cinfo.err = jpeg_std_error(&jerr.pub);
	jerr.pub.error_exit = sc_error_exit;
	
	// Establish the setjmp return context for sc_error_exit to use. 
	if (setjmp(jerr.setjmp_buffer)) 
	{
		jpeg_destroy_decompress(&cinfo);
		fclose(infile);
		return NULL;
	}
	
	//initialize the JPEG decompression object. 
	jpeg_create_decompress(&cinfo);
	
	// specify data source (eg, a file) 
	jpeg_stdio_src(&cinfo, infile);
	
	//read file parameters with jpeg_read_header()
	(void) jpeg_read_header(&cinfo, TRUE);
	
	// set parameters for decompression 
	
	// To change any of the defaultsset by jpeg_read_header()
	// so so we here.
	
	
	//Start decompressor 
	(void) jpeg_start_decompress(&cinfo);
	
	height = cinfo.output_height;
	width = cinfo.output_width;
	BytesPerLine = cinfo.output_width;
	scanW = ((width*cinfo.output_components + 3) >> 2) << 2;	// bytes per line
	
	pImg = (puint_8)malloc(height * scanW);
	if (!pImg)
	{
		jpeg_destroy_decompress(&cinfo);
		fclose(infile);
		return NULL;
	}
	
	
	//JSAMPLEs per row in output buffer 
	//row_stride = cinfo.output_width * cinfo.output_components;
	row_stride = cinfo.output_width;
	buffer = (JSAMPLE **)calloc(1, sizeof(JSAMPLE*));
	if (!buffer)
	{
		jpeg_destroy_decompress(&cinfo);
		goto error_exit;	
	}
	
	buffer[0] = (JSAMPLE *)calloc(scanW, sizeof(JSAMPLE));
	if (!buffer[0])
	{
		jpeg_destroy_decompress(&cinfo);
		goto error_exit;	
	}
	
	// read data
	i = 0;
	if (cinfo.output_components == 3)
	{
		//index = 3 * width;
		while (cinfo.output_scanline < cinfo.output_height && i < height) 
		{
			int j;

			jpeg_read_scanlines(&cinfo, buffer, 1);
			//memcpy(pImg+offset, buffer[0], index);
			index = 0;
			for (j = 0; j < width; j++)
			{
				// swap R & B to suit for bitmap standard
				pImg[offset+index] = buffer[0][index+2];
				pImg[offset+index+1] = buffer[0][index+1];
				pImg[offset+index+2] = buffer[0][index];
				index += 3;
			}
			offset += scanW;
			i++;
		}
	}
	else
	{
		while (cinfo.output_scanline < cinfo.output_height && i < height) 
		{
			jpeg_read_scanlines(&cinfo, buffer, 1);
			memcpy(pImg+offset, buffer[0], width);
			
			offset += scanW;
			i++;
		}
	}
	
	
//	(void) jpeg_finish_decompress(&cinfo);
	
	jpeg_destroy_decompress(&cinfo);

	if (buffer[0])
	{
		free(buffer[0]);
		buffer[0] = NULL;
	}

	if (buffer)
	{
		free(buffer);
		buffer = NULL;
	}
	
	
	if (infile)
	{
		fclose(infile);
		infile = NULL;
	}
	
	// At this point you may want to check to see whether any corrupt-data
	// warnings occurred (test whether jerr.pub.num_warnings is nonzero).
	
	if (pWidth)
		*pWidth = width;

	if (pHeight)
		*pHeight = height;

	if (pComponents)
		*pComponents = cinfo.output_components;
	
	return pImg;
	
error_exit:

	if (buffer[0])
	{
		free(buffer[0]);
		buffer[0] = NULL;
	}

	if (buffer)
	{
		free(buffer);
		buffer = NULL;
	}
	
   	if (infile)
	{
		fclose(infile);
		infile = NULL;
	}
	
	if (pImg)
	{
		free(pImg);
		pImg = NULL;
	}
	
	return NULL;
}
#if 0
puint_8 LoadImageMemPng(char *pImgMem, int imgSize, int *pWidth, int *pHeight, int *pComponents)
{
	png_struct *png_ptr=NULL;
	png_info *info_ptr=NULL;
	
	// create read struct
	png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, 0, 0, 0);

	// check pointer
	if (png_ptr == 0)
	{
		return NULL;
	}

	// create info struct
	info_ptr = png_create_info_struct(png_ptr);
	// check pointer
	if (info_ptr == 0)
	{
		png_destroy_read_struct(&png_ptr, 0, 0);
		return NULL;
	}
	// set error handling
	if (setjmp(png_jmpbuf(png_ptr)))
	{
		png_destroy_read_struct(&png_ptr, &info_ptr, 0);
		return NULL;
	}

	// I/O initialization using standard C streams
	//png_init_io(png_ptr, infile);
	png_set_read_fn(png_ptr, (void *)pImgMem, png_push_fill_buffer);
	
	// read entire image , ignore alpha channel�������Ҫʹ��alphaͨ�������PNG_TRANSFORM_STRIP_ALPHAȥ��
	png_read_png(png_ptr, info_ptr, PNG_TRANSFORM_EXPAND | PNG_TRANSFORM_STRIP_ALPHA, 0);
	
	pWidth = info_ptr->width;
	pHeight = info_ptr->height;
	//PngImage->colors = info_ptr->color_type;
	//PngImage->bit_depth= info_ptr->pixel_depth;
	//PngImage->row_pointers = png_get_rows(png_ptr,info_ptr);
	// close file
	return (png_get_rows(png_ptr,info_ptr));
}
#endif

puint_8 LoadImageMemJpg(char *pImgMem, int imgSize, int *pWidth, int *pHeight, int *pComponents)
{
	struct jpeg_decompress_struct cinfo;
	sc_error_mgr jerr;
	FILE * infile = NULL;		
	int row_stride, i;
	JSAMPLE **buffer = NULL;
	JSAMPLE *p = NULL; 
	int width, height, BytesPerLine, scanW;
	puint_8 pImg = NULL;
	int offset = 0;
	int index = 0;
	FILE file;

	infile = &file;
	// allocate and initialize JPEG decompression object 
	cinfo.err = jpeg_std_error(&jerr.pub);
	jerr.pub.error_exit = sc_error_exit;
	
	// Establish the setjmp return context for sc_error_exit to use. 
	if (setjmp(jerr.setjmp_buffer)) 
	{
		jpeg_destroy_decompress(&cinfo);
		fclose(infile);
		return NULL;
	}
	
	//initialize the JPEG decompression object. 
	jpeg_create_decompress(&cinfo);
	
	// specify data source (eg, a file) 
	jpeg_stdio_src(&cinfo, infile);

	jpeg_buf_size(&cinfo, pImgMem, imgSize);


	//read file parameters with jpeg_read_header()
	(void) jpeg_read_header(&cinfo, TRUE);
	
	// set parameters for decompression 
	
	// To change any of the defaultsset by jpeg_read_header()
	// so so we here.
	
	
	//Start decompressor 
	(void) jpeg_start_decompress(&cinfo);
	
	height = cinfo.output_height;
	width = cinfo.output_width;
	BytesPerLine = cinfo.output_width;
	scanW = ((width*cinfo.output_components + 3) >> 2) << 2;	// bytes per line
	
	pImg = (puint_8)malloc(height * scanW);
	if (!pImg)
	{
		jpeg_destroy_decompress(&cinfo);
		fclose(infile);
		return NULL;
	}
	
	//JSAMPLEs per row in output buffer 
	//row_stride = cinfo.output_width * cinfo.output_components;
	row_stride = cinfo.output_width;
	buffer = (JSAMPLE **)calloc(1, sizeof(JSAMPLE*));
	if (!buffer)
	{
		jpeg_destroy_decompress(&cinfo);
		goto error_exit;	
	}
	
	buffer[0] = (JSAMPLE *)calloc(scanW, sizeof(JSAMPLE));
	if (!buffer[0])
	{
		jpeg_destroy_decompress(&cinfo);
		goto error_exit;	
	}
	
	// read data
	i = 0;
	if (cinfo.output_components == 3)
	{
		//index = 3 * width;
		while (cinfo.output_scanline < cinfo.output_height && i < height) 
		{
			int j;

			jpeg_read_scanlines(&cinfo, buffer, 1);
			//memcpy(pImg+offset, buffer[0], index);
			index = 0;
			for (j = 0; j < width; j++)
			{
				// swap R & B to suit for bitmap standard
				pImg[offset+index] = buffer[0][index+2];
				pImg[offset+index+1] = buffer[0][index+1];
				pImg[offset+index+2] = buffer[0][index];
				index += 3;
			}
			offset += scanW;
			i++;
		}
	}
	else
	{
		while (cinfo.output_scanline < cinfo.output_height && i < height) 
		{
			jpeg_read_scanlines(&cinfo, buffer, 1);
			memcpy(pImg+offset, buffer[0], width);
			
			offset += scanW;
			i++;
		}
	}
	
	
//	(void) jpeg_finish_decompress(&cinfo);
	
	jpeg_destroy_decompress(&cinfo);

	if (buffer[0])
	{
		free(buffer[0]);
		buffer[0] = NULL;
	}
	if (buffer)
	{
		free(buffer);
		buffer = NULL;
	}
	
//	if (infile)
//	{
//		fclose(infile);
//		infile = NULL;
//	}
	// At this point you may want to check to see whether any corrupt-data
	// warnings occurred (test whether jerr.pub.num_warnings is nonzero).
	
	if (pWidth)
		*pWidth = width;

	if (pHeight)
		*pHeight = height;

	if (pComponents)
		*pComponents = cinfo.output_components;
	
	return pImg;
	
error_exit:

	if (buffer[0])
	{
		free(buffer[0]);
		buffer[0] = NULL;
	}

	if (buffer)
	{
		free(buffer);
		buffer = NULL;
	}
	
   	if (infile)
	{
		fclose(infile);
		infile = NULL;
	}
	
	if (pImg)
	{
		free(pImg);
		pImg = NULL;
	}
	
	return NULL;
}



puint_8 LoadImageBitmapGray(const char *filename, int *pWidth, int *pHeight)
{
	return LoadImageBMP(filename, pWidth, pHeight);
}



puint_8 LoadImageBitmap(const char *filename, int *pWidth, int *pHeight, int *pComponents)
{
	char *pimg = NULL;
	int i;
	int width, height, components, bytes;
	unsigned char *pl;
	unsigned char *buf = NULL;

	FILE *fp = NULL;

	COMBITMAPFILEHEADER	ph;
	COMBITMAPINFOHEADER pi;
	unsigned char hbuf[100], *p;

	fp = fopen(filename, "rb");
	if (!fp)
		return NULL;

	fread(hbuf, 1, SIZE_BMPFILEHEADER, fp);

	p = &(hbuf[0]);
	memcpy(&(ph.bfType), p, 2); p += 2;
	memcpy(&(ph.bfSize), p, 4); p += 4;
	p += 4;
	memcpy(&(ph.bfOffBits), p, 4); p += 4;

	if (ph.bfType != 19778) 
	{
		printf("No bmp file\n");
		fclose(fp);
		return NULL;
	}

	fread(hbuf, 1, SIZE_BMPINFOHEADER, fp);

	p = &(hbuf[0]);
	memcpy(&(pi.biSize), p, 4); p += 4;
	memcpy(&(pi.biWidth), p, 4); p += 4;
	memcpy(&(pi.biHeight), p, 4); p += 4;
	memcpy(&(pi.biPlanes), p, 2); p += 2;
	memcpy(&(pi.biBitCount), p, 2); p += 2;
	memcpy(&(pi.biCompression), p, 4); p += 4;
	memcpy(&(pi.biSizeImage), p, 4); p += 4;
	memcpy(&(pi.biXPelsPerMeter), p, 4); p += 4;
	memcpy(&(pi.biYPelsPerMeter), p, 4); p += 4;
	memcpy(&(pi.biClrUsed), p, 4); p += 4;
	memcpy(&(pi.biClrImportant), p, 4); p += 4;

	fseek(fp, ph.bfOffBits, SEEK_SET);

	width = pi.biWidth;
	height = pi.biHeight;
	

	if (pi.biSize != 40 ||
		(pi.biBitCount != 8 && 
		pi.biBitCount != 24 &&
		pi.biBitCount != 32))
	{
		printf("biSize %d  biBitCount %d\n", pi.biSize, pi.biBitCount);
		fclose(fp);
		return NULL;
	}

	if (pi.biBitCount == 8)
	{
		components = 1;

		pimg = (char *)malloc(width * height);
		if (!pimg) {
			fclose(fp);
			return NULL;
		}

		pl = (unsigned char *)pimg + width*(height - 1);
		for (i = height - 1; i >= 0; i--)
		{
			fread(pl, 1, width, fp);
			pl -= width;
		}
	}
	else if (pi.biBitCount == 24)
	{
		components = 3;
		bytes = ((width*components + 3) >> 2) << 2;	// bytes per line

		pimg = (char *)malloc(bytes * height);
		if (!pimg) {
			fclose(fp);
			return NULL;
		}
		
		buf = (unsigned char *)malloc(bytes);
		if (!buf)
		{
			free(pimg);
			fclose(fp);
			return NULL;
		}

		pl = (unsigned char *)pimg + bytes*(height - 1);
		for (i = height - 1; i >= 0; i--)
		{
			fread(buf, 1, bytes, fp);
			memcpy(pl, buf, bytes);
			pl -= bytes;
		}
	}
	else if (pi.biBitCount == 32)
	{
		components = 4;
		bytes = ((width*components + 3) >> 2) << 2;	// bytes per line
		
		pimg = (char *)malloc(bytes * height);
		if (!pimg) {
			fclose(fp);
			return NULL;
		}
		
		buf = (unsigned char *)malloc(bytes);
		if (!buf)
		{
			free(pimg);
			fclose(fp);
			return NULL;
		}
		
		pl = (unsigned char *)pimg + bytes*(height - 1);
		for (i = height - 1; i >= 0; i--)
		{
			fread(buf, 1, bytes, fp);
			memcpy(pl, buf, bytes);
			pl -= bytes;
		}
	}
	else
	{
		printf("un-support\n");
		fclose(fp);
		return NULL;
	}


	if (buf)
	{
		free(buf);
		buf = NULL;
	}
	fclose(fp);

	if (pWidth)
		*pWidth = width;
	if (pHeight)
		*pHeight = height;
	if (pComponents)
		*pComponents = components;

	return (puint_8)pimg;
}

puint_8 LoadImageMemBmp(const char *pImgMem, int memSize, short *pWidth, short *pHeight, int *pComponents)
{
	char *pImgBuf = NULL;
	char *pimg = NULL;
	int i;
	int width, height, components, bytes;
	unsigned char *pl;
	unsigned char *buf = NULL;

	//FILE *fp = NULL;

	COMBITMAPFILEHEADER	ph;
	COMBITMAPINFOHEADER pi;
	unsigned char hbuf[100], *p;

	if (NULL == pImgMem)
	{
		return NULL;
	}
	pImgBuf = pImgMem;

	//fread(hbuf, 1, SIZE_BMPFILEHEADER, fp);
	memcpy(hbuf, pImgBuf, SIZE_BMPFILEHEADER);
	pImgBuf += SIZE_BMPFILEHEADER;


	p = &(hbuf[0]);
	memcpy(&(ph.bfType), p, 2); p += 2;
	memcpy(&(ph.bfSize), p, 4); p += 4;
	p += 4;
	memcpy(&(ph.bfOffBits), p, 4); p += 4;

	if (ph.bfType != 19778) 
	{
		printf("No bmp file\n");
		//fclose(fp);
		return NULL;
	}

	//fread(hbuf, 1, SIZE_BMPINFOHEADER, fp);
	memcpy(hbuf, pImgBuf, SIZE_BMPINFOHEADER);
	pImgBuf += SIZE_BMPINFOHEADER;

	p = &(hbuf[0]);
	memcpy(&(pi.biSize), p, 4); p += 4;
	memcpy(&(pi.biWidth), p, 4); p += 4;
	memcpy(&(pi.biHeight), p, 4); p += 4;
	memcpy(&(pi.biPlanes), p, 2); p += 2;
	memcpy(&(pi.biBitCount), p, 2); p += 2;
	memcpy(&(pi.biCompression), p, 4); p += 4;
	memcpy(&(pi.biSizeImage), p, 4); p += 4;
	memcpy(&(pi.biXPelsPerMeter), p, 4); p += 4;
	memcpy(&(pi.biYPelsPerMeter), p, 4); p += 4;
	memcpy(&(pi.biClrUsed), p, 4); p += 4;
	memcpy(&(pi.biClrImportant), p, 4); p += 4;

	//fseek(fp, ph.bfOffBits, SEEK_SET);
	pImgBuf = pImgMem;
	pImgBuf += ph.bfOffBits;


	width = pi.biWidth;
	height = pi.biHeight;
	

	if (pi.biSize != 40 ||
		(pi.biBitCount != 8 && 
		pi.biBitCount != 24 &&
		pi.biBitCount != 32))
	{
		printf("biSize %d  biBitCount %d\n", pi.biSize, pi.biBitCount);
		//fclose(fp);
		return NULL;
	}

	if (pi.biBitCount == 8)
	{
		components = 1;

		pimg = (char *)malloc(width * height);
		if (!pimg)
		{
			//fclose(fp);
			return NULL;
		}

		pl = (unsigned char *)pimg + width*(height - 1);
		for (i = height - 1; i >= 0; i--)
		{
			//fread(pl, 1, width, fp);
			memcpy(pl, pImgBuf, width);
			pImgBuf += width;
			pl -= width;
		}
	}
	else if (pi.biBitCount == 24)
	{
		components = 3;
		bytes = ((width*components + 3) >> 2) << 2;	// bytes per line

		pimg = (char *)malloc(bytes * height);
		if (!pimg)
		{
			//fclose(fp);
			return NULL;
		}
		
		buf = (unsigned char *)malloc(bytes);
		if (!buf)
		{
			free(pimg);
			//fclose(fp);
			return NULL;
		}

		pl = (unsigned char *)pimg + bytes*(height - 1);
		for (i = height - 1; i >= 0; i--)
		{
			//fread(buf, 1, bytes, fp);
			memcpy(buf, pImgBuf, bytes);
			pImgBuf += bytes;

			memcpy(pl, buf, bytes);
			pl -= bytes;
		}
	}
	else if (pi.biBitCount == 32)
	{
		components = 4;
		bytes = ((width*components + 3) >> 2) << 2;	// bytes per line
		
		pimg = (char *)malloc(bytes * height);
		if (!pimg)
		{
			//fclose(fp);
			return NULL;
		}
		
		buf = (unsigned char *)malloc(bytes);
		if (!buf)
		{
			free(pimg);
			//fclose(fp);
			return NULL;
		}
		
		pl = (unsigned char *)pimg + bytes*(height - 1);
		for (i = height - 1; i >= 0; i--)
		{
			//fread(buf, 1, bytes, fp);
			memcpy(buf, pImgBuf, bytes);
			pImgBuf += bytes;

			memcpy(pl, buf, bytes);
			pl -= bytes;
		}
	}
	else
	{
		printf("un-support\n");
		//fclose(fp);
		return NULL;
	}


	if (buf)
	{
		free(buf);
		buf = NULL;
	}
	//fclose(fp);

	if (pWidth)
		*pWidth = width;
	if (pHeight)
		*pHeight = height;
	if (pComponents)
		*pComponents = components;

	return (puint_8)pimg;
}
//////////////////////////////////////////////////////////////////////////
//

int SaveImageBitmapGray(const char *filename, puint_8 pYDataBuf, int width, int height)
{
	return SaveImageBMP(filename, (char *)pYDataBuf, width, height);
}


int SaveImageBitmap(const char *filename, puint_8 pRGB24, 
					int width, int height, int components)
{
	int wClrUsed, dwSize;
	int nScanWidth;
	int bitcount;
	FILE *file = NULL;
	COMBITMAPFILEHEADER bmfHdr = { 0 };
	COMBITMAPINFOHEADER bmpInfoHdr = { 0 };
	uint_8 buf[1024] = { 0 };
	puint_8 p = NULL;
	
	if (!pRGB24) return 0;
	
	// open file
	if (!(file = fopen(filename, "wb")))
	{
		return 0;
	}
	
	// save info of image
	bitcount = components << 3;
	bmfHdr.bfType = *(unsigned short *)"BM";
	nScanWidth = (width * components + 3) >> 2 << 2;
	
	
	wClrUsed = 0;
	if (components == 1) // 256 bit
		wClrUsed = 256;
	dwSize = SIZE_BMPINFOHEADER + wClrUsed * SIZE_RGBQUAD;
	
	bmpInfoHdr.biBitCount = bitcount;
	bmpInfoHdr.biClrImportant = 0;
	bmpInfoHdr.biClrUsed = wClrUsed;
	bmpInfoHdr.biCompression = 0;
	bmpInfoHdr.biHeight = height;
	bmpInfoHdr.biPlanes = 1;
	bmpInfoHdr.biSize = sizeof(bmpInfoHdr);
	bmpInfoHdr.biSizeImage = nScanWidth * height;
	bmpInfoHdr.biWidth = width;
	bmpInfoHdr.biXPelsPerMeter = 0;
	bmpInfoHdr.biYPelsPerMeter = 0;
	
	
	dwSize += bmpInfoHdr.biSizeImage;
	
	bmfHdr.bfSize = dwSize + sizeof(bmfHdr);
	bmfHdr.bfOffBits = SIZE_INFO + wClrUsed * SIZE_RGBQUAD;
	
	
	{
		p = buf;
		memcpy(p, &(bmfHdr.bfType), 2); p += 2;
		memcpy(p, &(bmfHdr.bfSize), 4); p += 4;
		memcpy(p, &(bmfHdr.bfReserved1), 2); p += 2;
		memcpy(p, &(bmfHdr.bfReserved2), 2); p += 2;
		memcpy(p, &(bmfHdr.bfOffBits), 4); p += 4;

		memcpy(p, &(bmpInfoHdr.biSize), 4); p += 4;
		memcpy(p, &(bmpInfoHdr.biWidth), 4); p += 4;
		memcpy(p, &(bmpInfoHdr.biHeight), 4); p += 4;
		memcpy(p, &(bmpInfoHdr.biPlanes), 2); p += 2;
		memcpy(p, &(bmpInfoHdr.biBitCount), 2); p += 2;
		memcpy(p, &(bmpInfoHdr.biCompression), 4); p += 4;
		memcpy(p, &(bmpInfoHdr.biSizeImage), 4); p += 4;
		memcpy(p, &(bmpInfoHdr.biXPelsPerMeter), 4); p += 4;
		memcpy(p, &(bmpInfoHdr.biYPelsPerMeter), 4); p += 4;
		memcpy(p, &(bmpInfoHdr.biClrUsed), 4); p += 4;
 		fwrite(buf, 1, SIZE_INFO, file);	// write file header

		
		{ 
			int i = 0;

			if (components == 1) // 256 bit
			{
				p = buf;
				for (i = 0; i < 256; i++)
				{
					*p++ = (uint_8)i;
					*p++ = (uint_8)i;
					*p++ = (uint_8)i;
					*p++ = (uint_8)0;
				}

				fwrite(buf, 1, 1024, file);
			}

			{ // flip
				p = pRGB24 + (height - 1) * nScanWidth;
				for (i = 0; i < height; i++) 
				{
					fwrite(p, 1, nScanWidth, file);
					p -= nScanWidth;
				}
			}
		}
	}
	
	// release related resource
	fclose(file);
	
	return 1;	// successfully
}



int SaveImageJpegGray(const char *filename, puint_8 pYDataBuf, 
					  int width, int height, int quality)
{
	struct jpeg_compress_struct cinfo;
	/* More stuff */
	FILE * outfile = NULL;			/* target file */
	//	int row_stride;			/* physical row width in image buffer */
	
	sc_error_mgr jerr;


	if (!filename || !pYDataBuf || width <= 0 
		|| height <= 0 || quality <= 0 || quality > 100)
		return 0;

	/* Step 1: allocate and initialize JPEG compression object */
	cinfo.err = jpeg_std_error(&jerr.pub);
	jerr.pub.error_exit = sc_error_exit;

	/* Establish the setjmp return context for my_error_exit to use. */
	if (setjmp(jerr.setjmp_buffer))
	{
		/* If we get here, the JPEG code has signaled an error.
		 * We need to clean up the JPEG object, close the input file, and return.
		 */

		jpeg_destroy_compress(&cinfo);

		if (outfile) {	
			fclose(outfile);
			outfile = NULL;
		}

		return 0;
	}

	/* Now we can initialize the JPEG compression object. */
	jpeg_create_compress(&cinfo);

	/* Step 2: specify data destination (eg, a file) */
	/* Note: steps 2 and 3 can be done in either order. */

	if ((outfile = fopen(filename, "wb")) == NULL)
	{
		//char buf[300];
		//sprintf(buf, "JpegFile :\nCan't open %s\n", fileName);

		return 0;
	}

	jpeg_stdio_dest(&cinfo, outfile);

	/* Step 3: set parameters for compression */
												    
	/* First we supply a description of the input image.
	 * Four fields of the cinfo struct must be filled in:
	 */
	cinfo.image_width = width; 	/* image width and height, in pixels */
	cinfo.image_height = height;

	//if (color)
	//{
	//	cinfo.input_components = 3;		/* # of color components per pixel */
	//	cinfo.in_color_space = JCS_RGB; 	/* colorspace of input image */
	//}
	//else
	{
		cinfo.input_components = 1;		/* # of color components per pixel */
		cinfo.in_color_space = JCS_GRAYSCALE; 	/* colorspace of input image */
	}

 
	/* Now use the library's routine to set default compression parameters.
     * (You must set at least cinfo.in_color_space before calling this,
     * since the defaults depend on the source color space.)
    */

	jpeg_set_defaults(&cinfo);
	/* Now you can set any non-default parameters you wish to.
	* Here we just illustrate the use of quality (quantization table) scaling:
	*/
	jpeg_set_quality(&cinfo, quality, 1 /* limit to baseline-JPEG values */);
	
	/* Step 4: Start compressor */
	
	/* TRUE ensures that we will write a complete interchange-JPEG file.
	* Pass TRUE unless you are very sure of what you're doing.
	*/
	jpeg_start_compress(&cinfo, 1);
	
	/* Step 5: while (scan lines remain to be written) */
	/*           jpeg_write_scanlines(...); */
	
	/* Here we use the library's state variable cinfo.next_scanline as the
	* loop counter, so that we don't have to keep track ourselves.
	* To keep things simple, we pass one scanline per call; you can pass
	* more if you wish, though.
	*/
	// row_stride = width * 3;	/* JSAMPLEs per row in image_buffer */
	
	while (cinfo.next_scanline < cinfo.image_height)
	{
    /* jpeg_write_scanlines expects an array of pointers to scanlines.
	* Here the array is only one element long, but you could pass
	* more than one scanline at a time if that's more convenient.
		*/
		unsigned char * outRow;
		
		//if (color)
		//{
		//	outRow = pYDataBuf + (cinfo.next_scanline * width * 3);
		//}
		//else
		{
			outRow = pYDataBuf + (cinfo.next_scanline * width);
		}
		
		(void) jpeg_write_scanlines(&cinfo, &outRow, 1);
	}
	
	/* Step 6: Finish compression */
	
	jpeg_finish_compress(&cinfo);
	
	/* After finish_compress, we can close the output file. */
	if (outfile) {
		fclose(outfile);
		outfile = NULL;
	}
	
	/* Step 7: release JPEG compression object */
	
	/* This is an important step since it will release a good deal of memory. */
	jpeg_destroy_compress(&cinfo);
	
	
	/* And we're done! */
	
	return 1;
}



int SaveImageJpeg(const char *filename, puint_8 pDataBuf, 
				  int width, int height, int quality, int components)
{
	struct jpeg_compress_struct cinfo;
	/* More stuff */
	FILE * outfile=NULL;			/* target file */
	int row_stride;			/* physical row width in image buffer */
	int offset;
	sc_error_mgr jerr;

	
	if (!filename || !pDataBuf || width <= 0 
		|| height <= 0 || quality <= 0 || quality > 100)
		return 0;

	/* Step 1: allocate and initialize JPEG compression object */
	cinfo.err = jpeg_std_error(&jerr.pub);
	jerr.pub.error_exit = sc_error_exit;

	/* Establish the setjmp return context for my_error_exit to use. */
	if (setjmp(jerr.setjmp_buffer))
	{
		/* If we get here, the JPEG code has signaled an error.
		 * We need to clean up the JPEG object, close the input file, and return.
		 */

		jpeg_destroy_compress(&cinfo);

		if (outfile) {	
			fclose(outfile);
			outfile = NULL;
		}

		return 0;
	}

	/* Now we can initialize the JPEG compression object. */
	jpeg_create_compress(&cinfo);

	/* Step 2: specify data destination (eg, a file) */
	/* Note: steps 2 and 3 can be done in either order. */

	if ((outfile = fopen(filename, "wb")) == NULL)
	{		
		return 0;
	}

	jpeg_stdio_dest(&cinfo, outfile);

	/* Step 3: set parameters for compression */
												    
	/* First we supply a description of the input image.
	 * Four fields of the cinfo struct must be filled in:
	 */
	cinfo.image_width = width; 	/* image width and height, in pixels */
	cinfo.image_height = height;

	if (components == 3)
	{
		cinfo.input_components = 3;		/* # of color components per pixel */
		cinfo.in_color_space = JCS_RGB; 	/* colorspace of input image */
	}
	else
	{
		cinfo.input_components = 1;		/* # of color components per pixel */
		cinfo.in_color_space = JCS_GRAYSCALE; 	/* colorspace of input image */
	}

 
	/* Now use the library's routine to set default compression parameters.
     * (You must set at least cinfo.in_color_space before calling this,
     * since the defaults depend on the source color space.)
    */

	jpeg_set_defaults(&cinfo);
	/* Now you can set any non-default parameters you wish to.
	* Here we just illustrate the use of quality (quantization table) scaling:
	*/
	jpeg_set_quality(&cinfo, quality, 1 /* limit to baseline-JPEG values */);
	
	/* Step 4: Start compressor */
	
	/* TRUE ensures that we will write a complete interchange-JPEG file.
	* Pass TRUE unless you are very sure of what you're doing.
	*/
	jpeg_start_compress(&cinfo, 1);
	
	/* Step 5: while (scan lines remain to be written) */
	/*           jpeg_write_scanlines(...); */
	
	/* Here we use the library's state variable cinfo.next_scanline as the
	* loop counter, so that we don't have to keep track ourselves.
	* To keep things simple, we pass one scanline per call; you can pass
	* more if you wish, though.
	*/
	row_stride = (width * components + 3) >> 2 << 2;	/* JSAMPLEs per row in image_buffer */
	offset = 0;
	while (cinfo.next_scanline < cinfo.image_height)
	{
		/* jpeg_write_scanlines expects an array of pointers to scanlines.
		 * Here the array is only one element long, but you could pass
		 * more than one scanline at a time if that's more convenient.
		 */
		unsigned char * outRow;
		
		if (components == 3)
		{
			int i;
			puint_8 p;
			uint_8 tmp;

			//outRow = pDataBuf + (cinfo.next_scanline * row_stride);
			outRow = pDataBuf + offset;
			p = outRow;
/*			for (i = 0; i < width; i++) {
				tmp = *p;
				*p = *(p+2);
				*(p+2) = tmp;
				p += 3;
			}
*/			
		}
		else
		{
			//outRow = pDataBuf + (cinfo.next_scanline * width);
			outRow = pDataBuf + offset;
		}
		
		(void) jpeg_write_scanlines(&cinfo, &outRow, 1);
		offset += row_stride;
	}
	
	/* Step 6: Finish compression */
	
	jpeg_finish_compress(&cinfo);
	
	/* After finish_compress, we can close the output file. */
	if (outfile) {
		fclose(outfile);
		outfile = NULL;
	}
	
	/* Step 7: release JPEG compression object */
	
	/* This is an important step since it will release a good deal of memory. */
	jpeg_destroy_compress(&cinfo);
	
	
	/* And we're done! */
	
	return 1;
}