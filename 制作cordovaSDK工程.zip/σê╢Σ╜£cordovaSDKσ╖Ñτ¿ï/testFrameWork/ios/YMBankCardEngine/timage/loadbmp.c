#include "loadbmp.h"
#include <memory.h>

/////////////////////////////////////////////////////////////////////////
//
//	Get bmp image
//
char *LoadImageBMP(const char *filename, int *pWidth, int *pHeight)
{
	char		*pimg = NULL;
	int		i;
	int		width, height, bytes;
	unsigned char *pl;
	unsigned char	*buf = NULL;

	FILE	*fp = NULL;

	COMBITMAPFILEHEADER	ph;
	COMBITMAPINFOHEADER pi;
	unsigned char	hbuf[100], *p;

	fp = fopen(filename, "rb");
	if (!fp)
		return NULL;

	fread(hbuf, 1, SIZE_BMPFILEHEADER, fp);

	p = &(hbuf[0]);
	memcpy(&(ph.bfType), p, 2); p += 2;
	memcpy(&(ph.bfSize), p, 4); p += 4;
	p += 4;
	memcpy(&(ph.bfOffBits), p, 4); p += 4;

	if (ph.bfType != 19778) 
	{
		printf("No bmp file\n");
		fclose(fp);
		return NULL;
	}

	fread(hbuf, 1, SIZE_BMPINFOHEADER, fp);

	p = &(hbuf[0]);
	memcpy(&(pi.biSize), p, 4); p += 4;
	memcpy(&(pi.biWidth), p, 4); p += 4;
	memcpy(&(pi.biHeight), p, 4); p += 4;
	memcpy(&(pi.biPlanes), p, 2); p += 2;
	memcpy(&(pi.biBitCount), p, 2); p += 2;
	memcpy(&(pi.biCompression), p, 4); p += 4;
	memcpy(&(pi.biSizeImage), p, 4); p += 4;
	memcpy(&(pi.biXPelsPerMeter), p, 4); p += 4;
	memcpy(&(pi.biYPelsPerMeter), p, 4); p += 4;
	memcpy(&(pi.biClrUsed), p, 4); p += 4;
	memcpy(&(pi.biClrImportant), p, 4); p += 4;

	fseek(fp, ph.bfOffBits, SEEK_SET);

	width = pi.biWidth;
	height = pi.biHeight;

	if (pi.biSize != 40 ||
		(pi.biBitCount != 8 && 
		pi.biBitCount != 24))
	{
		printf("biSize %d  biBitCount %d\n", pi.biSize, pi.biBitCount);
		fclose(fp);
		return NULL;
	}

	if (pi.biBitCount == 8)
	{
		pimg = (char *)malloc(width * height);
		if (!pimg) {
			fclose(fp);
			return NULL;
		}

		pl = (unsigned char *)pimg + width*(height - 1);
		for (i = height - 1; i >= 0; i--)
		{
			fread(pl, 1, width, fp);
			pl -= width;
		}
	}
	else if (pi.biBitCount == 24)
	{
		pimg = (char *)malloc(width * height);
		if (!pimg) {
			fclose(fp);
			return NULL;
		}

		bytes = ((width*3 + 3) >> 2) << 2;	// bytes per line
		buf = (unsigned char *)malloc(bytes);
		if (!buf)
		{
			free(pimg);
			fclose(fp);
			return NULL;
		}

		pl = (unsigned char *)pimg + width*(height - 1);
		for (i = height - 1; i >= 0; i--)
		{
			int		j;

			fread(buf, 1, bytes, fp);
			p = buf;
			for (j = 0; j < width; j++, p += 3)
			{	// 		  B 		  G		 	   R
				pl[j] = (p[0] * 11 + p[1] * 59 + p[2] * 30) / 100;
			}

			pl -= width;
		}
	}

	if (buf)
	{
		free(buf);
		buf = NULL;
	}
	fclose(fp);

	if (pWidth)
		*pWidth = width;
	if (pHeight)
		*pHeight = height;

	return pimg;
}



int get_property_from_bmp(const char *filename, 
						  int *pWidth, int *pHeight, 
						  int *pComponents)
{
	FILE *fp = NULL;
	int	width, height, components;
	
	
	COMBITMAPFILEHEADER	ph;
	COMBITMAPINFOHEADER pi;
	unsigned char hbuf[100] = { 0 }, *p;
	
	fp = fopen(filename, "rb");
	if (!fp)
		return 0;
	
	fread(hbuf, 1, SIZE_BMPFILEHEADER, fp);
	
	p = &(hbuf[0]);
	memcpy(&(ph.bfType), p, 2); p += 2;
	memcpy(&(ph.bfSize), p, 4); p += 4;
	p += 4;
	memcpy(&(ph.bfOffBits), p, 4); p += 4;
	
	if (ph.bfType != 19778) 
	{
		printf("No bmp file\n");
		fclose(fp);
		return 0;
	}
	
	fread(hbuf, 1, SIZE_BMPINFOHEADER, fp);
	
	p = &(hbuf[0]);
	memcpy(&(pi.biSize), p, 4); p += 4;
	memcpy(&(pi.biWidth), p, 4); p += 4;
	memcpy(&(pi.biHeight), p, 4); p += 4;
	memcpy(&(pi.biPlanes), p, 2); p += 2;
	memcpy(&(pi.biBitCount), p, 2); p += 2;

// 	memcpy(&(pi.biCompression), p, 4); p += 4;
// 	memcpy(&(pi.biSizeImage), p, 4); p += 4;
// 	memcpy(&(pi.biXPelsPerMeter), p, 4); p += 4;
// 	memcpy(&(pi.biYPelsPerMeter), p, 4); p += 4;
// 	memcpy(&(pi.biClrUsed), p, 4); p += 4;
// 	memcpy(&(pi.biClrImportant), p, 4); p += 4;
	
	
	width = pi.biWidth;
	height = pi.biHeight;
	components = pi.biBitCount>>3;

	fclose(fp);
	
	if (pWidth)
		*pWidth = width;
	if (pHeight)
		*pHeight = height;
	if (pComponents)
		*pComponents = components;

	return 1;
}