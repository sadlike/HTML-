#ifndef __INC_HfximageIO_H__
#define __INC_HfximageIO_H__

#include "imgdef.h"
#include "jinclude.h"
#include "jpeglib.h"
#include "jerror.h"
#include "setjmp.h"

typedef struct struct_error_mgr 
{
	struct jpeg_error_mgr pub;	// "public" fields 
	jmp_buf setjmp_buffer;	    // for return to caller 
} sc_error_mgr;

typedef struct struct_error_mgr * sc_error_ptr;

#ifdef __cplusplus
extern "C" {
#endif

void sc_error_exit (j_common_ptr cinfo);
puint_8 Hfx_LoadJPGFile(const char * filename, int *pWidth, int *pHeight);

int get_property_from_jpg(const char *filename, int *pWidth, int *pHeight, int *pComponents);

#ifdef __cplusplus
}
#endif


#endif // __INC_HfximageIO_H__