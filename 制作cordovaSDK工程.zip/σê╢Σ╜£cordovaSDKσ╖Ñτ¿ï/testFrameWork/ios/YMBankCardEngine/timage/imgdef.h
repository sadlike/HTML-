#ifndef __IMAGE_DEFINE_H__
#define __IMAGE_DEFINE_H__


#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#define SIZE_BMPFILEHEADER	14
#define SIZE_BMPINFOHEADER	40
#define SIZE_RGBQUAD		4
#define SIZE_INFO			(SIZE_BMPFILEHEADER + SIZE_BMPINFOHEADER)
typedef struct ComBITMAPFILEHEADER 
{ // bmfh 
	unsigned short	 bfType; 
	unsigned long    bfSize; 
	unsigned short   bfReserved1; 
	unsigned short   bfReserved2;	
	unsigned long    bfOffBits; 
} 
COMBITMAPFILEHEADER; 


typedef struct ComBITMAPINFOHEADER
{ // bmih 
    unsigned int  biSize; 
    signed int   biWidth; 
    signed int   biHeight; 
    unsigned short   biPlanes; 
    unsigned short   biBitCount; 
    unsigned int  biCompression; 
    unsigned int  biSizeImage; 
    signed int   biXPelsPerMeter; 
    signed int   biYPelsPerMeter; 
    unsigned int  biClrUsed; 
    unsigned int  biClrImportant; 
} 
COMBITMAPINFOHEADER; 

typedef struct ComRGBQUAD 
{ // rgbq 
    unsigned char    rgbBlue; 
    unsigned char    rgbGreen; 
    unsigned char    rgbRed; 
    unsigned char    rgbReserved; 
} 
COMRGBQUAD; 

typedef struct ComBITMAPINFO 
{ // bmi 
    COMBITMAPINFOHEADER bmiHeader; 
    COMRGBQUAD          bmiColors[1]; 
} 
COMBITMAPINFO; 





typedef unsigned char 				uint_8;
typedef uint_8 *					puint_8;

typedef unsigned short 				uint_16;
typedef uint_16 *					puint_16;

typedef unsigned long 				uint_32;
typedef uint_32 *					puint_32;


#define RGB565_MASK_RED    			0xf800
#define RGB565_MASK_GREEN  			0x07e0
#define RGB565_MASK_BLUE   			0x001f




#define ARRAY_SIZE(a)				(sizeof(a)/sizeof(a[0]))
#define SAFE_FREE(p)				if (p) { free(p); p=NULL; }
#define SCAN_WIDTH(w)				(((w)+3) >> 2 << 2)

#endif // __IMAGE_DEFINE_H__