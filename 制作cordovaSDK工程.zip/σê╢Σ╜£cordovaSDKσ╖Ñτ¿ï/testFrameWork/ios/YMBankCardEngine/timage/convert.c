#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "convert.h"

//

#define MY(a,b,c) (( a*  0.2989  + b*  0.5866  + c*  0.1145))
#define MU(a,b,c) (( a*(-0.1688) + b*(-0.3312) + c*  0.5000 + 128))
#define MV(a,b,c) (( a*  0.5000  + b*(-0.4184) + c*(-0.0816) + 128))

//
#define DY(a,b,c) (unsigned char)(MY(a,b,c) > 255 ? 255 : (MY(a,b,c) < 0 ? 0 : MY(a,b,c)))
#define DU(a,b,c) (unsigned char)(MU(a,b,c) > 255 ? 255 : (MU(a,b,c) < 0 ? 0 : MU(a,b,c)))
#define DV(a,b,c) (unsigned char)(MV(a,b,c) > 255 ? 255 : (MV(a,b,c) < 0 ? 0 : MV(a,b,c)))

// 
#define Yvalue(r, g, b) (unsigned char)(0.257*(r) + 0.504*(g) + 0.098*(b) + 16)
#define Uvalue(r, g, b) (unsigned char)(-0.148*(r) - 0.291*(g) + 0.439*(b) + 128)
#define Vvalue(r, g, b) (unsigned char)(0.439*(r) -0.368*(g) - 0.071*(b) + 128)

void Rgb24ToYuv420(unsigned char *pDesYUV, unsigned char *pSrcRGB, 
				   unsigned int nWidth, unsigned int nHeight)
{
	unsigned long i = 0;
	unsigned long j = 0;
	unsigned long nSrcSize = 0;
	unsigned long nDesPos = 0;
	unsigned long nSrcPos = 0;
	unsigned long wideStride = 0;
	unsigned long nTest = 0;
	static index = 0;
	unsigned char *pSrcRgbTmp = NULL;
	int k = 0;

 	//nWidth = ((nWidth + 3) >> 2) << 2;	
//	nWidth -= 1;
	nSrcSize = nWidth *nHeight*3;
	wideStride = (nWidth)*3;
	pSrcRgbTmp = pSrcRGB;

 //	pSrcRgbTmp = (unsigned char *)malloc(nWidth * nHeight * 3);


// 	for (i=0; i<nWidth*nHeight; i++)
// 	{
// 		if ((i+1) % nWidth == 0)
// 		{
// 			pSrcRgbTmp[i*3] = 0;
// 			pSrcRgbTmp[i*3+1] = 0;
// 			pSrcRgbTmp[i*3+2] = 0;				
// 		}
// 		else
// 		{
// 			pSrcRgbTmp[i*3] = pSrcRGB[j];
// 			pSrcRgbTmp[i*3+1] = pSrcRGB[j+1];
// 			pSrcRgbTmp[i*3+2] = pSrcRGB[j+2];	
// 			j+=3;
// 		}
// 	}
	// get Y value
	for (i = 0; i < nSrcSize; i += 3)
	{
		pDesYUV[nDesPos++] = DY(pSrcRgbTmp[i+2], pSrcRgbTmp[i+1], pSrcRgbTmp[i]);
	}
	

	// get U value
	for (i = 0; i < nHeight; i += 2)
	{
		nSrcPos = i*nWidth*3;
		
		for (j = 0; j < wideStride; j += 6)
		{
			pDesYUV[nDesPos++] = DU(pSrcRgbTmp[nSrcPos+j+2], pSrcRgbTmp[nSrcPos+j+1], pSrcRgbTmp[nSrcPos+j]);
//			pDesYUV[nDesPos++] = DV(pSrcRgbTmp[nSrcPos+j], pSrcRgbTmp[nSrcPos+j+1], pSrcRgbTmp[nSrcPos+j+2]);
 			pDesYUV[nDesPos++] = DV(pSrcRgbTmp[nSrcPos+j+2], pSrcRgbTmp[nSrcPos+j+1], pSrcRgbTmp[nSrcPos+j]);
		}
	}
	
	
// 	// get V value
// 	for (i = 0; i < nHeight; i += 2)
// 	{
// 		nSrcPos = i*nWidth*3;
// 
// 		for (j = 0; j < wideStride; j += 6)
// 		{
// 		}
// 	}
// 	
	//free(pSrcRgbTmp);
	return;
}


void Yuv422Planer2Yuv420(unsigned char *pSrcYUV422, unsigned char *pDesYUV420,
						 unsigned int width, unsigned int height)
{
	unsigned long index = 0;
	unsigned long i = 0;
	unsigned long j = 0;
	unsigned long nSrcPos = 0;
	unsigned long nDesPos = 0;
	unsigned long halfWidth = width>>1;
	unsigned long halfHeight = height>>1;

	// copy Y
	memcpy(pDesYUV420, pSrcYUV422, width*height);

	// copy U
	nSrcPos = width*height;
	nDesPos = width*height;

	for (index = 0; index < halfHeight; index++)
	{
		memcpy(pDesYUV420+nDesPos, pSrcYUV422+nSrcPos, halfWidth);
		nSrcPos += width;
		nDesPos += halfWidth;
	}
	
	// copy V
	for (index = 0; index < halfHeight; index++)
	{
		memcpy(pDesYUV420+nDesPos, pSrcYUV422+nSrcPos, halfWidth);
		nSrcPos += width;
		nDesPos += halfWidth;
	}

	return;
}