
/////////////////////////////////////////////////////////////////////////
//
//	File:		BCOCR.H
//  
//	Author:		TJH			
//
//	Purpose :	Define Bankcard  Recognization API Functions In The Application Moduler 
//
//	Date:		20141114
//
/////////////////////////////////////////////////////////////////////////

#ifndef _BC_OCR_H_
#define _BC_OCR_H_

#include "HCCommonData.h"

#ifdef __WIN_PLATFORM
#define D_API_EXPORTS
#endif
#undef EXPORT
#if defined D_API_EXPORTS
#define EXPORT __declspec(dllexport)
#else
#define EXPORT
#endif

#if defined(__cplusplus)
extern "C" {
#endif
	
	
	/////////////////////////////////////////////////////////////////////////
	//
	//	Function	
	//			Int YM_RecognizeMem_BK(char *pImgMem, int memSize, BCR_RESULT *pResult)
	//
	//			Bank card recognize by image data memory buffer stream
	//
	//	Return Value		
	//			An integer to indicate the status of bank card recognize. 
	//			0 - Fail;
	//			1 - Success.
	//
	//	Parameters
	//			pImgMem
	//					A pointer to the user-supplied buffer that contains 
	//					the data memory stream of image.
	//
	//			memSize	
	//					the size of data memory stream of image
	//		
	//			pReuslt	
	//					To save the result of bankcard image recognize 
	//		
	//
	/////////////////////////////////////////////////////////////////////////
	EXPORT Int YM_RecognizeMem_BK(char *pImgMem, int memSize, BCR_RESULT *pResult,char *pLicense);
	
	/////////////////////////////////////////////////////////////////////////
	//
	//	Function	
	//			Int YM_RecognizeFile_BK(char *pImgFilePath, BCR_RESULT *pResult
	//
	//			Bank card recognize by image file path
	//
	//	Return Value		
	//			An integer to indicate the status of bank card recognize. 
	//			0 - Fail;
	//			1 - Success.
	//
	//	Parameters
	//			pImgFilePath
	//					A pointer to the user-supplied buffer that contains 
	//					the path where image files stay.
	//
	//			pReuslt	
	//					To save the result of bankcard image recognize 
	//		
	//
	/////////////////////////////////////////////////////////////////////////
	EXPORT Int YM_RecognizeFile_1_BK(char *pImgFilePath, BCR_RESULT *pReuslt, char *pLicense);
#ifndef __IOS
	EXPORT Int YM_RecognizeFile_BK(char *pImgFilePath, char *pResult, int len, char *pLicense, char *pTrnImgFilePath);
#else
    //pImgFilePath：图片路径
    EXPORT Int YM_RecognizeFile_BK(char *pImgFilePath, char *BankResult, int len, char *pLicense, char *pTrnImgFilePath, char *pPathIos);
#endif
	EXPORT Int YM_RecognizeYuvImg_BK(char *pYuvMem, int width, int height, BCR_RESULT *pResult);
	
    //暂时弃用
	EXPORT Int YM_BCOCR_BK(BImage *pImage, BCR_RESULT *pReuslt, char *pLicense);
	
	EXPORT BImage *YM_LoadImage_BK(char *pImgMem, int memSize, char *pImgFilePath);

	EXPORT Int YM_SaveImage_BK(BImage *pImage, Char *pFileName);
	EXPORT Int YM_ClearGlobalData();

// 	
#if defined(__cplusplus)
}
#endif

#endif	// _BC_OCR_H_


