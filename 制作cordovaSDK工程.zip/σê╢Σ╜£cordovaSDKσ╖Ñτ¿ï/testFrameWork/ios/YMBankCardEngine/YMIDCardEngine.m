//
//  OCREngine.m
//  IDCardScanDemo
//
//  Created by  on 14-04-16.
//  Copyright (c) 2011年 __MyCompanyName__. All rights reserved.
//

#import "YMIDCardEngine.h"
#import "HCBCRTOPAPI.h"
#import "HCCommonAPI.h"
#import "HCDOCTOPAPI.h"
#import "HCCommonData.h"
#import "VedioRec.h"
#import "BCOCR.h"
#import "ImageApi.h"
#import "WWPUtils.h"
int progress_func(int progress, int relative);

@implementation YMIDCardEngine
@synthesize ocrLanguage;

id callbackDelegate = nil;
id bcrResultDelegate = nil;
id bcrFreeDelegate = nil;

int progress_value = 0;
BOOL bcr_canceled = NO;

int progress_func(int progress, int relative)
{
    if (progress == 0)
		return 1;
	
	if (relative == 0)
		progress_value = progress;
	else
		progress_value += progress;
	
	return 0;
}

//- (void)initCodePage {
//	
//	switch (ocrLanguage) {
//		case OCR_LAN_ENGLISH:
//			codePage = 0x7;
//			break;
//		case OCR_LAN_CHINESE:
//			codePage = 0x80000632;//gb
//			HC_SetChineseCode(_bcrEngine, OCR_CODE_GB);
////			HC_SetChineseCode(_ocrEngine, OCR_CODE_GB);
//			break;
//		case kOcrLangTraditionalChinese:
//			codePage = 0x80000A06;//b5
//			HC_SetChineseCode(_bcrEngine, OCR_CODE_B5);
////			HC_SetChineseCode(_ocrEngine, OCR_CODE_GB2B5);
//			break;
//		case OCR_LAN_EUROPEAN:
//			codePage = 0x1;
//			break;
//		case OCR_LAN_JAPAN:
//			codePage = 0x80000a01;
//			break;
//		default:
//			codePage = 0x80000632;//gb
//			break;
//	}
//}

int BcrResult_func(int bcrResult)
{
    [bcrResultDelegate bcrResultCallbackWithValue:bcrResult];
    return 1;
}

int BcrFree_func(int bcrFree)
{
    [bcrFreeDelegate bcrFreeCallbackWithFreeValue:bcrFree];
    return 1;
}

#pragma mark---银行卡识别

-(NSDictionary*)doBCR_BankWithImagePath:(NSString*)imagePath andChannelNumberStr:(NSString *)channelNumberStr withPicIndex:(NSInteger)picIndex
{
    int ret = -1;
    NSString *result = @"";
    char BankResult[1024] = {0};
    NSMutableDictionary *headDict = [NSMutableDictionary dictionary];
    NSString *iOSFileDirectStr = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    NSString *docs = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@%ld.jpg",@"_",(long)picIndex]];
    char *TrnImagePath = (char*)[docs cStringUsingEncoding:NSUTF8StringEncoding];
    char *chImagePath = (char*)[imagePath cStringUsingEncoding:NSUTF8StringEncoding];
    char *iOSFileDirect = (char*)[iOSFileDirectStr cStringUsingEncoding:NSUTF8StringEncoding];
    char *channelNumber = (char*)[channelNumberStr cStringUsingEncoding:NSUTF8StringEncoding];
    ret = YM_RecognizeFile_BK(chImagePath,BankResult,1024,channelNumber,TrnImagePath,iOSFileDirect);
    if (ret == 1)
    {
        result = [NSString stringWithCString:BankResult encoding:0x80000632];
        NSLog(@"=======%@,%d",result,ret);
        NSDictionary *retHeadDic = [self dictionaryWithJsonString:result];
        if ([retHeadDic objectForKey:@"Num"]) {
            [headDict setObject:[retHeadDic objectForKey:@"Num"] forKey:RESBANK_NUM];
        }
        if ([retHeadDic objectForKey:@"Bankname"]) {
            [headDict setObject:[retHeadDic objectForKey:@"Bankname"] forKey:RESBANK_BANKNAME];
        }
        if ([retHeadDic objectForKey:@"Cardname"]) {
            [headDict setObject:[retHeadDic objectForKey:@"Cardname"] forKey:RESBANK_CARDNAME];
        }
        if ([retHeadDic objectForKey:@"Cardtype"]) {
            [headDict setObject:[retHeadDic objectForKey:@"Cardtype"] forKey:RESBANK_CARDTYPE];
        }
        //NSData转换为UIImage
        NSData *imageData = [NSData dataWithContentsOfFile:docs];
        idCardImage = [UIImage imageWithData:imageData];
        if (idCardImage != NULL) {
            [headDict setObject:idCardImage forKey:RESBANK_IDIMAGE];
        }
    }
    
    [headDict setObject:[NSString stringWithFormat:@"%d",ret] forKey:RESBANK_RET];
    return headDict;
}

-(int)doBcrRecognizeVedioWithBuffer_BK:(UInt8 *)buffer andWidth:(int)width andHeight:(int)height andRect:(BRect)pRect andChannelNumberStr:(NSString *)channelNumberStr
{
    char *channelNumber = (char*)[channelNumberStr cStringUsingEncoding:NSUTF8StringEncoding];
    NSString *iOSFileDirectStr = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    char *iOSFileDirect = (char*)[iOSFileDirectStr cStringUsingEncoding:NSUTF8StringEncoding];
    int ret = YMVR_RecognizeVedio_BK(buffer, width, height, 0, &pRect, BcrResult_func,BcrFree_func,channelNumber,iOSFileDirect);
    return ret;
}

// 银行卡视频识别
- (NSDictionary *)doBCRWithRect_BK:(CGRect)rect
{
    int ret;
    //    char buf[1024]= {0};

    BCR_RESULT pBcrResult;
    bcr_canceled = NO;
    NSMutableDictionary *headDict = [NSMutableDictionary dictionaryWithCapacity:4];
    NSString *cardNo, *bankName, *cardName, *cardType;
    cardNo = bankName = cardName = cardType = @"";

    ret = YMVR_GetResult_BK(&pBcrResult);
    BImage *dupBimage = YMVR_GetTrnImage_BK();

    NSString *docs = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/bank.jpg"] ;
    int imageRet = YM_SaveImage_BK(dupBimage, (char*)[docs UTF8String]);
    
    idCardImage = [[UIImage alloc]initWithContentsOfFile:docs];
    
    if (dupBimage)
    {
        HC_freeImage_BK(NULL, &dupBimage);
        dupBimage = nil;
    }

    [self freeBImage];

    if (ret != 1)
    {
        return nil;
    }

    cardNo = [NSString stringWithCString:pBcrResult.text encoding:0x80000632];
    bankName = [NSString stringWithCString:pBcrResult.bankname encoding:0x80000632];
    cardName = [NSString stringWithCString:pBcrResult.cardname encoding:0x80000632];
    cardType = [NSString stringWithCString:pBcrResult.cardtype encoding:0x80000632];
    if (cardNo.length) {
        [headDict setObject:cardNo forKey:RESBANK_NUM];
    }
    if (bankName.length) {
        [headDict setObject:bankName forKey:RESBANK_BANKNAME];
    }
    if (cardName.length) {
        [headDict setObject:cardName forKey:RESBANK_CARDNAME];
    }
    if (cardType.length) {
        [headDict setObject:cardType forKey:RESBANK_CARDTYPE];
    }

    if (idCardImage != NULL) {
         BOOL saveSuccess =    [WWPUtils saveImgToPhoneWithImage:idCardImage];
        [headDict setObject:idCardImage forKey:RESBANK_IDIMAGE];
    }

    return headDict;
}

#pragma mark-- 车牌识别
/*
-(int)doBcrRecognizeVedioWith_CP:(UInt8 *)buffer andWidth:(int)width andHeight:(int)height andRect:(BRect)pRect andChannelNumberStr:(NSString *)channelNumberStr
{
    NSString *iOSFileDirectStr = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    char *iOSFileDirect = (char*)[iOSFileDirectStr cStringUsingEncoding:NSUTF8StringEncoding];
    char *channelNumber = (char*)[channelNumberStr cStringUsingEncoding:NSUTF8StringEncoding];
    int ret = YMVR_RecognizeVedio_CP(buffer, width, height, 0, &pRect, BcrResult_func, BcrFree_func,0,channelNumber,iOSFileDirect);
    return ret;
}

- (NSDictionary *)doBCRWithRect_CP:(CGRect)rect
{
    int ret;
    char buf[1024]= {0};
    BRect headRect;
    headRect.lx = 0;
    headRect.ly = 0;
    headRect.rx = 0;
    headRect.ry = 0;
    
    //    BCR_RESULT pBcrResult;
    bcr_canceled = NO;
    NSMutableDictionary *headDict = [NSMutableDictionary dictionaryWithCapacity:1];
    
    NSString *result = @"";
    
    ret = YMVR_GetResult_CP(buf,1024);
    
    _picImage = YMVR_CarImage_CP();
    NSString *docs = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/cp.jpg"] ;
    YM_SaveImage(_picImage,(char*)[docs UTF8String]);
    idCardImage = [[UIImage alloc]initWithContentsOfFile:docs];
    
    HC_freeImage_CP(_bcrEngine, &_bImage);
    _bImage = NULL;
    
    if (ret != 1)
    {
        [self closeEngine];
        return nil;
    }
    result = [NSString stringWithCString:buf encoding:0x80000632];
    
    result = [result stringByReplacingOccurrencesOfString:@"Color" withString:RESCP_COLOR];
    result = [result stringByReplacingOccurrencesOfString:@"Layer" withString:RESCP_LAYER];
    result = [result stringByReplacingOccurrencesOfString:@"Num" withString:RESCP_NUM];
    
    headDict = (NSMutableDictionary*)[self dictionaryWithJsonString_CP:result];
    
    if (idCardImage != NULL) {
        [headDict setObject:idCardImage forKey:RESCP_IDIMAGE];
    }
    return headDict;
}

- (NSDictionary *)doOCR_CPwithPicIndex:(NSInteger)picIndex {
    BField *bField = NULL;
    int ret;
    char buf[8192];
    NSString *iOSFileDirectStr = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    char *iOSFileDirect = (char*)[iOSFileDirectStr cStringUsingEncoding:NSUTF8StringEncoding];
    bcr_canceled = NO;
    NSString *docs0 = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@%ld.jpg",@"_",(long)picIndex]];
    
    YM_SaveImage(_bImage,(char*)[docs0 UTF8String]);
    idCardImage = [[UIImage alloc]initWithContentsOfFile:docs0];
    ret = HC_DoLineOCR_CP(_bcrEngine, _bImage, &bField, buf, 8192,iOSFileDirect);
    
    [self freeBImage];
    
    if (ret != 1)
    {
        if (bField != NULL) {
            [self freeBField:bField];
        }
        
        [self closeEngine];
        return nil;
    }
    
    NSString *result = @"";
    result = [NSString stringWithCString:buf encoding:0x80000632];
    
    [self freeBField:bField];
    [self closeEngine];
    
    result = [result stringByReplacingOccurrencesOfString:@"Color" withString:RESCP_COLOR];
    result = [result stringByReplacingOccurrencesOfString:@"Layer" withString:RESCP_LAYER];
    result = [result stringByReplacingOccurrencesOfString:@"Num" withString:RESCP_NUM];
    
    NSMutableDictionary *headDic = (NSMutableDictionary*)[self dictionaryWithJsonString_CP:result];
    
    NSLog(@"doBCRWithRect_CP=%@",headDic);
    
    if (idCardImage != NULL) {
        [headDic setObject:idCardImage forKey:RESCP_IDIMAGE];
    }
    return headDic;
}

- (NSDictionary *)dictionaryWithJsonString_CP:(NSString *)jsonString{
    jsonString = [jsonString stringByReplacingOccurrencesOfString:@"\r\n" withString:@""];
    jsonString = [jsonString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    jsonString = [jsonString stringByReplacingOccurrencesOfString:@"\t" withString:@""];
    
    if (jsonString == nil) {
        return nil;
    }
    //    NSString *str  = [NSString stringWithFormat:@"{%@}",jsonString];
    NSData * jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError * err;
    NSDictionary * dic = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableContainers error:&err];
    if (err) {
        NSLog(@"json解析失败: %@",err);
        return nil;
    }
    return dic;
}

- (void)ymClearAll_Plate
{
    YMClearAll_CP();
}
*/

#pragma mark---身份证识别

-(int)doBcrRecognizeVedioWith_ID:(UInt8 *)buffer andWidth:(int)width andHeight:(int)height andRect:(BRect)pRect andChannelNumberStr:(NSString *)channelNumberStr
{
    NSString *iOSFileDirectStr = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    char *iOSFileDirect = (char*)[iOSFileDirectStr cStringUsingEncoding:NSUTF8StringEncoding];
    char *channelNumber = (char*)[channelNumberStr cStringUsingEncoding:NSUTF8StringEncoding];
    int ret = HC_YMVR_RecognizeVedio_ID(buffer, width, height, 0, &pRect, BcrResult_func, BcrFree_func,channelNumber,iOSFileDirect,(Int)_version);
    return ret;
}

- (NSDictionary *)doBCR_IDwithPicIndex:(NSInteger)picIndex {
    BField *bField = NULL;
    NSMutableDictionary *headDict = [NSMutableDictionary dictionaryWithCapacity:1];
    int ret;
    
    NSString *iOSFileDirectStr = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    char *iOSFileDirect = (char*)[iOSFileDirectStr cStringUsingEncoding:NSUTF8StringEncoding];
    
    NSString *docs1 = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@%ld.jpg",@"_",(long)picIndex]];
    YM_SaveImage(_bImage, (char*)[docs1 UTF8String]);
    idCardImage = [[UIImage alloc] initWithContentsOfFile:docs1];
    ret = HC_DoImageBCR_ID(_bcrEngine, _bImage, &bField,iOSFileDirect);
    if (ret != 1)
    {
        [self freeBImage];
        if (bField != NULL) {
            [self freeBField:bField];
        }
        [self closeEngine];
        return nil;
    }
    
    if (bField) {
        NSString *docs2 = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/headid.jpg"]];
        BImage *pImagetemp = HC_IMG_DupTMastImage_ID(_bImage,&(bField->headImgRect));
        YM_SaveImage(pImagetemp, (char*)[docs2 UTF8String]);
        headImage = [[UIImage alloc] initWithContentsOfFile:docs2];
        if(pImagetemp) {
            HC_freeImage_ID(_bcrEngine, &pImagetemp);
            pImagetemp = nil;
        }
    }
    
    [self freeBImage];
    
    NSString *result = @"";
    result = [self makeArrayFromBFieldJSON_ID:bField];
    NSLog(@"==%@",result);
    
    [self freeBField:bField];
    
    [self closeEngine];
    
    NSDictionary *retHeadDic = [self dictionaryWithJsonString:result];
    
    if ([retHeadDic objectForKey:@"Name"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Name"] forKey:RESID_NAME];
    }
    if ([retHeadDic objectForKey:@"Sex"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Sex"] forKey:RESID_SEX];
    }
    if ([retHeadDic objectForKey:@"Folk"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Folk"] forKey:RESID_FOLK];
    }
    if ([retHeadDic objectForKey:@"Birthday"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Birthday"] forKey:RESID_BIRT];
    }
    if ([retHeadDic objectForKey:@"Address"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Address"] forKey:RESID_ADDRESS];
    }
    if ([retHeadDic objectForKey:@"CardNo"]) {
        [headDict setObject:[retHeadDic objectForKey:@"CardNo"] forKey:RESID_NUM];
    }
    if ([retHeadDic objectForKey:@"IssueAuthority"]) {
        [headDict setObject:[retHeadDic objectForKey:@"IssueAuthority"] forKey:RESID_ISSUE];
    }
    if ([retHeadDic objectForKey:@"ValidPeriod"]) {
        [headDict setObject:[retHeadDic objectForKey:@"ValidPeriod"] forKey:RESID_VALID];
    }
    if (idCardImage != NULL) {
        [headDict setObject:idCardImage forKey:RESID_IMAGE];
    }
    if (headImage != NULL) {
        [headDict setObject:headImage forKey:RESID_HEADIMAGE];
    }
    return headDict;
}

// 身份证识别
- (NSDictionary *)doBCRWithRect_ID:(CGRect)rect
{
    int ret;
    char buf[1024]= {0};
    BRect headRect;
    headRect.lx = 0;
    headRect.ly = 0;
    headRect.rx = 0;
    headRect.ry = 0;
    bcr_canceled = NO;
    NSMutableDictionary *headDict = [NSMutableDictionary dictionaryWithCapacity:1];
    NSString *result = @"";
    
    // ret = HC_YMVR_GetResult(buf,1024);
    ret = HC_YMVR_GetResult_ID(buf);
    
    //  _picImage = HC_YMVR_GetPicInfo();
    _picImage = HC_YMVR_GetPicInfo_ID();
    NSString *docs = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/idcard.jpg"] ;
    YM_SaveImage(_picImage,(char*)[docs UTF8String]);
    idCardImage = [[UIImage alloc]initWithContentsOfFile:docs];
    
    _headBImage = HC_YMVR_GetHeadInfo_ID();
    NSString *docsHead = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/idhead.jpg"] ;
    YM_SaveImage(_headBImage,(char*)[docsHead UTF8String]);
    headImage = [[UIImage alloc]initWithContentsOfFile:docsHead];
    
    HC_freeImage_ID(_bcrEngine, &_bImage);
    _bImage = NULL;
    
    if (_picImage)
    {
        HC_freeImage_ID(_bcrEngine, &_picImage);
        _picImage = NULL;
    }
    
    if (_headBImage)
    {
        HC_freeImage_ID(_bcrEngine, &_headBImage);
        _headBImage = NULL;
    }
    
    if (ret != 1)
    {
        [self closeEngine];
        return nil;
    }
    
    result = [NSString stringWithCString:buf encoding:0x80000632];
    NSLog(@"=======%@",result);
    NSDictionary *retHeadDic = [self dictionaryWithJsonString:result];
    
    if ([retHeadDic objectForKey:@"Name"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Name"] forKey:RESID_NAME];
    }
    if ([retHeadDic objectForKey:@"Sex"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Sex"] forKey:RESID_SEX];
    }
    if ([retHeadDic objectForKey:@"Folk"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Folk"] forKey:RESID_FOLK];
    }
    if ([retHeadDic objectForKey:@"Birthday"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Birthday"] forKey:RESID_BIRT];
    }
    if ([retHeadDic objectForKey:@"Address"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Address"] forKey:RESID_ADDRESS];
    }
    if ([retHeadDic objectForKey:@"CardNo"]) {
        [headDict setObject:[retHeadDic objectForKey:@"CardNo"] forKey:RESID_NUM];
    }
    if ([retHeadDic objectForKey:@"IssueAuthority"]) {
        [headDict setObject:[retHeadDic objectForKey:@"IssueAuthority"] forKey:RESID_ISSUE];
    }
    if ([retHeadDic objectForKey:@"ValidPeriod"]) {
        [headDict setObject:[retHeadDic objectForKey:@"ValidPeriod"] forKey:RESID_VALID];
    }
    if (idCardImage != NULL) {
       BOOL saveSuccess =    [WWPUtils saveImgToPhoneWithImage:idCardImage];
        [headDict setObject:idCardImage forKey:RESID_IMAGE];
    }
    if (headImage != NULL) {
        [headDict setObject:headImage forKey:RESID_HEADIMAGE];
    }
    return headDict;
}

- (NSString *)makeArrayFromBFieldJSON_ID:(BField *)field {
    char buf[8192]= {11};
    NSString *result = @"";
    int ret = HC_PrintFieldInfo_JSON_ID(_bcrEngine,field,buf,8192);
    NSLog(@"makeArrayFromBFieldJSON_ID=%d",ret);
    if (ret == 1) {
        result = [NSString stringWithCString:buf encoding:0x80000632];
    }
    return result;
}

- (void)ymClearAll_ID
{
    YMClearAll_ID();
}


#pragma mark---驾照识别
/*
-(int)doBcrRecognizeVedioWith_JZ:(UInt8 *)buffer andWidth:(int)width andHeight:(int)height andRect:(BRect)pRect andChannelNumberStr:(NSString *)channelNumberStr
{
    NSString *iOSFileDirectStr = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    char *channelNumber = (char*)[channelNumberStr cStringUsingEncoding:NSUTF8StringEncoding];
    char *iOSFileDirect = (char*)[iOSFileDirectStr cStringUsingEncoding:NSUTF8StringEncoding];
    int ret = HC_YMVR_RecognizeVedio_JZ(buffer, width, height, 0, &pRect, BcrResult_func, BcrFree_func,channelNumber,iOSFileDirect);
    return ret;
}

- (NSDictionary *)doBCRWithRect_JZ:(CGRect)rect
{
    int ret;
    char buf[1024]= {0};
    BRect headRect;
    BImage *_bImageTemp = NULL;
    headRect.lx = 0;
    headRect.ly = 0;
    headRect.rx = 0;
    headRect.ry = 0;
    bcr_canceled = NO;
    NSMutableDictionary *headDict = [NSMutableDictionary dictionary];
    NSString *result = @"";
    
    ret = HC_YMVR_GetResult_JZ(buf);
    
    _bImageTemp = HC_YMVR_ImageNew_JZ();
    NSString *docs = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/jz.jpg"] ;
    YM_SaveImage(_bImageTemp,(char*)[docs UTF8String]);
    idCardImage = [[UIImage alloc]initWithContentsOfFile:docs];
    
    //    if (_bImageTemp)
    //    {
    //        HC_freeImage(_bcrEngine, &_bImageTemp);
    //        _bImageTemp = NULL;
    //    }
    
    if (_bImage)
    {
        HC_freeImage_JZ(_bcrEngine, &_bImage);
        _bImage = NULL;
    }
    if (ret != 1)
    {
        [self closeEngine];
        return nil;
    }
    result = [NSString stringWithCString:buf encoding:0x80000632];
    NSDictionary *retHeadDic = [self dictionaryWithJsonString:result];
    if ([retHeadDic objectForKey:@"Name"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Name"] forKey:RESJZ_NAME];
    }
    if ([retHeadDic objectForKey:@"CardNo."]) {
        [headDict setObject:[retHeadDic objectForKey:@"CardNo."] forKey:RESJZ_CARDNO];
    }
    if ([retHeadDic objectForKey:@"Sex"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Sex"] forKey:RESJZ_SEX];
    }
    if ([retHeadDic objectForKey:@"Birthday"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Birthday"] forKey:RESJZ_BIRTHDAY];
    }
    if ([retHeadDic objectForKey:@"Address"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Address"] forKey:RESJZ_ADDRESS];
    }
    if ([retHeadDic objectForKey:@"IssueDate"]) {
        [headDict setObject:[retHeadDic objectForKey:@"IssueDate"] forKey:RESJZ_ISSUE_DATE];
    }
    if ([retHeadDic objectForKey:@"ValidPeriod"]) {
        [headDict setObject:[retHeadDic objectForKey:@"ValidPeriod"] forKey:RESJZ_VALID_PERIOD];
    }
    if ([retHeadDic objectForKey:@"Nation"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Nation"] forKey:RESJZ_COUNTRY];
    }
    if ([retHeadDic objectForKey:@"DrivingType"]) {
        [headDict setObject:[retHeadDic objectForKey:@"DrivingType"] forKey:RESJZ_DRIVING_TYPE];
    }
    if ([retHeadDic objectForKey:@"RegisterDate"]) {
        [headDict setObject:[retHeadDic objectForKey:@"RegisterDate"] forKey:RESJZ_REGISTER_DATE];
    }
    if (idCardImage != NULL) {
        [headDict setObject:idCardImage forKey:RESJZ_IDIMAGE];
    }
    return headDict;
}

- (NSDictionary *)doBCR_JZwithPicIndex:(NSInteger)picIndex{
    BField *bField = NULL;
    int ret;
    
    NSString *docs1 = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@%ld.jpg",@"_",(long)picIndex]];
    
    YM_SaveImage(_bImage, (char*)[docs1 UTF8String]);
    idCardImage = [[UIImage alloc] initWithContentsOfFile:docs1];
    ret = HC_DoImageBCR_JZ(_bcrEngine, _bImage, &bField);
    
    [self freeBImage];
    
    if (ret != 1)
    {
        if (bField != NULL) {
            [self freeBField:bField];
        }
        [self closeEngine];
        return nil;
    }
    
    NSString *result = @"";
    NSMutableDictionary *headDict = [NSMutableDictionary dictionary];
    result = [self makeArrayFromBFieldJSON_JZ:bField];
    [self freeBField:bField];
    [self closeEngine];
    
    NSDictionary *retHeadDic = [self dictionaryWithJsonString:result];
    
    if ([retHeadDic objectForKey:@"Name"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Name"] forKey:RESJZ_NAME];
    }
    if ([retHeadDic objectForKey:@"CardNo."]) {
        [headDict setObject:[retHeadDic objectForKey:@"CardNo."] forKey:RESJZ_CARDNO];
    }
    if ([retHeadDic objectForKey:@"Sex"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Sex"] forKey:RESJZ_SEX];
    }
    if ([retHeadDic objectForKey:@"Birthday"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Birthday"] forKey:RESJZ_BIRTHDAY];
    }
    if ([retHeadDic objectForKey:@"Address"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Address"] forKey:RESJZ_ADDRESS];
    }
    if ([retHeadDic objectForKey:@"IssueDate"]) {
        [headDict setObject:[retHeadDic objectForKey:@"IssueDate"] forKey:RESJZ_ISSUE_DATE];
    }
    if ([retHeadDic objectForKey:@"ValidPeriod"]) {
        [headDict setObject:[retHeadDic objectForKey:@"ValidPeriod"] forKey:RESJZ_VALID_PERIOD];
    }
    if ([retHeadDic objectForKey:@"Nation"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Nation"] forKey:RESJZ_COUNTRY];
    }
    if ([retHeadDic objectForKey:@"DrivingType"]) {
        [headDict setObject:[retHeadDic objectForKey:@"DrivingType"] forKey:RESJZ_DRIVING_TYPE];
    }
    if ([retHeadDic objectForKey:@"RegisterDate"]) {
        [headDict setObject:[retHeadDic objectForKey:@"RegisterDate"] forKey:RESJZ_REGISTER_DATE];
    }
    if (idCardImage != NULL) {
        [headDict setObject:idCardImage forKey:RESJZ_IDIMAGE];
    }
    return headDict;
}

- (NSString *)makeArrayFromBFieldJSON_JZ:(BField *)field {
    char buf[8192]= {11};
    NSString *result = @"";
    int ret = HC_PrintFieldInfo_JSON_JZ(_bcrEngine,field,buf,8192);
    NSLog(@"makeArrayFromBFieldJSON_JZ=%d",ret);
    if (ret == 1) {
        result = [NSString stringWithCString:buf encoding:0x80000632];
    }
    return result;
}
 */

#pragma -mark --行驶证识别
/*
-(int)doBcrRecognizeVedioWith_XS:(UInt8 *)buffer andWidth:(int)width andHeight:(int)height andRect:(BRect)pRect andChannelNumberStr:(NSString *)channelNumberStr
{
    NSString *iOSFileDirectStr = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    char *channelNumber = (char*)[channelNumberStr cStringUsingEncoding:NSUTF8StringEncoding];
    char *iOSFileDirect = (char*)[iOSFileDirectStr cStringUsingEncoding:NSUTF8StringEncoding];
    int ret = HC_YMVR_RecognizeVedio_XS(buffer, width, height, 0, &pRect, BcrResult_func, BcrFree_func,channelNumber,iOSFileDirect);
    return ret;
}

- (NSDictionary *)doBCR_XSwithPicIndex:(NSInteger)picIndex{
    BField *bField = NULL;
    int ret;
    
    NSString *docs1 = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@%ld.jpg",@"_",(long)picIndex]];
    
    YM_SaveImage_BK(_bImage, (char*)[docs1 UTF8String]);
    idCardImage = [[UIImage alloc] initWithContentsOfFile:docs1];
    ret = HC_DoImageBCR_XS(_bcrEngine, _bImage, &bField);
    
    [self freeBImage];
    
    if (ret != 1)
    {
        if (bField != NULL) {
            [self freeBField:bField];
        }
        [self closeEngine];
        return nil;
    }
    
    NSString *result = @"";
    NSMutableDictionary *headDict = [NSMutableDictionary dictionary];
    result = [self makeArrayFromBFieldJSON_XS:bField];
    [self freeBField:bField];
    [self closeEngine];
    
    NSDictionary *retHeadDic = [self dictionaryWithJsonString:result];
    
    if ([retHeadDic objectForKey:@"Name"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Name"] forKey:RESXS_NAME];
    }
    if ([retHeadDic objectForKey:@"CardNo."]) {
        [headDict setObject:[retHeadDic objectForKey:@"CardNo."] forKey:RESXS_CARDNO];
    }
    if ([retHeadDic objectForKey:@"Address"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Address"] forKey:RESXS_ADDRESS];
    }
    if ([retHeadDic objectForKey:@"VehicleType"]) {
        [headDict setObject:[retHeadDic objectForKey:@"VehicleType"] forKey:RESXS_VEHICLETYPE];
    }
    if ([retHeadDic objectForKey:@"UseCharacte"]) {
        [headDict setObject:[retHeadDic objectForKey:@"UseCharacte"] forKey:RESXS_USECHARACTE];
    }
    if ([retHeadDic objectForKey:@"Model"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Model"] forKey:RESXS_MODEL];
    }
    if ([retHeadDic objectForKey:@"Vin"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Vin"] forKey:RESXS_VIN];
    }
    if ([retHeadDic objectForKey:@"EnginePN"]) {
        [headDict setObject:[retHeadDic objectForKey:@"EnginePN"] forKey:RESXS_ENGINEPN];
    }
    if ([retHeadDic objectForKey:@"RegisterDate"]) {
        [headDict setObject:[retHeadDic objectForKey:@"RegisterDate"] forKey:RESXS_REGISTERDATE];
    }
    if ([retHeadDic objectForKey:@"IssueDate"]) {
        [headDict setObject:[retHeadDic objectForKey:@"IssueDate"] forKey:RESXS_ISSUEDATE];
    }
    if ([retHeadDic objectForKey:@"FileNo."]) {
        [headDict setObject:[retHeadDic objectForKey:@"FileNo."] forKey:RESXS_ISSUEDATE];
    }
    if ([retHeadDic objectForKey:@"Record"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Record"] forKey:RESXS_FILENO];
    }
    if ([retHeadDic objectForKey:@"ApprovedNo."]) {
        [headDict setObject:[retHeadDic objectForKey:@"ApprovedNo."] forKey:RESXS_APPROVEDNO];
    }
    if ([retHeadDic objectForKey:@"TotalQuality"]) {
        [headDict setObject:[retHeadDic objectForKey:@"TotalQuality"] forKey:RESXS_TOTALQUALITY];
    }
    if ([retHeadDic objectForKey:@"CurbWeight"]) {
        [headDict setObject:[retHeadDic objectForKey:@"CurbWeight"] forKey:RESXS_CURBWEIGHT];
    }
    if ([retHeadDic objectForKey:@"ApprovedQuality"]) {
        [headDict setObject:[retHeadDic objectForKey:@"ApprovedQuality"] forKey:RESXS_APPROVEDQUALITY];
    }
    if ([retHeadDic objectForKey:@"Size"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Size"] forKey:RESXS_SIZE];
    }
    if ([retHeadDic objectForKey:@"TractQuality"]) {
        [headDict setObject:[retHeadDic objectForKey:@"TractQuality"] forKey:RESXS_TRACTQUALITY];
    }
    if ([retHeadDic objectForKey:@"Note"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Note"] forKey:RESXS_NOTE];
    }
    
    if (idCardImage != NULL) {
        [headDict setObject:idCardImage forKey:RESXS_IDIMAGE];
    }
    return headDict;
}

// 行驶证视频识别
- (NSDictionary *)doBCRWithRect_XS:(CGRect)rect
{
    int ret;
    char buf[1024]= {0};
    BRect headRect;
    BImage *_bImageTemp = NULL;
    headRect.lx = 0;
    headRect.ly = 0;
    headRect.rx = 0;
    headRect.ry = 0;
    bcr_canceled = NO;
    NSMutableDictionary *headDict = [NSMutableDictionary dictionary];
    NSString *result = @"";
    
    ret = HC_YMVR_GetResult_XS(buf);
    
    _bImageTemp = HC_YMVR_ImageNew_XS();
    NSString *docs = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/XS.jpg"] ;
    YM_SaveImage_BK(_bImageTemp,(char*)[docs UTF8String]);
    idCardImage = [[UIImage alloc]initWithContentsOfFile:docs];
    
    //    if (_bImageTemp)
    //    {
    //        HC_freeImage(_bcrEngine, &_bImageTemp);
    //        _bImageTemp = NULL;
    //    }
    
    if (_bImage)
    {
        HC_freeImage_XS(_bcrEngine, &_bImage);
        _bImage = NULL;
    }
    
    if (ret != 1)
    {
        [self closeEngine];
        return nil;
    }
    result = [NSString stringWithCString:buf encoding:0x80000632];
    NSDictionary *retHeadDic = [self dictionaryWithJsonString:result];
    NSLog(@"doBCRWithRect_XS=%@",retHeadDic);
    if ([retHeadDic objectForKey:@"Name"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Name"] forKey:RESXS_NAME];
    }
    if ([retHeadDic objectForKey:@"CardNo."]) {
        [headDict setObject:[retHeadDic objectForKey:@"CardNo."] forKey:RESXS_CARDNO];
    }
    if ([retHeadDic objectForKey:@"Address"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Address"] forKey:RESXS_ADDRESS];
    }
    if ([retHeadDic objectForKey:@"VehicleType"]) {
        [headDict setObject:[retHeadDic objectForKey:@"VehicleType"] forKey:RESXS_VEHICLETYPE];
    }
    if ([retHeadDic objectForKey:@"UseCharacte"]) {
        [headDict setObject:[retHeadDic objectForKey:@"UseCharacte"] forKey:RESXS_USECHARACTE];
    }
    if ([retHeadDic objectForKey:@"Model"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Model"] forKey:RESXS_MODEL];
    }
    if ([retHeadDic objectForKey:@"Vin"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Vin"] forKey:RESXS_VIN];
    }
    if ([retHeadDic objectForKey:@"EnginePN"]) {
        [headDict setObject:[retHeadDic objectForKey:@"EnginePN"] forKey:RESXS_ENGINEPN];
    }
    if ([retHeadDic objectForKey:@"RegisterDate"]) {
        [headDict setObject:[retHeadDic objectForKey:@"RegisterDate"] forKey:RESXS_REGISTERDATE];
    }
    if ([retHeadDic objectForKey:@"IssueDate"]) {
        [headDict setObject:[retHeadDic objectForKey:@"IssueDate"] forKey:RESXS_ISSUEDATE];
    }
    if ([retHeadDic objectForKey:@"FileNo."]) {
        [headDict setObject:[retHeadDic objectForKey:@"FileNo."] forKey:RESXS_ISSUEDATE];
    }
    if ([retHeadDic objectForKey:@"Record"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Record"] forKey:RESXS_FILENO];
    }
    if ([retHeadDic objectForKey:@"ApprovedNo."]) {
        [headDict setObject:[retHeadDic objectForKey:@"ApprovedNo."] forKey:RESXS_APPROVEDNO];
    }
    if ([retHeadDic objectForKey:@"TotalQuality"]) {
        [headDict setObject:[retHeadDic objectForKey:@"TotalQuality"] forKey:RESXS_TOTALQUALITY];
    }
    if ([retHeadDic objectForKey:@"CurbWeight"]) {
        [headDict setObject:[retHeadDic objectForKey:@"CurbWeight"] forKey:RESXS_CURBWEIGHT];
    }
    if ([retHeadDic objectForKey:@"ApprovedQuality"]) {
        [headDict setObject:[retHeadDic objectForKey:@"ApprovedQuality"] forKey:RESXS_APPROVEDQUALITY];
    }
    if ([retHeadDic objectForKey:@"Size"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Size"] forKey:RESXS_SIZE];
    }
    if ([retHeadDic objectForKey:@"TractQuality"]) {
        [headDict setObject:[retHeadDic objectForKey:@"TractQuality"] forKey:RESXS_TRACTQUALITY];
    }
    if ([retHeadDic objectForKey:@"Note"]) {
        [headDict setObject:[retHeadDic objectForKey:@"Note"] forKey:RESXS_NOTE];
    }
    if (idCardImage != NULL) {
        [headDict setObject:idCardImage forKey:RESXS_IDIMAGE];
    }
    return headDict;
}

- (NSString *)makeArrayFromBFieldJSON_XS:(BField *)field {
    char buf[8192]= {11};
    NSString *result = @"";
    int ret = HC_PrintFieldInfo_JSON_XS(_bcrEngine,field,buf,8192);
    NSLog(@"makeArrayFromBFieldJSON_XS=%d",ret);
    if (ret == 1) {
        result = [NSString stringWithCString:buf encoding:0x80000632];
    }
    return result;
}
 */

#pragma mark--VIN码识别
/*
-(int)doBcrRecognizeVedioWith_VIN:(UInt8 *)buffer andWidth:(int)width andHeight:(int)height andRect:(BRect)pRect andChannelNumberStr:(NSString *)channelNumberStr
{
    NSString *iOSFileDirectStr = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    char *iOSFileDirect = (char*)[iOSFileDirectStr cStringUsingEncoding:NSUTF8StringEncoding];
    char *channelNumber = (char*)[channelNumberStr cStringUsingEncoding:NSUTF8StringEncoding];
    int ret = YMVR_RecognizeVedio_VIN(buffer, width, height, 0, &pRect, BcrResult_func, BcrFree_func,2,channelNumber,iOSFileDirect);
    return ret;
}

- (NSDictionary *)doBCRWithRect_VIN:(CGRect)rect
{
    int ret;
    char buf[1024]= {0};
    
    NSMutableDictionary *retDic = [NSMutableDictionary dictionary];
    NSString *result = @"";
    ret = YMVR_GetResult_VIN(buf,1024);
    
    BImage *dupBimage ;
    YMVR_CarImage_VIN(&dupBimage);
    NSString *docs = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/a.jpg"] ;
    YM_SaveImage_BK(dupBimage,(char*)[docs UTF8String]);
    idCardImage = [[UIImage alloc]initWithContentsOfFile:docs];
    BImage *headBimage ;
    YMVR_CarImage_ViN(&headBimage);
    NSString *docs2 = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/head.jpg"] ;
    YM_SaveImage_BK(headBimage,(char*)[docs UTF8String]);
    headImage = [[UIImage alloc]initWithContentsOfFile:docs2];
    
    if (ret != 1)
    {
        return nil;
    }
    result = [NSString stringWithCString:buf encoding:0x80000632];
    
    if (result.length) {
        [retDic setObject:result forKey:RESVIN_RESULT];
    }
    
    if (idCardImage != NULL) {
        [retDic setObject:idCardImage forKey:RESVIN_IDIMAGE];
    }
    if (headImage != NULL) {
        [retDic setObject:headImage forKey:RESVIN_HEADIMAGE];
    }
    return retDic;
}

- (NSDictionary *)doOCR_VINwithPicIndex:(NSInteger)picIndex {
    BField *bField = NULL;
    int ret;
    NSString *iOSFileDirectStr = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    char *iOSFileDirect = (char*)[iOSFileDirectStr cStringUsingEncoding:NSUTF8StringEncoding];
    NSString *docs0 = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@%ld.jpg",@"_",(long)picIndex]];
    
    YM_SaveImage_BK(_bImage,(char*)[docs0 UTF8String]);
    idCardImage = [[UIImage alloc]initWithContentsOfFile:docs0];
    ret = HC_DoImageOCR_VIN(_bcrEngine, _bImage, &bField,iOSFileDirect);
    
    [self freeBImage];
    
    if (ret != 1)
    {
        if (bField != NULL) {
            [self freeBField:bField];
        }
        
        [self closeEngine];
        return nil;
    }
    
    NSString *result = @"";
    result = [NSString stringWithCString:bField->text encoding:0x80000632];
    
    [self freeBField:bField];
    [self closeEngine];
    
    NSMutableDictionary *headDic = [NSMutableDictionary dictionary];
    [headDic setObject:result forKey:RESVIN_RESULT];
    
    if (idCardImage != NULL) {
        [headDic setObject:idCardImage forKey:RESVIN_IDIMAGE];
    }
    return headDic;
}
 */

#pragma mark---购车发票识别
/*
- (NSDictionary *)doOCR_GCFPwithPicIndex:(NSInteger)picIndex {
    BField *bField = NULL;
    int ret;
    //    NSString *iOSFileDirectStr = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    //    char *iOSFileDirect = (char*)[iOSFileDirectStr cStringUsingEncoding:NSUTF8StringEncoding];
    
    DOC_FIELD *doc_field=NULL;
    NSMutableDictionary *headDict = [NSMutableDictionary dictionaryWithCapacity:10];
    char resultText[OCR_TEXT_MAX_LEN] = {0};
    HC_SetTemplateType(_bcrEngine);
    int ret2 = Plan_Image(_bImage, _bcrEngine);
    
    //    NSString *docs0 = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/%@%ld.jpg",@"_",(long)picIndex]];
    //    YM_SaveImage_BK(_bImage,(char*)[docs0 UTF8String]);
    //    idCardImage = [[UIImage alloc]initWithContentsOfFile:docs0];
    ret = HC_DoImageOCR(_bcrEngine, _bImage, &bField, &doc_field, nil);
    
    DEF_NEXPBLOCK *aaa = NULL;    //位置信息的结果提
    BImage *pfimge = NULL;           //灰度图片
    pfimge = HC_ExpGryImg(_bcrEngine);   //获取灰度图片
    aaa = HC_ExpBlockInfo(_bcrEngine);  //获取位置信息
    
    [self freeBImage];
    
    if (ret != 1)
    {
        if (bField != NULL) {
            [self freeBField:bField];
        }
        if (doc_field != NULL)
        {
            HC_freeDocField(doc_field);
        }
        
        [self closeEngine];
        return nil;
    }
    
    ret = HC_GetResultFromTemplate(_bcrEngine,resultText,sizeof(resultText));
    
    NSString *resultStr = @"";
    resultStr = [NSString stringWithCString:resultText encoding:0x80000632];
    
    int block_num = aaa->block_num;
    NSMutableArray *textArray = [NSMutableArray arrayWithCapacity:block_num];
    NSMutableArray *textTableArray = [NSMutableArray arrayWithCapacity:block_num];
    NSMutableArray *lxArray = [NSMutableArray arrayWithCapacity:block_num];
    NSMutableArray *lyArray = [NSMutableArray arrayWithCapacity:block_num];
    NSMutableArray *rxArray = [NSMutableArray arrayWithCapacity:block_num];
    NSMutableArray *ryArray = [NSMutableArray arrayWithCapacity:block_num];
    
    for (int i= 0; i<block_num; i++)
    {
        NSString *text = [NSString stringWithCString:(char*)(*aaa).block_info[i].text encoding:0x80000632];
        NSString *text_table = [NSString stringWithCString:(char*)(*aaa).block_info[i].text_table encoding:0x80000632];
        short lx = (*aaa).block_info[i].rt.lx;
        short ly = (*aaa).block_info[i].rt.ly;
        short rx = (*aaa).block_info[i].rt.rx;
        short ry = (*aaa).block_info[i].rt.ry;
        [textArray addObject:text];
        [textTableArray addObject:text_table];
        [lxArray addObject:[NSString stringWithFormat:@"%d",lx]];
        [lyArray addObject:[NSString stringWithFormat:@"%d",ly]];
        [rxArray addObject:[NSString stringWithFormat:@"%d",rx]];
        [ryArray addObject:[NSString stringWithFormat:@"%d",ry]];
    }
    
    //    NSString *docs = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/%@%ld.jpg",@"_",(long)picIndex]];
    //    //    HC_SaveImage_JPG(pfimge,(char*)[docs UTF8String],0);
    //    HC_SaveImage(_bcrEngine, pfimge, (char*)[docs UTF8String], 0);
    //    idCardImage = [[UIImage alloc]initWithContentsOfFile:docs];
    
    [headDict setObject:resultStr forKey:RESGCFP_RESULT];
    [headDict setObject:[NSString stringWithFormat:@"%d",block_num] forKey:RESGCFP_BlockNum];
    [headDict setObject:textArray forKey:RESGCFP_Text];
    [headDict setObject:textTableArray forKey:RESGCFP_TextTable];
    [headDict setObject:lxArray forKey:RESGCFP_Lx];
    [headDict setObject:lyArray forKey:RESGCFP_Ly];
    [headDict setObject:rxArray forKey:RESGCFP_Rx];
    [headDict setObject:ryArray forKey:RESGCFP_Ry];
    
    //    [headDict setObject:idCardImage forKey:RESGCFP_IDIMAGE];
    
    HC_freeImage(_bcrEngine,&pfimge);      //释放灰度图片
    HC_FreeExpBlockInfo(&aaa);     //释放位置信息结构体
    [self closeEngine];
    
    return headDict;
}
 */

#pragma mark-- 护照识别
/*
- (NSDictionary *)doBCRJSON_HZ
{
    BField *bField = NULL;
    int ret;
    NSMutableDictionary *retDic = [NSMutableDictionary dictionary];
    
    NSString *iOSFileDirectStr = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    char *iOSFileDirect = (char*)[iOSFileDirectStr cStringUsingEncoding:NSUTF8StringEncoding];
    
    NSString *docs1 = [NSHomeDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"Documents/hz.jpg"]];
    YM_SaveImage(_bImage, (char*)[docs1 UTF8String]);
    idCardImage = [[UIImage alloc] initWithContentsOfFile:docs1];
    
    ret = HC_DoImageBCR_HZ(_bcrEngine, _bImage, &bField,iOSFileDirect);
    
    [self freeBImage];
    
    if (ret != 1)
    {
        if (bField != NULL) {
            [self freeBField:bField];
        }
        [self closeEngine];
        return nil;
    }
    
    NSString *result = @"";
    result = [self makeArrayFromBFieldJSON_HZ:bField];
    [self freeBField:bField];
    [self closeEngine];
    
    if (ret != 1)
    {
        [self closeEngine];
        return nil;
    }
    
    NSDictionary *headDic = [self dictionaryWithJsonString:result];
    NSLog(@"doBCRWithRect_HZ=%@",headDic);
    if ([headDic objectForKey:@"Name"]) {
        [retDic setObject:[headDic objectForKey:@"Name"] forKey:RESHZ_NAME];
    }
    if ([headDic objectForKey:@"NameCh"]) {
        [retDic setObject:[headDic objectForKey:@"NameCh"] forKey:RESHZ_NAMECH];
    }
    if ([headDic objectForKey:@"CardNo"]) {
        [retDic setObject:[headDic objectForKey:@"CardNo"] forKey:RESHZ_CARDNO];
    }
    if ([headDic objectForKey:@"Sex"]) {
        [retDic setObject:[headDic objectForKey:@"Sex"] forKey:RESHZ_SEX];
    }
    if ([headDic objectForKey:@"SexCH"]) {
        [retDic setObject:[headDic objectForKey:@"SexCH"] forKey:RESHZ_SEXCH];
    }
    if ([headDic objectForKey:@"Birthday"]) {
        [retDic setObject:[headDic objectForKey:@"Birthday"] forKey:RESHZ_BIRTHDAY];
    }
    if ([headDic objectForKey:@"Address"]) {
        [retDic setObject:[headDic objectForKey:@"Address"] forKey:RESHZ_ADDRESS];
    }
    if ([headDic objectForKey:@"AddressCH"]) {
        [retDic setObject:[headDic objectForKey:@"AddressCH"] forKey:RESHZ_ADDRESSCH];
    }
    if ([headDic objectForKey:@"IssueDate"]) {
        [retDic setObject:[headDic objectForKey:@"IssueDate"] forKey:RESHZ_ISSUEDATE];
    }
    if ([headDic objectForKey:@"ValidPeriod"]) {
        [retDic setObject:[headDic objectForKey:@"ValidPeriod"] forKey:RESHZ_VALIDPERIOD];
    }
    if ([headDic objectForKey:@"Nation"]) {
        [retDic setObject:[headDic objectForKey:@"Nation"] forKey:RESHZ_NATION];
    }
    if ([headDic objectForKey:@"IssueAddress"]) {
        [retDic setObject:[headDic objectForKey:@"IssueAddress"] forKey:RESHZ_ISSUEADDRESS];
    }
    if ([headDic objectForKey:@"IssueAddressCH"]) {
        [retDic setObject:[headDic objectForKey:@"IssueAddressCH"] forKey:RESHZ_ISSUEADDRESSCH];
    }
    if ([headDic objectForKey:@"personalNo"]) {
        [retDic setObject:[headDic objectForKey:@"personalNo"] forKey:RESHZ_PERSONALNO];
    }
    if ([headDic objectForKey:@"EnFir"]) {
        [retDic setObject:[headDic objectForKey:@"EnFir"] forKey:RESHZ_ENFIR];
    }
    if ([headDic objectForKey:@"EnSen"]) {
        [retDic setObject:[headDic objectForKey:@"EnSen"] forKey:RESHZ_ENSEN];
    }
    if ([headDic objectForKey:@"NameFir"]) {
        [retDic setObject:[headDic objectForKey:@"NameFir"] forKey:RESHZ_NAMEFIR];
    }
    if ([headDic objectForKey:@"NameSen"]) {
        [retDic setObject:[headDic objectForKey:@"NameSen"] forKey:RESHZ_NAMESEN];
    }
    if ([headDic objectForKey:@"MRZ"]) {
        [retDic setObject:[headDic objectForKey:@"MRZ"] forKey:RESHZ_MRZ];
    }
    if ([headDic objectForKey:@"BIDC_MRZ1"]) {
        [retDic setObject:[headDic objectForKey:@"BIDC_MRZ1"] forKey:RESHZ_BIDC_MRZ1];
    }
    if ([headDic objectForKey:@"BIDC_MRZ2"]) {
        [retDic setObject:[headDic objectForKey:@"BIDC_MRZ2"] forKey:RESHZ_BIDC_MRZ2];
    }
    
    if (idCardImage != NULL) {
        [retDic setObject:idCardImage forKey:RESHZ_IDIMAGE];
    }
    return retDic;
}

- (NSString *)makeArrayFromBFieldJSON_HZ:(BField *)field {
    char buf[8192]= {11};
    NSString *result = @"";
    int ret = HC_PrintFieldInfo_JSON_HZ(_bcrEngine,field,buf,8192);
    NSLog(@"makeArrayFromBFieldJSON=%d",ret);
    if (ret == 1) {
        result = [NSString stringWithCString:buf encoding:0x80000632];
    }
    return result;
}
 */
- (id)initWithLanguage:(NSInteger)language andIndex:(NSInteger)index andChannelNumber:(NSString*)channelNumberStr
{
    self = [super init];
    if (self)
    {
        _engInitRet = engInitFailed;
        switch (index) {
            case cardType_ID:
            {
                _cardIndex = cardType_ID;
                _engInitRet = [self resetEngine_ID:language andChannelNumber:channelNumberStr];
                
            }
                break;
                
            default:
                break;
        }
        
    }
    return self;
}
- (EngInitRet)resetEngine_ID:(NSInteger)language andChannelNumber:(NSString*)channelNumberStr
{
    language = 2;
    NSInteger ret;
    NSString *path = [[NSBundle mainBundle] bundlePath];
    NSMutableString *realPath = [NSMutableString string];
    [realPath appendFormat:@"%@/", path];
    
    char *p = (char*)[realPath cStringUsingEncoding:NSUTF8StringEncoding];
    char *channelNumber = (char*)[channelNumberStr cStringUsingEncoding:NSUTF8StringEncoding];
    
    NSString *iOSFileDirectStr = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    char *iOSFileDirect = (char*)[iOSFileDirectStr cStringUsingEncoding:NSUTF8StringEncoding];
    NSLog(@"%@",_bcrEngine);
    ret = HC_StartBCR_ID(&_bcrEngine, p, "null",(int)language,channelNumber,iOSFileDirect);
    
    switch (ret) {
            [self closeEngine_ID];
            NSLog(@"HC_StartBCR_ID failed.=%ld",(long)ret);
        case 0:
            return engInitFailed;
            break;
        case 100:
            return engInitLocTimeExpired;
            break;
        case 101:
            return engInitRecTimeExpired;
            break;
        case 200:
            return engInitAuthoriFailed;
            break;
        case 300:
            return engInitTimesExceed;
            break;
        case 600:
            return engInitEncryptionFailed;
            break;
        case 900:
            return engInitTimesPermissionsFailed;
            break;
        case 901:
            return engInitTimePermissionsFailed;
            break;
            
        default:
            break;
    }
    return engInitSuccess;
}
- (void)closeEngine_ID {
    if (_bcrEngine) {
        HC_CloseBCR_ID(&_bcrEngine);
        _bcrEngine = NULL;
    }
}
#pragma mark -
- (id)initWithLanguage:(NSInteger)language andIndex:(NSInteger)index
{
    self = [super init];
    if (self)
    {
        _engInitRet = engInitFailed;
        switch (index) {
            case cardType_Bank:
            {
                _cardIndex = cardType_Bank;
                _engInitRet = engInitSuccess;
            }
                break;
            case cardType_ID:
            {
                _cardIndex = cardType_ID;
                _engInitRet = [self resetEngine:language];
            }
                break;
                
            case cardType_JZ:
            {
                _cardIndex = cardType_JZ;
                _engInitRet = [self resetEngine:language];
            }
                break;
                
            case cardType_XS:
            {
                _cardIndex = cardType_XS;
                _engInitRet = [self resetEngine:language];
            }
                break;
                
            case cardType_CP:
            {
                _cardIndex = cardType_CP;
                _engInitRet = [self resetEngine:language];
            }
                break;
            case cardType_VIN:
            {
                _cardIndex = cardType_VIN;
                _engInitRet = [self resetEngine:language];
            }
                break;
            case cardType_GCFP:
            {
                _cardIndex = cardType_GCFP;
                _engInitRet = [self resetEngine:language];
            }
                break;
                
            case cardType_HZ:
            {
                _cardIndex = cardType_HZ;
                _engInitRet = [self resetEngine:language];
            }
                break;
                
            default:
                break;
        }

    }
    return self;
}


- (EngInitRet)resetEngine:(NSInteger)language
{
	language = 2;
	NSInteger ret = 0;
    NSString *path = [[NSBundle mainBundle] bundlePath];
    NSMutableString *realPath = [NSMutableString string];
    [realPath appendFormat:@"%@/", path];
    
    char *p = (char*)[realPath cStringUsingEncoding:NSUTF8StringEncoding];
    NSString *iOSFileDirectStr = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    char *iOSFileDirect = (char*)[iOSFileDirectStr cStringUsingEncoding:NSUTF8StringEncoding];
    
    char *channelNumber;
    switch (_cardIndex) {
        case cardType_Bank:
        {
            channelNumber = (char*)[CHANNELNUM_BK cStringUsingEncoding:NSUTF8StringEncoding];
        }
            break;
        case cardType_ID:
        {
            channelNumber = (char*)[CHANNELNUM_ID cStringUsingEncoding:NSUTF8StringEncoding];
            ret = HC_StartBCR_ID(&_bcrEngine, p, "null",(int)language,channelNumber,iOSFileDirect);
            NSLog(@"HC_StartBCR_ID =%ld",(long)ret);
        }
            break;
//        case cardType_JZ:
//        {
//            channelNumber = (char*)[CHANNELNUM_JZ cStringUsingEncoding:NSUTF8StringEncoding];
//            ret = HC_StartBCR_JZ(&_bcrEngine, p, "null",(int)language,channelNumber,iOSFileDirect);
//            NSLog(@"HC_StartBCR_JZ =%ld",(long)ret);
//        }
//            break;
//        case cardType_XS:
//        {
//            channelNumber = (char*)[CHANNELNUM_XS cStringUsingEncoding:NSUTF8StringEncoding];
//            ret = HC_StartBCR_XS(&_bcrEngine, p, "null",(int)language,channelNumber,iOSFileDirect);
//            NSLog(@"HC_StartBCR_XS =%ld",(long)ret);
//        }
//            break;
//        case cardType_CP:
//        {
//            channelNumber = (char*)[CHANNELNUM_CP cStringUsingEncoding:NSUTF8StringEncoding];
//            ret = HC_StartOCR_CP(&_bcrEngine, p, "null", (int)language,
//                                 OCR_READ_OCR,channelNumber,iOSFileDirect);
//            NSLog(@"HC_StartOCR_CP =%ld",(long)ret);
//        }
//            break;
//        case cardType_VIN:
//        {
//            language = 1;
//            channelNumber = (char*)[CHANNELNUM_VIN cStringUsingEncoding:NSUTF8StringEncoding];
//            ret = HC_StartOCR_VIN(&_bcrEngine, p, "null", (int)language,
//                                 OCR_READ_DOC,channelNumber,iOSFileDirect);
//            NSLog(@"HC_StartOCR_VIN =%ld",(long)ret);
//        }
//            break;
//        case cardType_GCFP:
//        {
////            channelNumber = (char*)[CHANNELNUM_GCFP cStringUsingEncoding:NSUTF8StringEncoding];
//            ret = HC_StartOCR(&_bcrEngine, "null", "ScanPen_mob.cfg", (int)language, OCR_READ_DOC);
//            NSLog(@"HC_StartOCR =%ld",(long)ret);
//        }
//            break;
//        case cardType_HZ:
//        {
//            channelNumber = (char*)[CHANNELNUM_HZ cStringUsingEncoding:NSUTF8StringEncoding];
//            ret = HC_StartBCR_HZ(&_bcrEngine, p, "null",(int)language,channelNumber,iOSFileDirect);
//            NSLog(@"HC_StartBCR_HZ failed.=%ld",(long)ret);
//        }
//            break;
            
        default:
            break;
    }

    switch (ret) {
        case 0:
            return engInitFailed;
            break;
        case 100:
            return engInitLocTimeExpired;
            break;
        case 101:
            return engInitRecTimeExpired;
            break;
        case 200:
            return engInitAuthoriFailed;
            break;
        case 300:
            return engInitTimesExceed;
            break;
        case 600:
            return engInitEncryptionFailed;
            break;
        case 900:
            return engInitTimesPermissionsFailed;
            break;
        case 901:
            return engInitTimePermissionsFailed;
            break;
            
        default:
            break;
    }
    return engInitSuccess;
}

-(void)setBcrResultCallbackDelegate:(id)delegate
{
    bcrResultDelegate = delegate;
    if (![bcrResultDelegate conformsToProtocol:@protocol(BcrResultCallbackDelegate)]) {
        bcrResultDelegate = nil;
    }
}

- (void)closeEngine {
    if (_bcrEngine) {
        switch (_cardIndex) {
//            case cardType_ID:
//                HC_CloseBCR_ID(&_bcrEngine);
//                break;
//            case cardType_JZ:
//                HC_CloseBCR_JZ(&_bcrEngine);
//                break;
//            case cardType_XS:
//                HC_CloseBCR_XS(&_bcrEngine);
//                break;
//            case cardType_CP:
//                HC_CloseOCR_CP(&_bcrEngine);
//                break;
//            case cardType_GCFP:
//                HC_CloseOCR(&_bcrEngine);
//                break;
//            case cardType_HZ:
//                HC_CloseBCR_HZ(&_bcrEngine);
//                break;
//            default:
//                break;
        }
        _bcrEngine = NULL;
    }
}

- (void)freeBImage {
	if(_bImage) {
        switch (_cardIndex) {
            case cardType_Bank:
                HC_freeImage_BK(_bcrEngine, &_bImage);
                break;
            case cardType_ID:
                HC_freeImage_ID(_bcrEngine, &_bImage);
                break;
//            case cardType_JZ:
//                HC_freeImage_JZ(_bcrEngine, &_bImage);
//                break;
//            case cardType_XS:
//                HC_freeImage_XS(_bcrEngine, &_bImage);
//                break;
//            case cardType_CP:
//                HC_freeImage_CP(_bcrEngine, &_bImage);
//                break;
//            case cardType_VIN:
//                HC_freeImage_VIN(_bcrEngine, &_bImage);
//                break;
//            case cardType_GCFP:
//                HC_freeImage(_bcrEngine, &_bImage);
//                break;
//            case cardType_HZ:
//                HC_freeImage_HZ(_bcrEngine, &_bImage);
//                break;
            default:
                break;
        }
		_bImage = nil;
	}
}

- (BOOL)allocBImage:(UIImage *)image {
	[self freeBImage];
	int width = CGImageGetWidth(image.CGImage);
	int height = CGImageGetHeight(image.CGImage);
	
	NSInteger ret;
    if (!_bcrEngine) {
        [self resetEngine:ocrLanguage];
    }
    switch (_cardIndex) {
        case cardType_Bank:
            ret = HC_allocImage_BK(_bcrEngine, &_bImage, width, height, -1);
            break;
        case cardType_ID:
            ret = HC_allocImage_ID(_bcrEngine, &_bImage, width, height, -1);
            break;
//        case cardType_JZ:
//            ret = HC_allocImage_JZ(_bcrEngine, &_bImage, width, height, -1);
//            break;
//        case cardType_XS:
//            ret = HC_allocImage_XS(_bcrEngine, &_bImage, width, height, -1);
//            break;
//        case cardType_CP:
//            ret = HC_allocImage_CP(_bcrEngine, &_bImage, width, height, -1);
//            break;
//        case cardType_VIN:
//            ret = HC_allocImage_VIN(_bcrEngine, &_bImage, width, height, -1);
//            break;
//        case cardType_GCFP:
//            ret = HC_allocImage(_bcrEngine, &_bImage, width, height, -1);
//            break;
//        case cardType_HZ:
//            ret = HC_allocImage_HZ(_bcrEngine, &_bImage, width, height, -1);
//            break;
        default:
            ret = 1;
            break;
    }
	if (ret == 0) {
		NSLog(@"allocImage failed.");
		_bImage = nil;
		return NO;
	}
	
	if(![YMUtility GetYDataFromImage:image pixels:_bImage->pixels]) {
		NSLog(@"GetYDataFromImage failed.");
		[self freeBImage];
		return NO;
	}
	return YES;
}

- (void)freeBField:(BField *)field {
        if (field)
        switch (_cardIndex) {
            case cardType_ID:
                HC_freeBField_ID(_bcrEngine, field, 0);
                break;
//            case cardType_JZ:
//                HC_freeBField_JZ(_bcrEngine, field, 0);
//                break;
//            case cardType_XS:
//                HC_freeBField_XS(_bcrEngine, field, 0);
//                break;
//            case cardType_CP:
//                HC_freeBField_CP(_bcrEngine, field, 0);
//                break;
//            case cardType_VIN:
//                HC_freeBField_VIN(_bcrEngine, field, 0);
//                break;
//            case cardType_HZ:
//                HC_freeBField_HZ(_bcrEngine, field, 0);
//                break;
                
            default:
                break;
        }
}

/*!
 json格式字符串转字典：
 * @brief 把格式化的JSON格式的字符串转换成字典
 
 * @param jsonString JSON格式的字符串
 
 * @return 返回字典
 
 */

-(NSDictionary *)dictionaryWithJsonString:(NSString *)jsonString {
    
    if (jsonString == nil) {
        
        return nil;
        
    }
    NSLog(@"jsonString=%@",jsonString);
    NSData *jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    
    NSError *err;
    
    NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                         
                                                        options:NSJSONReadingMutableContainers
                         
                                                          error:&err];
    if(err) {
        
        NSLog(@"json解析失败：%@",err);
        
        return nil;
        
    }
    NSLog(@"dictionaryWithJsonString=%@",dic);
    return dic;
}

- (BOOL)allocBImage_ID:(UIImage *)image {
    [self freeBImage_ID];
    
    int width = CGImageGetWidth(image.CGImage);
    int height = CGImageGetHeight(image.CGImage);
    
    NSInteger ret;
    if (!_bcrEngine) {
        [self resetEngine_ID:ocrLanguage andChannelNumber:@"yunmaiTY"];
    }
    ret = HC_allocImage_ID(_bcrEngine, &_bImage, width, height, -1);
    if (ret == 0) {
        NSLog(@"allocImage failed.");
        _bImage = nil;
        return NO;
    }
    
    if(![YMUtility GetYDataFromImage:image pixels:_bImage->pixels]) {
        NSLog(@"GetYDataFromImage failed.");
        [self freeBImage_ID];
        return NO;
    }
    return YES;
}
- (void)freeBImage_ID {
    
    if(_bImage) {
        HC_freeImage_ID(_bcrEngine, &_bImage);
        _bImage = nil;
    }
}

@end
