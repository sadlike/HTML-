//
//  WWPCacheManager.m
//  testPlugin
//
//  Created by wwp on 2018/11/9.
//

#import "WWPCacheManager.h"
#import "YMIDCardEngine.h"

WWPCacheManager *hwSaveCache;

@implementation WWPCacheManager
-(instancetype)init{
    if (self = [super init]) {
        self.ymIDCardEngine = [[YMIDCardEngine alloc]init];
    }
    return self;
}
@end
