//
//  CameraViewController.m
//  IDCardDemo
//
//  Created by linmac on 16-10-15.
//  Copyright (c) 2013年 mac. All rights reserved.
//

#import "CameraViewController.h"
#import "CameraDrawView.h"
#import "YMLine.h"
#import "UIViewExt.h"
#import "YMIDCardEngine.h"
#import "UKImage.h"
#import <sys/sysctl.h>
#import <CoreVideo/CoreVideo.h>
#import <CoreMedia/CoreMedia.h>
#import <ImageIO/ImageIO.h>
#import "WWPCacheManager.h"
#import "WWPUtils.h"



#define  CONTROL_MONTH 5
#define  CONTROL_YEAR 2019

@interface CameraViewController ()<UIAlertViewDelegate,BcrResultCallbackDelegate>{
    
    CameraDrawView *_cameraDrawView;
    BOOL _on;
    
    NSTimer *_timer;
    CAShapeLayer *_maskWithHole;
    AVCaptureDevice *_device;//当前摄像设备
    BOOL _isFoucePixel;
    int _maxCount;
    float _isIOS8AndFoucePixelLensPosition;
    
    NSInteger   bcrResultValue;
    NSInteger   bcrFreeValue;
}

@property (assign, nonatomic) BOOL adjustingFocus;//是否正在对焦
@end

@implementation CameraViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _maxCount = 4;//最大连续检边次数
    //初始化相机
    [self initializeCamera];
    //创建相机界面控件
    [self createCameraView];
  
    [self editJurisdiction];
    
//    appDlg = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [hwSaveCache.ymIDCardEngine setBcrResultCallbackDelegate:self];
}

- (void) viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
    
    idCardRangeRect = _cameraDrawView.engIdCardRect;
    
    if(!_isFoucePixel){//如果不支持相位对焦，开启自定义对焦
        //定时器 开启连续对焦
        _timer = [NSTimer scheduledTimerWithTimeInterval:1.3 target:self selector:@selector(fouceMode) userInfo:nil repeats:YES];
    }
    
    AVCaptureDevice*camDevice =[AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    int flags = NSKeyValueObservingOptionNew;
    //注册反差对焦通知（5s以下机型）
    [camDevice addObserver:self forKeyPath:@"adjustingFocus" options:flags context:nil];
    if (_isFoucePixel) {
        [camDevice addObserver:self forKeyPath:@"lensPosition" options:flags context:nil];
    }
    [self.session startRunning];
    
    if (self.exIdCardIndex == cardType_Bank) {
        _cameraDrawView.LabIdDetail.hidden = YES;
    }
    else if (self.exIdCardIndex == cardType_VIN)
    {
        _cameraDrawView.LabIdDetail.hidden = YES;
        _cameraDrawView.LabbankDetail.hidden = YES;
        _cameraDrawView.ImageVBankLine.hidden = YES;
    }
    else if (self.exIdCardIndex == cardType_CP)
    {
        _cameraDrawView.LabIdDetail.hidden = YES;
        _cameraDrawView.LabbankDetail.hidden = YES;
        _cameraDrawView.ImageVBankLine.hidden = YES;
    }
    else
    {
        _cameraDrawView.LabbankDetail.hidden = YES;
        _cameraDrawView.ImageVBankLine.hidden = YES;
    }
    
}

- (void) viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    self.view.backgroundColor = [UIColor clearColor];
}

- (void) viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    //移除聚焦监听
    AVCaptureDevice*camDevice =[AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    [camDevice removeObserver:self forKeyPath:@"adjustingFocus"];
    if (_isFoucePixel) {
        [camDevice removeObserver:self forKeyPath:@"lensPosition"];
    }
    [self.session stopRunning];
    
}
- (void) viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    
    //关闭定时器
    if(!_isFoucePixel){
        [_timer invalidate];
    }
}
-(void)editJurisdiction{
    NSDate *nowDate = [NSDate date];
    NSCalendar *gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSUInteger unitFlags = NSCalendarUnitDay | NSCalendarUnitMonth | NSCalendarUnitYear;
    NSDateComponents *components = [gregorian components:unitFlags fromDate:nowDate];
    NSInteger month = [components month];
    NSInteger year = [components year];
    if ((year==CONTROL_YEAR)&&(month>CONTROL_MONTH)) {
        [self showCamaraAlert:nil];
        return;
    }else{
    }
}
//监听对焦
-(void)observeValueForKeyPath:(NSString*)keyPath ofObject:(id)object change:(NSDictionary*)change context:(void*)context {
    if([keyPath isEqualToString:@"adjustingFocus"]){
        self.adjustingFocus =[[change objectForKey:NSKeyValueChangeNewKey] isEqualToNumber:[NSNumber numberWithInt:1]];
        //对焦中
    }
    if([keyPath isEqualToString:@"lensPosition"]){
        _isIOS8AndFoucePixelLensPosition =[[change objectForKey:NSKeyValueChangeNewKey] floatValue];
    }
}

//初始化相机
- (void) initializeCamera
{
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0) {
        //判断摄像头授权
        NSString *mediaType = AVMediaTypeVideo;
        AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:mediaType];
        if(authStatus == AVAuthorizationStatusRestricted || authStatus == AVAuthorizationStatusDenied){
            
            UIAlertView * alt = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"allowCamare", nil) message:nil delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
            [alt show];
            return;
        }
    }
    //1.创建会话层
    self.session = [[AVCaptureSession alloc] init];
    //设置图片品质
    [self.session setSessionPreset:AVCaptureSessionPresetHigh];
    
    //2.创建、配置输入设备
    NSArray *devices = [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo];
    
    for (AVCaptureDevice *device in devices)
    {
        if (device.position == AVCaptureDevicePositionBack)
        {
            _device = device;
            self.captureInput = [AVCaptureDeviceInput deviceInputWithDevice:device error:nil];
        }
    }
    [self.session addInput:self.captureInput];
    
    ///创建、配置预览输出设备
    AVCaptureVideoDataOutput *captureOutput = [[AVCaptureVideoDataOutput alloc] init];
    captureOutput.alwaysDiscardsLateVideoFrames = YES;
    
    dispatch_queue_t queue;
    queue = dispatch_queue_create("cameraQueue", NULL);
    [captureOutput setSampleBufferDelegate:self queue:queue];
    
    NSString* key = (NSString*)kCVPixelBufferPixelFormatTypeKey;
    NSNumber* value = [NSNumber numberWithUnsignedInt:kCVPixelFormatType_32BGRA];
    NSDictionary* videoSettings = [NSDictionary dictionaryWithObject:value forKey:key];
    [captureOutput setVideoSettings:videoSettings];
    
    [self.session addOutput:captureOutput];
    
    //3.创建、配置输出
    self.captureOutput = [[AVCaptureStillImageOutput alloc] init];
    NSDictionary *outputSettings = [[NSDictionary alloc] initWithObjectsAndKeys:AVVideoCodecJPEG,AVVideoCodecKey,nil];
    [self.captureOutput setOutputSettings:outputSettings];
    [self.session addOutput:self.captureOutput];
    
    //判断对焦方式
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0) {
        AVCaptureDeviceFormat *deviceFormat = _device.activeFormat;
        if (deviceFormat.autoFocusSystem == AVCaptureAutoFocusSystemPhaseDetection){
            _isFoucePixel = YES;
            _maxCount = 5;//最大连续检边次数
        }
    }
    
    //设置预览
    self.preview = [AVCaptureVideoPreviewLayer layerWithSession: self.session];
    self.preview.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    self.preview.videoGravity = AVLayerVideoGravityResizeAspectFill;
    [self.view.layer addSublayer:self.preview];
    
    [self.session startRunning];
}

//创建相机界面
- (void)createCameraView{
    //设置检边视图层
    _cameraDrawView = [[CameraDrawView alloc]initWithFrame:self.view.bounds];
    _cameraDrawView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_cameraDrawView];
    [_cameraDrawView setNeedsDisplay];
    // 获取bundle参数
//    NSBundle *bundle = [NSBundle bundleForClass:self.class];
    
//    NSString*bundlePath=[[NSBundle mainBundle] pathForResource:@"ImageResource" ofType:@"bundle"];
//    NSBundle*bundle=[NSBundle bundleWithPath:bundlePath];
//
//
//    // 读UIImage
//    UIImage *cancleImage = [UIImage imageNamed:@"cancel_s" inBundle:bundle compatibleWithTraitCollection:nil];

    //返回、闪光灯按钮
//    UIButton *backBtn = [[UIButton alloc]initWithFrame:CGRectMake(SYSTEM_WIDTH-70,SYSTEM_HEIGHT - 60, 65, 35)];
//    [backBtn addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
////    [backBtn setImage: [UIImage imageNamed:@"ImageResource.bundle/cancel_s"] forState:UIControlStateNormal];
//    backBtn.titleLabel.textAlignment = NSTextAlignmentLeft;
//    backBtn.transform = CGAffineTransformMakeRotation(M_PI_2);
    
    UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [backBtn setFrame:CGRectMake(SYSTEM_WIDTH-70,SYSTEM_HEIGHT - 60, 65, 35)];
    [backBtn setTitle:@"返回" forState:UIControlStateNormal];
    [backBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    backBtn.layer.borderWidth=1;
    backBtn.layer.borderColor = [UIColor grayColor].CGColor;
    [backBtn addTarget:self action:@selector(backAction) forControlEvents:UIControlEventTouchUpInside];
    backBtn.transform = CGAffineTransformMakeRotation(M_PI_2);
    //    [backBtn setImage: [UIImage imageNamed:@"ImageResource.bundle/cancel_s"] forState:UIControlStateNormal];

    [self.view addSubview:backBtn];
//    [self.view bringSubviewToFront:backBtn];
//    UIImage *onImage = [UIImage imageNamed:@"flash_on_s" inBundle:bundle compatibleWithTraitCollection:nil];

    UIButton *flashBtn = [[UIButton alloc]initWithFrame:CGRectMakeFlash(255+5,30, 35, 35)];
    [flashBtn setImage: [UIImage imageNamed:@"ImageResource.bundle/flash_on_s"] forState:UIControlStateNormal];
    [flashBtn addTarget:self action:@selector(flashBtn) forControlEvents:UIControlEventTouchUpInside];
    flashBtn.hidden = YES;
    [self.view addSubview:flashBtn];
    
}


//从摄像头缓冲区获取图像
#pragma mark - AVCaptureSession delegate
- (void)captureOutput:(AVCaptureOutput *)captureOutput
didOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer
       fromConnection:(AVCaptureConnection *)connection
{
    //获取当前帧数据
    CVImageBufferRef imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer);
    CVPixelBufferLockBaseAddress(imageBuffer,0);
    uint8_t *baseAddress = (uint8_t *)CVPixelBufferGetBaseAddress(imageBuffer);
    
    int width = (int)CVPixelBufferGetWidth(imageBuffer);
    int height = (int)CVPixelBufferGetHeight(imageBuffer);
    CGSize imageSize;
    imageSize.width = width;
    imageSize.height = height;
    
    CGRect rect0 = [self getImageSize:imageSize byCardRect:idCardRangeRect];

    BRect bRect;
    bRect.lx = rect0.origin.x;
    bRect.ly = rect0.origin.y;
    bRect.rx = rect0.origin.x + rect0.size.width;
    bRect.ry = rect0.origin.y + rect0.size.height;
    
#pragma mark -- begin
    int edge = 0;
    switch (self.exIdCardIndex) {
        case cardType_Bank:
        {
            edge = [hwSaveCache.ymIDCardEngine doBcrRecognizeVedioWithBuffer_BK:baseAddress andWidth:width andHeight:height andRect:bRect andChannelNumberStr:CHANNELNUM_BK];
        }
            break;

        case cardType_ID:
        {
            edge = [hwSaveCache.ymIDCardEngine doBcrRecognizeVedioWith_ID:baseAddress andWidth:width andHeight:height andRect:bRect andChannelNumberStr:CHANNELNUM_ID];
        }
//            break;
//        case cardType_XS:
//        {
//            edge = [hwSaveCache.ymIDCardEngine doBcrRecognizeVedioWith_XS:baseAddress andWidth:width andHeight:height andRect:bRect andChannelNumberStr:CHANNELNUM_XS];
//        }
//            break;
//        case cardType_JZ:
//        {
//            edge = [hwSaveCache.ymIDCardEngine doBcrRecognizeVedioWith_JZ:baseAddress andWidth:width andHeight:height andRect:bRect andChannelNumberStr:CHANNELNUM_JZ];
//        }
//            break;
//        case cardType_CP:
//        {
//            edge = [hwSaveCache.ymIDCardEngine doBcrRecognizeVedioWith_CP:baseAddress andWidth:width andHeight:height andRect:bRect andChannelNumberStr:CHANNELNUM_CP];
//        }
//            break;
//        case cardType_VIN:
//        {
//            edge = [hwSaveCache.ymIDCardEngine doBcrRecognizeVedioWith_VIN:baseAddress andWidth:width andHeight:height andRect:bRect andChannelNumberStr:CHANNELNUM_VIN];
//        }
//            break;

        default:
            break;
    }
    NSLog(@"edge = %d",edge);
    NSString *str = @"";
  
    switch (edge) {
        case 100:
        {
            str = @"本地时间过期";
            [_session stopRunning];
            bcrFreeValue = 1;
            [self performSelectorOnMainThread:@selector(showCamaraAlert:) withObject:str waitUntilDone:NO];
        }
            break;
        case 101:
        {
            str = @"识别时间过期";
            [_session stopRunning];
            bcrFreeValue = 1;
            [self performSelectorOnMainThread:@selector(showCamaraAlert:) withObject:str waitUntilDone:NO];
        }
            break;
        case 200:
        {
            str = @"授权失败";
            [_session stopRunning];
            bcrFreeValue = 1;
            [self performSelectorOnMainThread:@selector(showCamaraAlert:) withObject:str waitUntilDone:NO];
        }
            break;
        case 300:
        {
            str = @"识别次数超过";
            [_session stopRunning];
            bcrFreeValue = 1;
            [self performSelectorOnMainThread:@selector(showCamaraAlert:) withObject:str waitUntilDone:NO];
        }
            break;
        case 600:
        {
            str = @"软件加密失败";
            [_session stopRunning];
            bcrFreeValue = 1;
            [self performSelectorOnMainThread:@selector(showCamaraAlert:) withObject:str waitUntilDone:NO];
        }
            break;
        case 900:
        {
            str = @"识别次数创建权限失败";
            [_session stopRunning];
            bcrFreeValue = 1;
            [self performSelectorOnMainThread:@selector(showCamaraAlert:) withObject:str waitUntilDone:NO];
        }
            break;
        case 901:
        {
            str = @"识别时间创建权限失败";
            [_session stopRunning];
            bcrFreeValue = 1;
            [self performSelectorOnMainThread:@selector(showCamaraAlert:) withObject:str waitUntilDone:NO];
        }
            break;
            
        default:
            break;
    }
    if(str.length>0){
        NSDictionary * errorDic =@{@"code":[NSString stringWithFormat:@"%d",edge],
                                   @"msg":str};
        if (self.block) {
            self.block(errorDic);
        }
         [self backAction];
    }else{
        //找边成功
        if (bcrResultValue == 1)
        {
            bcrResultValue = 0;
            //停止取景
            [_session stopRunning];
            [self performSelectorOnMainThread:@selector(perFormDoOcr) withObject:nil waitUntilDone:NO];
        }
    }
    
    CVPixelBufferUnlockBaseAddress(imageBuffer,0);

}

-(void)showCamaraAlert:(id)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];
//    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:nil message:(NSString*)sender delegate:nil cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
//    [alertView show];
}

// Create a UIImage from sample buffer data
- (UIImage *) imageFromSampleBuffer:(CMSampleBufferRef) sampleBuffer
{
    // Get a CMSampleBuffer's Core Video image buffer for the media data
    CVImageBufferRef imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer);
    // Lock the base address of the pixel buffer
    CVPixelBufferLockBaseAddress(imageBuffer, 0);
    
    // Get the number of bytes per row for the pixel buffer
    void *baseAddress = CVPixelBufferGetBaseAddress(imageBuffer);
    
    // Get the number of bytes per row for the pixel buffer
    size_t bytesPerRow = CVPixelBufferGetBytesPerRow(imageBuffer);
    // Get the pixel buffer width and height
    size_t width = CVPixelBufferGetWidth(imageBuffer);
    size_t height = CVPixelBufferGetHeight(imageBuffer);
    
    // Create a device-dependent RGB color space
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    
    // Create a bitmap graphics context with the sample buffer data
    CGContextRef context = CGBitmapContextCreate(baseAddress, width, height, 8,
                                                 bytesPerRow, colorSpace, kCGBitmapByteOrder32Little | kCGImageAlphaPremultipliedFirst);
    // Create a Quartz image from the pixel data in the bitmap graphics context
    CGImageRef quartzImage = CGBitmapContextCreateImage(context);
    // Unlock the pixel buffer
    CVPixelBufferUnlockBaseAddress(imageBuffer,0);
    
    // Free up the context and color space
    CGContextRelease(context);
    CGColorSpaceRelease(colorSpace);
    
    // Create an image object from the Quartz image
    UIImage *image = [UIImage imageWithCGImage:quartzImage];
    
    // Release the Quartz image
    CGImageRelease(quartzImage);
    
    return (image);
}

-(void)perFormDoOcr
{
    

    
    CGRect rect;
    NSMutableDictionary *resultDict = [NSMutableDictionary dictionary];
//    NSString *resultStr = @"";
    switch (self.exIdCardIndex) {
        case cardType_Bank:
        {
            resultDict = (NSMutableDictionary*)[hwSaveCache.ymIDCardEngine doBCRWithRect_BK:rect];
        }
            break;
        case cardType_ID:
        {
           NSMutableDictionary *resultDi = (NSMutableDictionary*)[hwSaveCache.ymIDCardEngine doBCRWithRect_ID:rect];
//            ViewController *vc = [[ViewController alloc] init];
//            resultStr = [vc makeCardResultWithDicVideo_ID:resultDict];
           
             resultDict = [[WWPUtils shareInstance] makeResultDicVideo_ID:resultDi];
//            NSLog(@"rsultDic-----%@",resultDict);
//            if (resultStr.length)
//            {
//                [resultDict setObject:resultStr forKey:RES_IDSTR];
//            }
           
        }
            break;
//        case cardType_XS:
//        {
//            resultDict = (NSMutableDictionary*)[hwSaveCache.ymIDCardEngine doBCRWithRect_XS:rect];
//            ViewController *vc = [[ViewController alloc] init];
//            resultStr = [vc makeCardResultWithDic_XS:resultDict];
//            if (resultStr.length)
//            {
//                [resultDict setObject:resultStr forKey:RES_XSSTR];
//            }
//        }
//            break;
//        case cardType_JZ:
//        {
//            resultDict = (NSMutableDictionary*)[hwSaveCache.ymIDCardEngine doBCRWithRect_JZ:rect];
//            ViewController *vc = [[ViewController alloc] init];
//            resultStr = [vc makeCardResultWithDic_JZ:resultDict];
//            if (resultStr.length)
//            {
//                [resultDict setObject:resultStr forKey:RES_JZSTR];
//            }
//        }
//            break;
//        case cardType_CP:
//        {
//            resultDict = (NSMutableDictionary*)[hwSaveCache.ymIDCardEngine doBCRWithRect_CP:rect];
//            ViewController *vc = [[ViewController alloc] init];
//            resultStr = [vc makeCardResultWithDic_CP:resultDict];
//            if (resultStr.length)
//            {
//                [resultDict setObject:resultStr forKey:RES_CPSTR];
//            }
//        }
//            break;
//        case cardType_VIN:
//        {
//            resultDict = (NSMutableDictionary*)[hwSaveCache.ymIDCardEngine doBCRWithRect_VIN:rect];
//            ViewController *vc = [[ViewController alloc] init];
//            resultStr = [vc makeCardResultWithDic_VIN:resultDict];
//            if (resultStr.length)
//            {
//                [resultDict setObject:resultStr forKey:RESVIN_RESULT];
//            }
//        }
//            break;
            
        default:
            break;
    }
    if (self.block) {
        self.block(resultDict);
    }
    [self backAction];
    return;
//    ResultViewController *rvc = [[ResultViewController alloc] initWithNibName:@"ResultViewController" bundle:nil];
//    rvc.resultDic = resultDict;
//    rvc.resVCCardIndex = self.exIdCardIndex;
//    [self presentViewController:rvc animated:YES completion:nil];
}

-(CGRect)getImageSize:(CGSize)imageSize byCardRect:(CGRect)R
{
    NSLog(@"imageSize:%f, %f", imageSize.width, imageSize.height);
    CGRect screenBound = self.view.bounds;
    CGFloat tempWidth = screenBound.size.width;
    CGFloat tempHight = screenBound.size.height;
    screenBound.size.height = tempWidth;
    screenBound.size.width = tempHight;
    
    float screenWidth = screenBound.size.width;//MAX(screenBound.size.width, screenBound.size.height);
    float screenHeight = screenBound.size.height;//MIN(screenBound.size.width, screenBound.size.height);
    float screenRadio = screenHeight/screenWidth;
    
    float imageWidth = imageSize.width;
    float imageHeight = imageSize.height;
    float imageRadio = imageHeight/imageWidth;
    
    CGRect  imageRect = CGRectZero;
    if (screenRadio<imageRadio)
    {
        float radio = screenWidth/imageWidth;
        float offsetheigh = imageSize.height*radio - screenHeight;
        float realHeight = imageHeight*radio;
        imageRect = CGRectMake((R.origin.x)/realHeight*imageSize.height,
                               (R.origin.y+offsetheigh/2)/screenWidth*imageSize.width,
                               R.size.width/realHeight*imageSize.height,
                               R.size.height/screenWidth*imageSize.width);
        
        //设置暂停画面frame
        //        [pauseBgView setFrame:CGRectMake(0, -offsetheigh/2.0f, screenWidth, screenHeight+offsetheigh)];
    }else
    {
        float radio = screenHeight/imageHeight;
        float offsetWidth = imageSize.width*radio - screenWidth;
        float realWith = imageWidth*radio;
        imageRect = CGRectMake((R.origin.x+offsetWidth/2)/screenHeight*imageSize.height,
                               (R.origin.y)/realWith*imageSize.width,
                               R.size.width/screenHeight*imageSize.height,
                               R.size.height/realWith*imageSize.width);
        //设置暂停画面frame
        //        [pauseBgView setFrame:CGRectMake(-offsetWidth/2.0f, 0, screenWidth+offsetWidth, screenHeight)];
    }
    
    return imageRect;
}

//获取摄像头位置
- (AVCaptureDevice *)cameraWithPosition:(AVCaptureDevicePosition)position
{
    NSArray *devices = [AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo];
    for (AVCaptureDevice *device in devices)
    {
        if (device.position == position)
        {
            return device;
        }
    }
    return nil;
}

//对焦
- (void)fouceMode{
    NSError *error;
    AVCaptureDevice *device = [self cameraWithPosition:AVCaptureDevicePositionBack];
    if ([device isFocusModeSupported:AVCaptureFocusModeAutoFocus])
    {
        if ([device lockForConfiguration:&error]) {
            CGPoint cameraPoint = [self.preview captureDevicePointOfInterestForPoint:self.view.center];
            [device setFocusPointOfInterest:cameraPoint];
            [device setFocusMode:AVCaptureFocusModeAutoFocus];
            [device unlockForConfiguration];
        } else {
            NSLog(@"Error: %@", error);
        }
    }
}

#pragma mark - ButtonAction
//返回按钮按钮点击事件
- (void)backAction{
    switch (self.exIdCardIndex) {
        case cardType_ID:
            [hwSaveCache.ymIDCardEngine ymClearAll_ID];
            break;

        case cardType_CP:
            [hwSaveCache.ymIDCardEngine ymClearAll_Plate];;
            break;
            
        default:
            break;
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

//闪光灯按钮点击事件
- (void)flashBtn{
    
    AVCaptureDevice *device = [self cameraWithPosition:AVCaptureDevicePositionBack];
    if (![device hasTorch]) {
        //        NSLog(@"no torch");
    }else{
        [device lockForConfiguration:nil];
        if (!_on) {
            [device setTorchMode: AVCaptureTorchModeOn];
            _on = YES;
        }
        else
        {
            [device setTorchMode: AVCaptureTorchModeOff];
            _on = NO;
        }
        [device unlockForConfiguration];
    }
}

//隐藏状态栏
- (UIStatusBarStyle)preferredStatusBarStyle{
    
    return UIStatusBarStyleDefault;
}

- (BOOL)prefersStatusBarHidden{
    
    return YES;
}

CG_INLINE CGRect
CGRectMakeBack(CGFloat x, CGFloat y, CGFloat width, CGFloat height)
{
    CGRect rect;
    
    if (SYSTEM_HEIGHT==480) {
        rect.origin.y = y-20;
        rect.origin.x = x;
        rect.size.width = width;
        rect.size.height = height;
    }else{
        rect.origin.x = x * SYSTEM_WIDTH/320;
        rect.origin.y = y * SYSTEM_HEIGHT/568;
        rect.size.width = width * SYSTEM_WIDTH/320;
        rect.size.height = height * SYSTEM_HEIGHT/568;
        
    }
    return rect;
}

CG_INLINE CGRect
CGRectMakeFlash(CGFloat x, CGFloat y, CGFloat width, CGFloat height)
{
    CGRect rect;
    
    if (SYSTEM_HEIGHT==480) {
        rect.origin.y = y-20;
        rect.origin.x = x;
        rect.size.width = width;
        rect.size.height = height;
    }else{
        rect.origin.x = x * SYSTEM_WIDTH/320;
        rect.origin.y = y * SYSTEM_HEIGHT/568;
        rect.size.width = width * SYSTEM_WIDTH/320;
        rect.size.height = height * SYSTEM_HEIGHT/568;
        
    }
    return rect;
}

-(void)bcrResultCallbackWithValue:(NSInteger)value
{
    bcrResultValue = value;
}

@end
