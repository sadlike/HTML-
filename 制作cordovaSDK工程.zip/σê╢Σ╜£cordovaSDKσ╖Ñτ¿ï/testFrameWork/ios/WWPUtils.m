//
//  WWPUtils.m
//  testFrameWork
//
//  Created by wwp on 2018/11/12.
//  Copyright © 2018年 wwp. All rights reserved.
//

#import "WWPUtils.h"
#import "YMIDCardEngine.h"
#import "WWPCacheManager.h"
#import <Photos/Photos.h>
#define BUNDLE_NAME @"WWPScanCardResourceBundle"

@implementation WWPUtils
WWPUtils *instance=nil;
+(instancetype)shareInstance
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (instance==nil) {
            instance = [[WWPUtils alloc]init];
        }
    });
    return instance;
}
+ (NSBundle *)getBundle{
    
    return [NSBundle bundleWithPath: [[NSBundle mainBundle] pathForResource: BUNDLE_NAME ofType: @"bundle"]];
}

+ (NSString *)getBundlePath: (NSString *) assetName{
    
    NSBundle *myBundle = [WWPUtils getBundle];
    
    if (myBundle && assetName) {
        
        return [[myBundle resourcePath] stringByAppendingPathComponent: assetName];
    }
    
    return nil;
}
-(NSMutableDictionary *)makeResultDicVideo_ID:(NSDictionary *)dic{
    NSMutableDictionary *messageDic =[[NSMutableDictionary alloc]init];;
    
    if (!dic.count)
        return [@{}mutableCopy];
    
    if ([[[dic objectForKey:RESID_NAME] objectForKey:@"value"] length]) {
       NSString *valueStr=[NSString stringWithFormat:@"%@",[[dic objectForKey:RESID_NAME] objectForKey:@"value"]];
        [messageDic setValue:valueStr forKey:@"name"];
    }
    if ([[[dic objectForKey:RESID_SEX] objectForKey:@"value"] length]) {
         NSString *valueStr=[NSString stringWithFormat:@"%@",[[dic objectForKey:RESID_SEX] objectForKey:@"value"]];
        [messageDic setValue:valueStr forKey:@"sex"];
    }
    if ([[[dic objectForKey:RESID_FOLK] objectForKey:@"value"] length]) {
        NSString *valueStr=[NSString stringWithFormat:@"%@",[[dic objectForKey:RESID_FOLK] objectForKey:@"value"]];
        [messageDic setValue:valueStr forKey:@"nation"];
    }
    if ([[[dic objectForKey:RESID_BIRT] objectForKey:@"value"] length] ) {
        NSString *valueStr=[NSString stringWithFormat:@"%@",[[dic objectForKey:RESID_BIRT] objectForKey:@"value"]];
        [messageDic setValue:valueStr forKey:@"birthday"];
    }
    if ([[[dic objectForKey:RESID_ADDRESS] objectForKey:@"value"] length]) {
      NSString *valueStr=[NSString stringWithFormat:@"%@",[[dic objectForKey:RESID_ADDRESS] objectForKey:@"value"]];
         [messageDic setValue:valueStr forKey:@"address"];
    }
    if ([[[dic objectForKey:RESID_NUM] objectForKey:@"value"] length]) {
        NSString *valueStr=[NSString stringWithFormat:@"%@",[[dic objectForKey:RESID_NUM] objectForKey:@"value"]];
         [messageDic setValue:valueStr forKey:@"id_card_no"];
    }
    if ([[[dic objectForKey:RESID_ISSUE] objectForKey:@"value"] length]) {
        NSString *valueStr=[NSString stringWithFormat:@"%@",[[dic objectForKey:RESID_ISSUE] objectForKey:@"value"]];
        [messageDic setValue:valueStr forKey:@"issuer"];
    }
    if ([[[dic objectForKey:RESID_VALID] objectForKey:@"value"] length]) {
        NSString *valueStr=[NSString stringWithFormat:@"%@",[[dic objectForKey:RESID_VALID] objectForKey:@"value"]];
        [messageDic setValue:valueStr forKey:@"expiration_date"];
    }
    
    if([[dic objectForKey:RESID_IMAGE] length]){
        NSString *str = [NSString stringWithFormat:@"%@",[dic objectForKey:RESID_IMAGE]];
        [messageDic setValue:str forKey:@"id_image"];
    }
    
    
    return messageDic;
}
- (NSString *)makeCardResultWithDicVideo_ID:(NSDictionary*)dic
{
    NSMutableString *message = [NSMutableString string];
    if (!dic.count)
        return nil;
    
    if ([[[dic objectForKey:RESID_NAME] objectForKey:@"value"] length]) {
        [message appendFormat:@"姓名:%@\n",[[dic objectForKey:RESID_NAME] objectForKey:@"value"]];
    }
    if ([[[dic objectForKey:RESID_SEX] objectForKey:@"value"] length]) {
        [message appendFormat:@"性别:%@\n",[[dic objectForKey:RESID_SEX] objectForKey:@"value"]];
    }
    if ([[[dic objectForKey:RESID_FOLK] objectForKey:@"value"] length]) {
        [message appendFormat:@"民族:%@\n",[[dic objectForKey:RESID_FOLK] objectForKey:@"value"]];
    }
    if ([[[dic objectForKey:RESID_BIRT] objectForKey:@"value"] length] ) {
        [message appendFormat:@"出生日期:%@\n",[[dic objectForKey:RESID_BIRT] objectForKey:@"value"]];
    }
    if ([[[dic objectForKey:RESID_ADDRESS] objectForKey:@"value"] length]) {
        [message appendFormat:@"住址:%@\n",[[dic objectForKey:RESID_ADDRESS] objectForKey:@"value"]];
    }
    if ([[[dic objectForKey:RESID_NUM] objectForKey:@"value"] length]) {
        [message appendFormat:@"公民身份号码:%@\n",[[dic objectForKey:RESID_NUM] objectForKey:@"value"]];
    }
    if ([[[dic objectForKey:RESID_ISSUE] objectForKey:@"value"] length]) {
        [message appendFormat:@"签发机关:%@\n",[[dic objectForKey:RESID_ISSUE] objectForKey:@"value"]];
    }
    if ([[[dic objectForKey:RESID_VALID] objectForKey:@"value"] length]) {
        [message appendFormat:@"有效期限:%@\n",[[dic objectForKey:RESID_VALID] objectForKey:@"value"]];
    }
    
    return message;
}

- (NSString *)makeCardResultWithDic_ID:(NSDictionary*)dic
{
    NSMutableString *message = [NSMutableString string];
    if (!dic.count)
        return nil;
    
    if ([[dic objectForKey:RESID_NAME] length]) {
        [message appendFormat:@"姓名:%@\n",[dic objectForKey:RESID_NAME]];
    }
    if ([[dic objectForKey:RESID_SEX] length]) {
        [message appendFormat:@"性别:%@\n",[dic objectForKey:RESID_SEX]];
    }
    if ([[dic objectForKey:RESID_FOLK] length]) {
        [message appendFormat:@"民族:%@\n",[dic objectForKey:RESID_FOLK]];
    }
    if ([[dic objectForKey:RESID_BIRT] length]) {
        [message appendFormat:@"出生日期:%@\n",[dic objectForKey:RESID_BIRT]];
    }
    if ([[dic objectForKey:RESID_ADDRESS] length]) {
        [message appendFormat:@"住址:%@\n",[dic objectForKey:RESID_ADDRESS]];
    }
    if ([[dic objectForKey:RESID_NUM] length]) {
        [message appendFormat:@"公民身份号码:%@\n",[dic objectForKey:RESID_NUM]];
    }
    if ([[dic objectForKey:RESID_ISSUE] length]) {
        [message appendFormat:@"签发机关:%@\n",[dic objectForKey:RESID_ISSUE]];
    }
    if ([[dic objectForKey:RESID_VALID] length]) {
        [message appendFormat:@"有效期限:%@\n",[dic objectForKey:RESID_VALID]];
    }
    
    return message;
}

- (NSString *)makeCardResultWithDic_XS:(NSDictionary*)dic
{
    NSMutableString *message = [NSMutableString string];
    if (!dic.count)
        return nil;
    
    if ([[dic objectForKey:RESXS_NAME] length]) {
        [message appendFormat:@"所有人:%@\n",[dic objectForKey:RESXS_NAME]];
    }
    if ([[dic objectForKey:RESXS_CARDNO] length]) {
        [message appendFormat:@"号牌号码:%@\n",[dic objectForKey:RESXS_CARDNO]];
    }
    if ([[dic objectForKey:RESXS_ADDRESS] length]) {
        [message appendFormat:@"住 址:%@\n",[dic objectForKey:RESXS_ADDRESS]];
    }
    if ([[dic objectForKey:RESXS_VEHICLETYPE] length]) {
        [message appendFormat:@"车辆类型:%@\n",[dic objectForKey:RESXS_VEHICLETYPE]];
    }
    if ([[dic objectForKey:RESXS_USECHARACTE] length]) {
        [message appendFormat:@"使用性质:%@\n",[dic objectForKey:RESXS_USECHARACTE]];
    }
    if ([[dic objectForKey:RESXS_MODEL] length]) {
        [message appendFormat:@"品牌型号:%@\n",[dic objectForKey:RESXS_MODEL]];
    }
    if ([[dic objectForKey:RESXS_VIN] length]) {
        [message appendFormat:@"车辆识别代号:%@\n",[dic objectForKey:RESXS_VIN]];
    }
    if ([[dic objectForKey:RESXS_ENGINEPN] length]) {
        [message appendFormat:@"发动机号码:%@\n",[dic objectForKey:RESXS_ENGINEPN]];
    }
    if ([[dic objectForKey:RESXS_REGISTERDATE] length]) {
        [message appendFormat:@"注册日期:%@\n",[dic objectForKey:RESXS_REGISTERDATE]];
    }
    if ([[dic objectForKey:RESXS_ISSUEDATE] length]) {
        [message appendFormat:@"发证日期:%@\n",[dic objectForKey:RESXS_ISSUEDATE]];
    }
    return message;
}

- (NSString *)makeCardResultWithDic_JZ:(NSDictionary*)dic
{
    NSMutableString *message = [NSMutableString string];
    if (!dic.count)
        return nil;
    
    if ([[dic objectForKey:RESJZ_NAME] length]) {
        [message appendFormat:@"姓名:%@\n",[dic objectForKey:RESJZ_NAME]];
    }
    if ([[dic objectForKey:RESJZ_CARDNO] length]) {
        [message appendFormat:@"证号:%@\n",[dic objectForKey:RESJZ_CARDNO]];
    }
    if ([[dic objectForKey:RESJZ_SEX] length]) {
        [message appendFormat:@"性别:%@\n",[dic objectForKey:RESJZ_SEX]];
    }
    if ([[dic objectForKey:RESJZ_BIRTHDAY] length]) {
        [message appendFormat:@"出生日期:%@\n",[dic objectForKey:RESJZ_BIRTHDAY]];
    }
    if ([[dic objectForKey:RESJZ_ADDRESS] length]) {
        [message appendFormat:@"住址:%@\n",[dic objectForKey:RESJZ_ADDRESS]];
    }
    if ([[dic objectForKey:RESJZ_ISSUE_DATE] length]) {
        [message appendFormat:@"初次领证日期:%@\n",[dic objectForKey:RESJZ_ISSUE_DATE]];
    }
    if ([[dic objectForKey:RESJZ_VALID_PERIOD] length]) {
        [message appendFormat:@"有效期限:%@\n",[dic objectForKey:RESJZ_VALID_PERIOD]];
    }
    if ([[dic objectForKey:RESJZ_COUNTRY] length]) {
        [message appendFormat:@"国籍:%@\n",[dic objectForKey:RESJZ_COUNTRY]];
    }
    if ([[dic objectForKey:RESJZ_DRIVING_TYPE] length]) {
        [message appendFormat:@"准驾车型:%@\n",[dic objectForKey:RESJZ_DRIVING_TYPE]];
    }
    if ([[dic objectForKey:RESJZ_REGISTER_DATE] length]) {
        [message appendFormat:@"有效起始日期:%@\n",[dic objectForKey:RESJZ_REGISTER_DATE]];
    }
    return message;
}

- (NSString *)makeCardResultWithDic_CP:(NSDictionary*)dic
{
    NSMutableString *message = [NSMutableString string];
    if (!dic.count)
        return nil;
    
    if ([[dic objectForKey:RESCP_NUM] length]) {
        [message appendFormat:@"号码:%@\n",[dic objectForKey:RESCP_NUM]];
    }
    if ([[dic objectForKey:RESCP_LAYER] length]) {
        [message appendFormat:@"层级:%@\n",[dic objectForKey:RESCP_LAYER]];
    }
    if ([[dic objectForKey:RESCP_COLOR] length]) {
        [message appendFormat:@"颜色:%@\n",[dic objectForKey:RESCP_COLOR]];
    }
    return message;
}

- (NSString *)makeCardResultWithDic_VIN:(NSDictionary*)dic
{
    NSString *field = [dic objectForKey:RESVIN_RESULT];
    return field;
}

- (NSString *)makeCardResultWithDic_GCFP:(NSDictionary*)dic
{
    NSMutableString *message = [NSMutableString string];
    if (!dic.count)
        return nil;
    
    if ([[dic objectForKey:RESGCFP_RESULT] length]) {
        [message appendFormat:@"%@\n",[dic objectForKey:RESGCFP_RESULT]];
    }
    return message;
}

- (NSString *)makeCardResultWithDic_HZ:(NSDictionary*)dic
{
    NSMutableString *message = [NSMutableString string];
    if (!dic.count)
        return nil;
    
    if ([[dic objectForKey:RESHZ_NAME] length]) {
        [message appendFormat:@"英文姓名:%@\n",[dic objectForKey:RESHZ_NAME]];
    }
    if ([[dic objectForKey:RESHZ_NAMECH] length]) {
        [message appendFormat:@"中文姓名:%@\n",[dic objectForKey:RESHZ_NAMECH]];
    }
    if ([[dic objectForKey:RESHZ_CARDNO] length]) {
        [message appendFormat:@"护照号:%@\n",[dic objectForKey:RESHZ_CARDNO]];
    }
    if ([[dic objectForKey:RESHZ_SEX] length]) {
        [message appendFormat:@"英文性别:%@\n",[dic objectForKey:RESHZ_SEX]];
    }
    if ([[dic objectForKey:RESHZ_SEXCH] length]) {
        [message appendFormat:@"中文性别:%@\n",[dic objectForKey:RESHZ_SEXCH]];
    }
    if ([[dic objectForKey:RESHZ_BIRTHDAY] length]) {
        [message appendFormat:@"出生日期:%@\n",[dic objectForKey:RESHZ_BIRTHDAY]];
    }
    if ([[dic objectForKey:RESHZ_ADDRESS] length]) {
        [message appendFormat:@"英文地点:%@\n",[dic objectForKey:RESHZ_ADDRESS]];
    }
    if ([[dic objectForKey:RESHZ_ADDRESSCH] length]) {
        [message appendFormat:@"中文地点:%@\n",[dic objectForKey:RESHZ_ADDRESSCH]];
    }
    if ([[dic objectForKey:RESHZ_ISSUEDATE] length]) {
        [message appendFormat:@"签发日期:%@\n",[dic objectForKey:RESHZ_ISSUEDATE]];
    }
    if ([[dic objectForKey:RESHZ_VALIDPERIOD] length]) {
        [message appendFormat:@"有效期限:%@\n",[dic objectForKey:RESHZ_VALIDPERIOD]];
    }
    if ([[dic objectForKey:RESHZ_NATION] length]) {
        [message appendFormat:@"国 家:%@\n",[dic objectForKey:RESHZ_NATION]];
    }
    if ([[dic objectForKey:RESHZ_ISSUEADDRESS] length]) {
        [message appendFormat:@"英文签发地点:%@\n",[dic objectForKey:RESHZ_ISSUEADDRESS]];
    }
    if ([[dic objectForKey:RESHZ_ISSUEADDRESSCH] length]) {
        [message appendFormat:@"中文签发地点:%@\n",[dic objectForKey:RESHZ_ISSUEADDRESSCH]];
    }
    if ([[dic objectForKey:RESHZ_PERSONALNO] length]) {
        [message appendFormat:@"个人号码:%@\n",[dic objectForKey:RESHZ_PERSONALNO]];
    }
    if ([[dic objectForKey:RESHZ_ENFIR] length]) {
        [message appendFormat:@"中文姓拼音:%@\n",[dic objectForKey:RESHZ_ENFIR]];
    }
    if ([[dic objectForKey:RESHZ_ENSEN] length]) {
        [message appendFormat:@"中文名拼音:%@\n",[dic objectForKey:RESHZ_ENSEN]];
    }
    if ([[dic objectForKey:RESHZ_NAMEFIR] length]) {
        [message appendFormat:@"中文姓:%@\n",[dic objectForKey:RESHZ_NAMEFIR]];
    }
    if ([[dic objectForKey:RESHZ_NAMESEN] length]) {
        [message appendFormat:@"中文名:%@\n",[dic objectForKey:RESHZ_NAMESEN]];
    }
    if ([[dic objectForKey:RESHZ_MRZ] length]) {
        [message appendFormat:@"MRZ:%@\n",[dic objectForKey:RESHZ_MRZ]];
    }
    if ([[dic objectForKey:RESHZ_BIDC_MRZ1] length]) {
        [message appendFormat:@"BIDC_MRZ1:%@\n",[dic objectForKey:RESHZ_BIDC_MRZ1]];
    }
    if ([[dic objectForKey:RESHZ_BIDC_MRZ2] length]) {
        [message appendFormat:@"BIDC_MRZ2:%@\n",[dic objectForKey:RESHZ_BIDC_MRZ2]];
    }
    
    return message;
}


-(UIImage*)cropImage:(UIImage*)srcImage WithRect:(CGRect)rect
{
    CGImageRef cr = CGImageCreateWithImageInRect(srcImage.CGImage, rect);
    UIImage* cropped = [UIImage imageWithCGImage:cr];
    
    CGImageRelease(cr);
    return cropped;
}

- (UIImage *)scaleImage:(UIImage *)image toScale:(float)scaleSize
{
    image = [UIImage imageWithCGImage:image.CGImage scale:1.0 orientation:UIImageOrientationUp];
    UIGraphicsBeginImageContext(CGSizeMake(image.size.width * scaleSize, image.size.height * scaleSize));
    [image drawInRect:CGRectMake(0, 0, image.size.width * scaleSize, image.size.height * scaleSize)];
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return scaledImage;
}

-(NSString*)getIDCardDataInfo:(NSDictionary*)dict
{
    NSMutableString *info = [NSMutableString string];
    NSString *field = [dict objectForKey:[NSNumber numberWithInt:ID_cardNo]];
    if (hwSaveCache.idType == cardType_Bank)
    {
        field = [dict objectForKey:[NSNumber numberWithInt:Bank_cardNo]];
        if ([field length])
            [info appendFormat:@"%@\r",field];
        field = [dict objectForKey:[NSNumber numberWithInt:Bank_bankName]];
        if ([field length])
            [info appendFormat:@"%@\r",field];
        field = [dict objectForKey:[NSNumber numberWithInt:Bank_cardName]];
        if ([field length])
            [info appendFormat:@"%@\r",field];
        field = [dict objectForKey:[NSNumber numberWithInt:Bank_cardType]];
        if ([field length])
            [info appendFormat:@"%@",field];
    }
    else
    {
        if ([field length])
            [info appendFormat:@"%@\r",field];
    }
    return info;
}

-(NSString*)getPlateDataInfo:(NSDictionary*)dict
{
    NSMutableString *info = [NSMutableString string];
    NSString *field = [dict objectForKey:[NSNumber numberWithInt:ID_cardNo]];
    if ([field length])
    {
        field = [field stringByReplacingOccurrencesOfString:@"Color" withString:@"颜色"];
        field = [field stringByReplacingOccurrencesOfString:@"Layer" withString:@"层级"];
        field = [field stringByReplacingOccurrencesOfString:@"Num" withString:@"车牌号码"];
        [info appendFormat:@"%@\r",field];
    }
    
    return info;
}
+(BOOL)saveImgToPhoneWithImage:(id)image{
    // 1.先保存图片到【相机胶卷】
    /// 同步执行修改操作
    NSError *error = nil;
    __block PHObjectPlaceholder *placeholder = nil;
    [[PHPhotoLibrary sharedPhotoLibrary]performChangesAndWait:^{
        placeholder =  [PHAssetChangeRequest creationRequestForAssetFromImage:image].placeholderForCreatedAsset;
    } error:&error];
    if (error) {
        NSLog(@"保存失败");
        return NO;
    }
    // 2.拥有一个【自定义相册】
    // 获取 app 名称
    NSString *title = [NSBundle mainBundle].infoDictionary[(NSString *)kCFBundleNameKey];
    PHFetchResult<PHAssetCollection *> *result = [PHAssetCollection fetchAssetCollectionsWithType:(PHAssetCollectionTypeAlbum)
                                                                                          subtype:(PHAssetCollectionSubtypeAlbumRegular)
                                                                                          options:nil];
    PHAssetCollection * assetCollection;
    
    for (PHAssetCollection *collection in result) {
        if ([collection.localizedTitle isEqualToString:title]) { // 说明 app 中存在该相册
            assetCollection =  collection;
            break;
        }
    }
    if (assetCollection == nil) {
        NSLog(@"创建相册失败");
    }
    // 3.将刚才保存到【相机胶卷】里面的图片引用到【自定义相册】
    [[PHPhotoLibrary sharedPhotoLibrary]performChangesAndWait:^{
        PHAssetCollectionChangeRequest *requtes = [PHAssetCollectionChangeRequest changeRequestForAssetCollection:assetCollection];
        [requtes addAssets:@[placeholder]];
    } error:&error];
    if (error) {
        NSLog(@"保存图片失败");
          return NO;
    } else {
        NSLog(@"保存图片成功");
        return YES;
    }
}
@end
