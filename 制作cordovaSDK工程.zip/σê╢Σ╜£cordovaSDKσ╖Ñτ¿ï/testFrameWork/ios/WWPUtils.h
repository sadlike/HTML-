//
//  WWPUtils.h
//  testFrameWork
//
//  Created by wwp on 2018/11/12.
//  Copyright © 2018年 wwp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIkit.h>

@interface WWPUtils : NSObject
+(instancetype)shareInstance;
- (NSString *)makeCardResultWithDicVideo_ID:(NSDictionary*)dic;
- (NSString *)makeCardResultWithDic_ID:(NSDictionary*)dic;
- (NSString *)makeCardResultWithDic_XS:(NSDictionary*)dic;
- (NSString *)makeCardResultWithDic_JZ:(NSDictionary*)dic;
-(NSMutableDictionary *)makeResultDicVideo_ID:(NSDictionary *)dic;

+ (NSString *)getBundlePath: (NSString *) assetName;
+ (NSBundle *)getBundle;
+(BOOL)saveImgToPhoneWithImage:(UIImage *)image;
@end
